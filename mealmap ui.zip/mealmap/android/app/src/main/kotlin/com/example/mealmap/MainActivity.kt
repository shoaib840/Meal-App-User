package com.mealapp.eaglesolutions

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
