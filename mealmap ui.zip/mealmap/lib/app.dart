import 'package:mealmap/utilz/constants/exports.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<BottomBarProvider>(
            create: (_) => BottomBarProvider()),
        ChangeNotifierProvider<HomeController>(create: (_) => HomeController()),
        ChangeNotifierProvider<AuthssController>(
            create: (_) => AuthssController()),
        ChangeNotifierProvider<ImagePickerController>(
            create: (_) => ImagePickerController()),
        ChangeNotifierProvider<LanguageControlllerr>(
            create: (_) => LanguageControlllerr()),
      ],
      child: Consumer<LanguageControlllerr>(
        builder: (context, languageController, child) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'MealApp',
            home: const SplashScreen(),
            locale: languageController
                .locale, // Use the locale from LanguageController
            localizationsDelegates: const [
              AppLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            supportedLocales: const [
              Locale("de"),
              Locale("el"),
              Locale("en"),
              Locale("es"),
              Locale("fr"),
              Locale("it"),
              Locale("nl"),
              Locale("pl"),
              Locale("pt"),
              Locale("ru"),
              Locale("tr"),
            ],
          );
        },
      ),
    );
  }
}
