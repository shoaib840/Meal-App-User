import 'package:mealmap/utilz/constants/exports.dart';

class OnBoardingScreen extends StatefulWidget {
  const OnBoardingScreen({super.key});

  @override
  State<OnBoardingScreen> createState() => _OnBoardingScreenState();
}

class _OnBoardingScreenState extends State<OnBoardingScreen> {
  int indexx = 0;
  PageController pageController = PageController();
  @override
  Widget build(BuildContext context) {
    final appLocal = AppLocalizations.of(context);
    List onBoardingList = [
      {
        "title": appLocal!.onBoarding1title, // "Order and Enjoy Anywhere",
        "des": appLocal.onBoarding1Des,
        // "Discover a world of flavors at restaurants near you. Order your favorite dishes and choose whether to have them delivered to your doorstep or pick them up directly at the restaurant. With just a few taps, the food you love is ready for you!",
        "img": IconsApp.onboardingOneIcon
      },
      {
        "title": appLocal
            .onBoarding2title, // "Book Your Table at the Best Restaurants\nand Enjoy Exclusive Discounts.",
        "des": appLocal
            .onBoarding2Des, // "Book your table at the best restaurants and take advantage of exclusive discounts reserved for our users. Whether it's a romantic dinner or a night out with friends, secure a special spot and save.",
        "img": IconsApp.onboardingTwoIcon
      },
      {
        "title": appLocal
            .onBoarding3title, //"Forget the Hassles of Restaurant\nPayments",
        "des": appLocal
            .onBoarding3Des, // "With our app, you can request the bill, pay directly, and even split the cost with your friends. All with a simple click!",
        "img": IconsApp.onboardingThreeIcon
      },
    ];
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: SizedBox(
              height: h,
              width: w,
              child: Column(
                children: [
                  SizedBox(
                    height: h * 0.05,
                  ),
                  SizedBox(
                    height: h * 0.55,
                    width: w,
                    child: PageView.builder(
                      controller: pageController,
                      onPageChanged: (index) {
                        setState(() {
                          indexx = index;
                        });
                      },
                      itemCount: onBoardingList.length,
                      itemBuilder: (context, index) {
                        return Image.asset(
                          onBoardingList[index]['img'],
                        );
                      },
                    ),
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      for (int i = 0; i < onBoardingList.length; i++)
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          margin: const EdgeInsets.symmetric(horizontal: 4.0),
                          width: indexx == i ? w * 0.1 : w * 0.06,
                          height: indexx == i ? h * 0.015 : h * 0.015,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: indexx == i
                                ? AppColors.primaryColor
                                : AppColors.greyColor.withOpacity(0.4),
                          ),
                        ),
                    ],
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  appText(
                      textAlign: TextAlign.center,
                      myText: onBoardingList[indexx]['title'],
                      isbold: true,
                      myfontSize: 16),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: w * 0.02),
                    child: appText(
                        textAlign: TextAlign.center,
                        myfontSize: 10,
                        myText: onBoardingList[indexx]['des']),
                  ),
                  const Spacer(),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: w * 0.02),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextButton(
                            onPressed: () {
                              Navigator.push(context,
                                  createRoute(newPage: const LoginScreen()));
                            },
                            child: appText(
                                myText: appLocal.skip, //"Skip",
                                isbold: true)),
                        Container(
                          height: h * 0.06,
                          width: w * 0.12,
                          clipBehavior: Clip.antiAlias,
                          decoration: const BoxDecoration(
                              color: AppColors.secondaryColor,
                              shape: BoxShape.circle),
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () {
                                if (indexx < onBoardingList.length - 1) {
                                  // Check if not at the last page
                                  setState(() {
                                    indexx++; // Increment indexx
                                    pageController.animateToPage(
                                      indexx,
                                      duration:
                                          const Duration(milliseconds: 300),
                                      curve: Curves.easeInOut,
                                    );
                                  });
                                } else {
                                  Navigator.push(
                                      context,
                                      createRoute(
                                          newPage: const LoginScreen()));
                                }
                              },
                              splashColor: AppColors.whiteColor,
                              child: const Icon(
                                Icons.arrow_forward_ios,
                                color: AppColors.primaryColor,
                                size: 18,
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: h * 0.01,
                  )
                ],
              ),
            )));
  }
}
