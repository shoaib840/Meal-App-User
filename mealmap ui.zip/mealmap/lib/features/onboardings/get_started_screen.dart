import 'package:mealmap/utilz/constants/exports.dart';

class GetStartedScreen extends StatefulWidget {
  const GetStartedScreen({super.key});

  @override
  State<GetStartedScreen> createState() => _GetStartedScreenState();
}

class _GetStartedScreenState extends State<GetStartedScreen> {
  final GetStorage _storage = GetStorage();

  @override
  void initState() {
    _storage.write('isSplashScreenShow', false);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              height: h,
              width: w,
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(ImagesApp.getStartedImage),
                      fit: BoxFit.fill)),
              child: Column(
                children: [
                  SizedBox(
                    height: h * 0.58,
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: w * 0.2,
                      ),
                      SizedBox(
                        height: h * 0.06,
                        width: w * 0.16,
                        child: Image.asset(IconsApp.appIcon),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: h * 0.01,
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: w * 0.1,
                      ),
                      appText(myText: "MealApp", isbold: true, myfontSize: 30),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: w * 0.07,
                      ),
                      appText(
                        myText: "${appLocal!.getstartedwith} MealApp",
                        isbold: true,
                      ),
                    ],
                  ),
                  SizedBox(
                    height: h * 0.12,
                  ),
                  SizedBox(
                    height: h * 0.08,
                    width: w,
                    child: Row(
                      children: [
                        SizedBox(
                          width: w * 0.05,
                        ),
                        SizedBox(
                          height: h * 0.04,
                          width: w * 0.15,
                          child: appButton(
                              borderColor: AppColors.blackColor,
                              buttonColor: AppColors.blackColor,
                              textColor: AppColors.whiteColor,
                              buttonText: appLocal.skip , //"Skip",
                              ontapfunction: () {
                                Navigator.push(context,
                                    createRoute(newPage: const LoginScreen()));
                              }),
                        ),
                        const Spacer(),
                        Container(
                          height: h * 0.06,
                          width: w * 0.42,
                          clipBehavior: Clip.antiAlias,
                          decoration: BoxDecoration(
                              color: AppColors.primaryColor,
                              borderRadius: BorderRadius.circular(30)),
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    createRoute(
                                        newPage: const OnBoardingScreen()));
                              },
                              splashColor: AppColors.whiteColor,
                              child: Row(
                                children: [
                                  SizedBox(
                                    width: w * 0.02,
                                  ),
                                  appText(
                                      myText: "  ${appLocal.getstarted}",
                                       isbold: true),
                                  const Spacer(),
                                  Container(
                                    height: h * 0.06,
                                    width: w * 0.12,
                                    decoration: const BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: AppColors.blackColor,
                                    ),
                                    child: const Icon(
                                      Icons.arrow_forward_ios,
                                      color: AppColors.primaryColor,
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: w * 0.05,
                        ),
                      ],
                    ),
                  )
                ],
              ),
            )));
  }
}
