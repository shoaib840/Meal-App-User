import 'package:mealmap/utilz/constants/exports.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final GetStorage _storage = GetStorage();

  @override
  void initState() {
    super.initState();
    bool isSplashScreenShow = _storage.read('isSplashScreenShow') ?? true;
    FirebaseAuth.instance.authStateChanges().listen((User? user) {
      if (!mounted) return; // Ensure the widget is still mounted
      if (user == null) {
        Future.delayed(const Duration(seconds: 4)).then((value) {
          if (!mounted) return; // Ensure the widget is still mounted
          if (isSplashScreenShow) {
            Navigator.pushAndRemoveUntil(
              context,
              createRoute(newPage: const GetStartedScreen()),
              (route) => false,
            );
          } else {
            Navigator.pushAndRemoveUntil(
              context,
              createRoute(newPage: const LoginScreen()),
              (route) => false,
            );
          }
        });
      } else {
        context.read<AuthssController>().getUserData();
        Future.delayed(const Duration(seconds: 5)).then((value) {
          if (!mounted) return; // Ensure the widget is still mounted
          Navigator.pushAndRemoveUntil(
            context,
            createRoute(newPage: const DrawerWithBottomBar()),
            (route) => false,
          );
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: SizedBox(
              height: h,
              width: w,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    height: h * 0.15,
                    width: w * 0.3,
                    child: Image.asset(IconsApp.appIcon),
                  ),
                  appText(myText: "MealApp", isbold: true, myfontSize: 24),
                  SizedBox(
                    height: h * 0.01,
                  ),
                  SizedBox(
                    width: w,
                    child: const Center(
                      child: SpinKitThreeBounce(
                        color: AppColors.primaryColor,
                        size: 40,
                      ),
                    ),
                  )
                ],
              ),
            )));
  }
}
