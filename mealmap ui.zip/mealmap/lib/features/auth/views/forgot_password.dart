import 'package:mealmap/utilz/constants/exports.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  TextEditingController emailController = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  @override
  void dispose() {
    emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final authsWatch = context.watch<AuthssController>();
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Stack(
              children: [
                Container(
                  height: h,
                  width: w,
                  padding: EdgeInsets.only(left: w * 0.05, right: w * 0.05),
                  child: Form(
                    key: formKey,
                    child: Column(
                      children: [
                        SizedBox(
                          height: h * 0.02,
                        ),
                        Row(
                          children: [
                            arrowBack(),
                          ],
                        ),
                        SizedBox(
                          height: h * 0.02,
                        ),
                        SizedBox(
                          height: h * 0.05,
                          width: w * 0.1,
                          child: Image.asset(IconsApp.appIcon),
                        ),
                        SizedBox(
                          height: h * 0.01,
                        ),
                        appText(
                            myText: "MealApp", isbold: true, myfontSize: 30),
                        SizedBox(
                          height: h * 0.1,
                        ),
                        appText(
                            myText: appLocal!
                                .enteryouremailtorecoverpassword, //"Enter your email to recover password",
                            isbold: true),
                        SizedBox(
                          height: h * 0.02,
                        ),
                        customTextField(
                          myControler: emailController,
                          mYhintText: appLocal.email, //"Email",
                          keyBordType: TextInputType.name,
                          fieldValidator: (value) {
                            if (value == null || value.isEmpty) {
                              return appLocal.required; // 'Required';
                            }
                            bool check = emailvalidator(value.toString());
                            if (check == false) {
                              return appLocal
                                  .emailIsIncorrect; //'Email is incorrect';
                            }
                            return null;
                          },
                        ),
                        SizedBox(
                          height: h * 0.04,
                        ),
                        SizedBox(
                          height: h * 0.065,
                          width: w * 0.8,
                          child: appButton(
                              buttonText: appLocal.continuee, //"Continue",
                              ontapfunction: () {
                                if (formKey.currentState!.validate()) {
                                  context
                                      .read<AuthssController>()
                                      .forgetPassword(
                                          email: emailController.text,
                                          context: context);
                                }
                              }),
                        ),
                      ],
                    ),
                  ),
                ),
                //-----------------------------------------------//
                authsWatch.isloading == true ? loading() : const SizedBox()
              ],
            )));
  }
}
