import 'dart:developer';
import 'package:mealmap/utilz/constants/exports.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  bool isPassShow = true;
  TextEditingController phoneNumberController = TextEditingController();
  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String completePhoneNumber = '';

  @override
  void initState() {
    context.read<ImagePickerController>().clearImage();
    super.initState();
  }

  @override
  void dispose() {
    phoneNumberController.dispose();
    firstNameController.dispose();
    lastNameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final imagePickWatch = context.watch<ImagePickerController>();
    final authsRead = context.read<AuthssController>();
    final authsWatch = context.watch<AuthssController>();
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Stack(
              children: [
                Container(
                  height: h,
                  width: w,
                  padding: EdgeInsets.only(left: w * 0.05, right: w * 0.05),
                  child: SingleChildScrollView(
                    child: Form(
                      key: formKey,
                      child: Column(
                        children: [
                          SizedBox(
                            height: h * 0.03,
                          ),
                          SizedBox(
                            height: h * 0.05,
                            width: w * 0.1,
                            child: Image.asset(IconsApp.appIcon),
                          ),
                          SizedBox(
                            height: h * 0.01,
                          ),
                          appText(
                              myText: "MealApp", isbold: true, myfontSize: 30),
                          SizedBox(
                            height: h * 0.02,
                          ),
                          appText(
                              myText: appLocal!.signUp, //"Sign Up",
                              isbold: true,
                              myfontSize: 16),
                          SizedBox(
                            height: h * 0.02,
                          ),
                          GestureDetector(
                            onTap: () {
                              showModalBottomSheet(
                                backgroundColor: Colors.transparent,
                                isScrollControlled: true,
                                context: context,
                                builder: (BuildContext context) {
                                  return const EditPictureBottomSheet();
                                },
                              );
                            },
                            child: Container(
                              height: h * 0.1,
                              width: w * 0.25,
                              clipBehavior: Clip.antiAlias,
                              decoration: BoxDecoration(
                                  color:
                                      AppColors.secondaryColor.withOpacity(0.5),
                                  shape: BoxShape.circle),
                              child: Padding(
                                padding: EdgeInsets.all(
                                    imagePickWatch.profileImage != null
                                        ? 0
                                        : 20.0),
                                child: imagePickWatch.profileImage != null
                                    ? Image.file(
                                        imagePickWatch.profileImage!,
                                        fit: BoxFit.cover,
                                      )
                                    : Image.asset(
                                        IconsApp.personIcon,
                                        color: AppColors.primaryColor,
                                      ),
                              ),
                            ),
                          ),
                          //--------------------------------------------------------//
                          SizedBox(
                            height: h * 0.02,
                          ),
                          SizedBox(
                            height: h * 0.01,
                          ),
                          SizedBox(
                            width: w,
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                color: Colors.transparent,
                                borderRadius: BorderRadius.circular(5),
                              ),
                              child: IntlPhoneField(
                                validator: (phone) {
                                  if (phone?.number == null ||
                                      phone!.number.isEmpty) {
                                    return appLocal.required; //'Required';
                                  }
                                  return null;
                                },
                                dropdownIcon: const Icon(
                                  Icons.arrow_drop_down,
                                  color: AppColors.primaryColor,
                                ),
                                initialCountryCode: 'US',
                                controller: phoneNumberController,
                                inputFormatters: [
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[0-9]')),
                                ],
                                keyboardType: TextInputType.phone,
                                style: const TextStyle(fontFamily: "Poppins"),
                                decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.symmetric(
                                      vertical: 5, horizontal: 5),
                                  filled: true,
                                  fillColor: AppColors.secondaryColor,
                                  floatingLabelBehavior:
                                      FloatingLabelBehavior.never,
                                  counterText: '',
                                  hintText:
                                      appLocal.phonenumber, // "Phone Number",
                                  hintStyle: const TextStyle(
                                      color: Colors.black,
                                      fontSize: 12,
                                      fontFamily: "Poppins"),
                                  errorBorder: OutlineInputBorder(
                                    borderSide: const BorderSide(
                                        color: Colors.transparent),
                                    borderRadius: BorderRadius.circular(30),
                                  ),
                                  enabled: true,
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: const BorderSide(
                                        width: 2, color: Colors.transparent),
                                    borderRadius: BorderRadius.circular(30),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: const BorderSide(
                                        width: 2, color: Colors.transparent),
                                    borderRadius: BorderRadius.circular(30),
                                  ),
                                  disabledBorder: OutlineInputBorder(
                                    borderSide: const BorderSide(
                                        width: 2, color: Colors.transparent),
                                    borderRadius: BorderRadius.circular(30),
                                  ),
                                  border: OutlineInputBorder(
                                    borderSide: const BorderSide(
                                        width: 2, color: Colors.transparent),
                                    borderRadius: BorderRadius.circular(30),
                                  ),
                                ),
                                onChanged: (phone) {
                                  if (phone.number.isEmpty) {
                                    print("+++++++++++++++++=");
                                    setState(() {
                                      completePhoneNumber = '';
                                      print(completePhoneNumber);
                                    });
                                  } else {
                                    setState(() {
                                      completePhoneNumber =
                                          phone.completeNumber.toString();
                                      log(phone.completeNumber.toString());
                                      log(completePhoneNumber);
                                    });
                                  }
                                },
                                onCountryChanged: (phone) {
                                  log('Country code changed to: ' +
                                      phone.code.toString());
                                },
                              ),
                            ),
                          ),

                          //----------------------------------------------------------//
                          SizedBox(
                            height: h * 0.02,
                          ),
                          customTextField(
                            mYhintText: appLocal.firstname, // "First name",
                            keyBordType: TextInputType.name,
                            myControler: firstNameController,
                            fieldValidator: (value) {
                              if (value == null || value.isEmpty) {
                                return appLocal.required; //'Required';
                              }
                              return null;
                            },
                          ),
                          SizedBox(
                            height: h * 0.02,
                          ),
                          customTextField(
                            mYhintText: appLocal.lastname, //"Last name",
                            myControler: lastNameController,
                            keyBordType: TextInputType.name,
                            fieldValidator: (value) {
                              if (value == null || value.isEmpty) {
                                return appLocal.required; //'Required';
                              }
                              return null;
                            },
                          ),
                          SizedBox(
                            height: h * 0.02,
                          ),
                          customTextField(
                            mYhintText: appLocal.email, //"Email",
                            myControler: emailController,
                            keyBordType: TextInputType.name,
                            fieldValidator: (value) {
                              if (value == null || value.isEmpty) {
                                return appLocal.required; //'Required';
                              }
                              bool check = emailvalidator(value.toString());
                              if (check == false) {
                                return appLocal
                                    .emailIsIncorrect; //'Invalid Email';
                              }
                              return null;
                            },
                          ),
                          SizedBox(
                            height: h * 0.02,
                          ),
                          customTextField(
                              myControler: passwordController,
                              obsecureText: isPassShow,
                              suffixIconOnTap: () {
                                isPassShow = !isPassShow;
                                setState(() {});
                              },
                              fieldValidator: (value) {
                                if (value == null || value.isEmpty) {
                                  return appLocal.required; //'Required';
                                }
                                if (value.toString().length < 6) {
                                  return appLocal
                                      .passwordIsTooSmall; //'Password is too small';
                                }
                                return null;
                              },
                              mYhintText: appLocal.password, // "Password",
                              keyBordType: TextInputType.name,
                              suffixIcon: isPassShow
                                  ? Icons.visibility_outlined
                                  : Icons.visibility_off_outlined),
                          SizedBox(
                            height: h * 0.05,
                          ),
                          SizedBox(
                            height: h * 0.065,
                            width: w * 0.8,
                            child: appButton(
                                buttonText: appLocal.continuee, //"Continue",
                                ontapfunction: () async {
                                  if (formKey.currentState!.validate()) {
                                    if (completePhoneNumber != '' ||
                                        completePhoneNumber.isNotEmpty) {
                                      bool result =
                                          await authsRead.createProfile(
                                              context: context,
                                              userEmail: emailController.text,
                                              firstname:
                                                  firstNameController.text,
                                              lastname: lastNameController.text,
                                              phone: completePhoneNumber,
                                              profileimage:
                                                  imagePickWatch.profileImage ??
                                                      "",
                                              userPass:
                                                  passwordController.text);
                                      if (result) {
                                        await authsRead.getUserData();
                                        emailController.clear();
                                        firstNameController.clear();
                                        lastNameController.clear();
                                        phoneNumberController.clear();
                                        passwordController.clear();
                                        Navigator.pushAndRemoveUntil(
                                          // ignore: use_build_context_synchronously
                                          context,
                                          createRoute(
                                              newPage:
                                                  const DrawerWithBottomBar()),
                                          (route) => false,
                                        );
                                      }
                                      //------------------------------------------------//
                                      //---------------------------------------------------------------------------//
                                    } else {
                                      snaki(
                                          context: context,
                                          msg: appLocal
                                              .enterphonenumber, //"Enter phone number",
                                          isErrorColor: true);
                                    }
                                    // Your action on form validation success
                                  }
                                }),
                          ),
                          SizedBox(
                            height: h * 0.02,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              appText(myText: "Already have an account?"),
                              TextButton(
                                  onPressed: () {
                                    Navigator.pushReplacement(
                                        context,
                                        createRoute(
                                            newPage: const LoginScreen()));
                                  },
                                  child: appText(
                                      myText: appLocal.signIn, // "Sign In",
                                      isbold: true,
                                      myColors: AppColors.primaryColor))
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),

                //----------------------------------------------------------------//
                authsWatch.isloading == true ? loading() : const SizedBox()
              ],
            )));
  }
}
