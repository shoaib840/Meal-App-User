import 'package:mealmap/utilz/constants/exports.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool isPassShow = true;
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final authsRead = context.read<AuthssController>();
    final authsWatch = context.watch<AuthssController>();
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Stack(
              children: [
                Container(
                  height: h,
                  width: w,
                  padding: EdgeInsets.only(left: w * 0.05, right: w * 0.05),
                  child: SingleChildScrollView(
                    child: Form(
                      key: formKey,
                      child: Column(
                        children: [
                          SizedBox(
                            height: h * 0.03,
                          ),
                          SizedBox(
                            height: h * 0.05,
                            width: w * 0.1,
                            child: Image.asset(IconsApp.appIcon),
                          ),
                          SizedBox(
                            height: h * 0.01,
                          ),
                          appText(
                              myText: "MealApp", isbold: true, myfontSize: 30),

                          SizedBox(
                            height: h * 0.02,
                          ),
                          appText(
                              myText: appLocal!.signIn, //"Sign in",
                              isbold: true,
                              myfontSize: 16),
                          SizedBox(
                            height: h * 0.06,
                          ),
                          customTextField(
                            mYhintText: appLocal.email, //"Email",
                            myControler: emailController,
                            keyBordType: TextInputType.name,
                            fieldValidator: (value) {
                              if (value == null || value.isEmpty) {
                                return appLocal.required; //'Required';
                              }
                              bool check = emailvalidator(value.toString());
                              if (check == false) {
                                return appLocal
                                    .emailIsIncorrect; //'Email is incorrect';
                              }
                              return null;
                            },
                          ),
                          SizedBox(
                            height: h * 0.02,
                          ),
                          customTextField(
                              myControler: passwordController,
                              obsecureText: isPassShow,
                              suffixIconOnTap: () {
                                isPassShow = !isPassShow;
                                setState(() {});
                              },
                              fieldValidator: (value) {
                                if (value == null || value.isEmpty) {
                                  return appLocal.required; //'Required';
                                }
                                if (value.toString().length < 6) {
                                  return appLocal
                                      .passwordIsTooSmall; //'Password is to small';
                                }
                                return null;
                              },
                              mYhintText: appLocal.password, //"Password",
                              keyBordType: TextInputType.name,
                              suffixIcon: isPassShow
                                  ? Icons.visibility_outlined
                                  : Icons.visibility_off_outlined),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        createRoute(
                                            newPage:
                                                const ForgotPasswordScreen()));
                                  },
                                  child: appText(
                                      myText: appLocal
                                          .forgotPassword, // "Forgot Password?",
                                      myColors: AppColors.greyColor))
                            ],
                          ),
                          SizedBox(
                            height: h * 0.02,
                          ),
                          SizedBox(
                            height: h * 0.065,
                            width: w * 0.8,
                            child: appButton(
                                buttonText: appLocal.continuee, // "Continue",
                                ontapfunction: () async {
                                  if (formKey.currentState!.validate()) {
                                    bool result = await authsRead
                                        .logInwithEmailAndPassword(
                                            context: context,
                                            yourPass: passwordController.text,
                                            yourEmail: emailController.text);
                                    if (result) {
                                      Navigator.pushAndRemoveUntil(
                                        // ignore: use_build_context_synchronously
                                        context,
                                        createRoute(
                                            newPage:
                                                const DrawerWithBottomBar()),
                                        (route) => false,
                                      );
                                    }
                                  }
                                }),
                          ),
                          SizedBox(
                            height: h * 0.02,
                          ),
                          appText(myText: appLocal.or //"or"
                              ),
                          SizedBox(
                            height: h * 0.02,
                          ),
                          SizedBox(
                            height: h * 0.065,
                            width: w * 0.8,
                            child: appButtonWithIcon(
                                buttonText: appLocal
                                    .continuewithgoogle, //"Continue with Google",
                                ontapfunction: () async {
                                  //--------------------------------------------------------//
                                  final user =
                                      await authsRead.handleGoogleSignIn();
                                  if (user != null) {
                                    bool result = await authsRead.getUserDataGoogle(
                                        // ignore: use_build_context_synchronously
                                        context: context,
                                        user: user);
                                    //-----------------------------------//
                                    if (result) {
                                      await authsRead.getUserData();
                                      Navigator.pushAndRemoveUntil(
                                        // ignore: use_build_context_synchronously
                                        context,
                                        createRoute(
                                            newPage:
                                                const DrawerWithBottomBar()),
                                        (route) => false,
                                      );
                                    } else {
                                      snaki(
                                          // ignore: use_build_context_synchronously
                                          context: context,
                                          msg: appLocal
                                              .errortryagainlater, //"Error try again later",
                                          isErrorColor: true);
                                    }
                                  }
                                  //------------------------------------------------------//
                                },
                                iconPath: IconsApp.googleIcon),
                          ),
                          SizedBox(
                            height: h * 0.15,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              appText(
                                myText: appLocal
                                    .donthaveanaccount, //"Don't have an account?"
                              ),
                              TextButton(
                                  onPressed: () {
                                    Navigator.pushReplacement(
                                        context,
                                        createRoute(
                                            newPage: const SignUpScreen()));
                                  },
                                  child: appText(
                                      myText: appLocal.signUp, // "Sign up",
                                      isbold: true,
                                      myColors: AppColors.primaryColor))
                            ],
                          )

                          // SizedBox(
                          //   height: h * 0.065,
                          //   width: w * 0.8,
                          //   child: appButtonWithIcon(
                          //       buttonText: "Continue as guest",
                          //       ontapfunction: () {},
                          //       iconPath: IconsApp.personIcon),
                          // ),
                          // SizedBox(
                          //   height: h * 0.01,
                          // ),
                          // SizedBox(
                          //   height: h * 0.065,
                          //   width: w * 0.8,
                          //   child: appButtonWithIcon(
                          //       buttonText: "Continue with Phone number",
                          //       ontapfunction: () {},
                          //       iconPath: IconsApp.mailIcon),
                          // ),
                          // SizedBox(
                          //   height: h * 0.01,
                          // ),
                          // SizedBox(
                          //   height: h * 0.065,
                          //   width: w * 0.8,
                          //   child: appButtonWithIcon(
                          //       buttonText: "Continue with Google",
                          //       ontapfunction: () {},
                          //       iconPath: IconsApp.googleIcon),
                          // ),
                          // SizedBox(
                          //   height: h * 0.01,
                          // ),
                          // SizedBox(
                          //   height: h * 0.065,
                          //   width: w * 0.8,
                          //   child: appButtonWithIcon(
                          //       buttonText: "Continue with Apple",
                          //       ontapfunction: () {},
                          //       iconPath: IconsApp.appleIcon),
                          // ),
                        ],
                      ),
                    ),
                  ),
                ),
                //----------------------------------------------------------------//
                authsWatch.isloading == true ? loading() : const SizedBox()
              ],
            )));
  }
}
