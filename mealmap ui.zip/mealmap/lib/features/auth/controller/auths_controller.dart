import 'package:mealmap/utilz/constants/exports.dart';

class AuthssController extends ChangeNotifier {
  final db = FirebaseStorage.instance;
  bool isloading = false;
  Map<String, dynamic>? userData;

  //---------------------------------------------------------------------------------   create login
  Future<bool> createProfile(
      {required context,
      required String userEmail,
      required String firstname,
      required String lastname,
      required String phone,
      required profileimage,
      required String userPass}) async {
    isloading = true;
    notifyListeners();
    try {
      bool res = await signUpwithEmailAndPass(
          context: context, yourPass: userPass, yourEmail: userEmail);
      if (res) {
        await saveUserData(
          image: profileimage,
          context: context,
          email: userEmail,
          fisrtName: firstname,
          lastName: lastname,
          phone: phone,
        );
        isloading = false;
        notifyListeners();
        return true;
      } else {
        isloading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      isloading = false;
      notifyListeners();
      return false;
    }
  }

  //------------------------------------------------------------------------ sign in email and password
  Future<bool> signUpwithEmailAndPass({
    required context,
    required String yourPass,
    required String yourEmail,
  }) async {
    try {
      final credential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: yourEmail,
        password: yourPass,
      );
      if (credential.user != null) {
        // Navigator.pop(context);
        notifyListeners();
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        // print('The password provided is too weak.');
        snaki(
            context: context,
            msg: 'The password provided is too weak.',
            isErrorColor: true);

        return false;
      } else if (e.code == 'email-already-in-use') {
        // print('The account already exists for that email.');
        snaki(
            context: context,
            msg: 'The account already exists on that email',
            isErrorColor: true);
        return false;
      }
    } catch (e) {
      snaki(context: context, msg: e.toString(), isErrorColor: true);
      if (kDebugMode) {
        print(e);
      }
      // Navigator.pop(context);
    }
    return true;
  }

  //------------------------------------------------------------------------------------ Save user Data
  Future<bool> saveUserData({
    required context,
    required image,
    required String fisrtName,
    required String lastName,
    required String email,
    required String phone,
  }) async {
    try {
      CollectionReference user = FirebaseFirestore.instance.collection("users");
      //-------------------------------------------------------------------//
      String? imageDownload;
      if (image is String) {
        imageDownload = image;
      } else {
        var file = File(image.path);
        String fileName = "${DateTime.now()}.jpg";
        var isUploaded = await db
            .ref("ProfilePics")
            .child(fileName)
            .putFile(file)
            .whenComplete(() => debugPrint("imagenuploaded   ........... "));
        imageDownload = await isUploaded.ref.getDownloadURL();
        debugPrint("imagenuploaded   ........... $imageDownload");
      }
      //------------------------------------------------------------------//

      await user.doc(FirebaseAuth.instance.currentUser!.uid).set({
        "email": email,
        "firstName": fisrtName,
        "lastName": lastName,
        'phone': phone,
        "profileImage": imageDownload,
        "cash": "0",
        'dateTime': DateTime.now()
      }).whenComplete(() {
        getUserData();
        debugPrint("user data saved");
        notifyListeners();
      });
      return true;
    } catch (e) {
      return false;
    }
  }

  //-------------------------------------------------Login------------------------------------//

  Future<bool> logInwithEmailAndPassword({
    required context,
    required String yourPass,
    required String yourEmail,
  }) async {
    isloading = true;
    notifyListeners();
    try {
      final credential = await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: yourEmail, password: yourPass);

      if (credential.user != null) {
        await getUserData();
        if (userData == null) {
          snaki(
              context: context,
              msg: 'No user Data found on that email',
              isErrorColor: true);
          await FirebaseAuth.instance.signOut();
          isloading = false;
          notifyListeners();
          return false;
        } else {
          isloading = false;
          notifyListeners();
          return true;
        }
      } else {
        isloading = false;
        notifyListeners();
        return false;
      }
    } on FirebaseAuthException catch (e) {
      print("Error $e");
      print("Error code: ${e.code}");
      if (e.code == 'user-not-found') {
        print('No user found for that email.');
        snaki(context: context, msg: 'Invalid Credentials', isErrorColor: true);
        isloading = false;
        notifyListeners();
        return false;
      } else if (e.code == 'invalid-credential') {
        print('Wrong password provided for that user.');
        snaki(context: context, msg: 'Invalid Credentials', isErrorColor: true);
        isloading = false;
        notifyListeners();
        return false;
      } else {
        // Handle other FirebaseAuthException errors
        print('Authentication failed: ${e.message}');
        snaki(
            context: context, msg: 'Authentication failed', isErrorColor: true);
        isloading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      // Handle other generic exceptions
      print('Error: $e');
      snaki(
          context: context,
          msg: 'An unexpected error occurred',
          isErrorColor: true);
      isloading = false;
      notifyListeners();
      return false;
    }
  }

//-------------------------Get Data-----------------------------------------------------//
  Future<void> getUserData() async {
    isloading = true;
    userData = null;
    notifyListeners();

    try {
      var userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(FirebaseAuth.instance.currentUser!.uid)
          .get();
      if (userDoc.exists && userDoc.data() != null) {
        userData = userDoc.data() as Map<String, dynamic>;
        print(userData);
        notifyListeners();
      }
    } catch (e) {
      print('Error fetching user data: $e');
    }
    isloading = false;
    notifyListeners();
  }

  //--------------------------------------Change Password-----------------------------------------//
  Future changePassword(
      {required String currentPassword,
      required String newPassword,
      required String email,
      required context}) async {
    User? user = FirebaseAuth.instance.currentUser;

    // Reauthenticate the user with their current password
    AuthCredential credential = EmailAuthProvider.credential(
      email: email,
      password: currentPassword,
    );
    isloading = true;
    notifyListeners();
    try {
      // Reauthenticate the user
      await user!.reauthenticateWithCredential(credential);
      // Change the password
      await user.updatePassword(newPassword);
      snaki(context: context, msg: 'Password changed successfully');
      Navigator.pop(context);
      print('Password changed successfully');
    } on FirebaseAuthException catch (e) {
      Navigator.pop(context);
      print(e.code);
      if (e.code == "invalid-credential") {
        snaki(context: context, msg: 'Wrong password ', isErrorColor: true);
        print('Wrong current password: $e');
      } else {
        snaki(
            context: context,
            msg: 'Error changing password: $e',
            isErrorColor: true);
        print('Error changing password: $e');
      }
    }
    isloading = false;
    notifyListeners();
  }

  //-----------------------------------------------------------------------------Forget Password
  Future forgetPassword({required String email, required context}) async {
    isloading = true;
    notifyListeners();
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);

      snaki(
        context: context,
        msg: 'Password reset instructions sent to your email',
      );
      notifyListeners();
    } catch (e) {
      snaki(
          context: context,
          msg: e.toString().substring(30, 120),
          isErrorColor: true);
      notifyListeners();
    }
    isloading = false;
    notifyListeners();
  }

  //-------------------------------------------------------------------------GOOGLE SIGN IN
  //---------------------------------------------------------------- Sign in with google
// ...
  final FirebaseAuth _auth = FirebaseAuth.instance;
  // final GoogleSignIn googleSignIn = GoogleSignIn();
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<User?> handleGoogleSignIn() async {
    isloading = true;
    notifyListeners();
    await _googleSignIn.signOut();
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) {
        isloading = false;
        notifyListeners();
        return null;
      }
      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;
      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      final UserCredential authResult =
          await _auth.signInWithCredential(credential);
      isloading = false;
      notifyListeners();
      return authResult.user;
    } catch (e) {
      isloading = false;
      notifyListeners();
      print('Error during sign in: $e');
      return null;
    }
  }

  Future<bool> getUserDataGoogle(
      {required User user, required BuildContext context}) async {
    isloading = true;
    notifyListeners();
    try {
      final DocumentSnapshot<Map<String, dynamic>> userData =
          await _firestore.collection('users').doc(user.uid).get();
      print("User UID: ${user.uid}");
      if (userData.exists) {
        print("User Found");
        isloading = false;
        notifyListeners();
        return true;
      } else {
        print("User Not Found");

        String? displayName = user.displayName;
        String firstName = displayName?.split(' ')[0] ?? '';
        String lastName =
            displayName!.split(' ').length > 1 ? displayName.split(' ')[1] : '';

        await saveUserData(
          context: context,
          image: user.photoURL ?? "",
          fisrtName: firstName,
          lastName: lastName,
          email: user.email ?? "",
          phone: user.phoneNumber ?? "",
        );

        isloading = false;
        notifyListeners();
        return true;
      }
    } catch (e) {
      isloading = false;
      notifyListeners();
      print('Error fetching user data: $e');
      return false;
    }
  }

  // Future<bool> getUserDataGoogle({required User user, required context}) async {
  //   isloading = true;
  //   notifyListeners();
  //   try {
  //     final DocumentSnapshot<Map<String, dynamic>> userData =
  //         await _firestore.collection('users').doc(user.uid).get();
  //     print("user uidddddddddddddddddddddddddddddddd ${user.uid}");
  //     if (userData.exists) {
  //       print("user Founddddddddddddddd");
  //       isloading = false;
  //       notifyListeners();
  //       return true;
  //       // return userData.data();
  //     } else {
  //       print("user Nottttttttttttttttttttt Founddddddddddddddd");
  //       String? firstName = user.displayName?.split(' ')[0];
  //       String? lastName = user.displayName?.split(' ')[1];
  //       saveUserData(
  //           context: context,
  //           image: user.photoURL ?? "",
  //           fisrtName: firstName!,
  //           lastName: lastName!,
  //           email: user.email!,
  //           phone: user.phoneNumber ?? "");
  //       // await googleSignIn.signOut();
  //       isloading = false;
  //       notifyListeners();
  //       return true;
  //     }
  //   } catch (e) {
  //     isloading = false;
  //     notifyListeners();
  //     print('Error fetching user data: $e');
  //     return false;
  //   }
  // }

  //-----------------------Chnage Profile------------------------------------------//

  Future changeProfilePicture({
    required var imagePath,
  }) async {
    isloading = true;
    notifyListeners();
    CollectionReference user = FirebaseFirestore.instance.collection("users");
    String? imageDownload;
    var file = File(imagePath.path);
    String fileName = "${DateTime.now()}.jpg";
    var isUploaded = await db
        .ref("ProfilePics")
        .child(fileName)
        .putFile(file)
        .whenComplete(() => debugPrint("imagenuploaded   ........... "));
    imageDownload = await isUploaded.ref.getDownloadURL();
    debugPrint("imagenuploaded   ........... $imageDownload");
    await user.doc(FirebaseAuth.instance.currentUser!.uid).update({
      "profileImage": imageDownload,
    });
    isloading = false;
    notifyListeners();
  }
  //------------------Change  USER Name -----------------------//

  Future changeUserName({
    required String firstName,
    required String secondName,
  }) async {
    isloading = true;
    notifyListeners();
    CollectionReference user = FirebaseFirestore.instance.collection("users");
    await user
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .update({"firstName": firstName, "lastName": secondName});
    isloading = false;
    notifyListeners();
  }

  //------------------Change  USER Phone -----------------------//

  Future changeUserPhone({
    required String phone,
  }) async {
    isloading = true;
    notifyListeners();
    CollectionReference user = FirebaseFirestore.instance.collection("users");
    await user.doc(FirebaseAuth.instance.currentUser!.uid).update({
      "phone": phone,
    });
    isloading = false;
    notifyListeners();
  }
  //------------------------End-------------------------//
}
