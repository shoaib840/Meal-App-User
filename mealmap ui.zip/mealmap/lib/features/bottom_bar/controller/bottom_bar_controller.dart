import 'package:mealmap/utilz/constants/exports.dart';

class BottomBarProvider extends ChangeNotifier {
  int pageIndex = 0;

  changePageIndex({required int index}) {
    pageIndex = index;
    notifyListeners();
  }
}
