import 'package:mealmap/utilz/constants/exports.dart';

class BottomBar extends StatefulWidget {
  const BottomBar({super.key});

  @override
  State<BottomBar> createState() => _BottomBarState();
}

class _BottomBarState extends State<BottomBar> {
  List<Widget> pages = [
    const HomeScreen(),
    const ReservationScreen(),
    const QRViewExample(),
    const WishListScreen(),
    const CartScreen()
  ];
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;

    final bottomW = context.watch<BottomBarProvider>();
    final bottomR = context.read<BottomBarProvider>();

    return SafeArea(
        child: Scaffold(
      extendBody: true,
      body: pages[bottomW.pageIndex],
      backgroundColor: AppColors.backgroundColor,
      bottomNavigationBar: Container(
        height: h * 0.09,
        width: w,
        clipBehavior: Clip.antiAlias,
        decoration: const BoxDecoration(
            color: AppColors.blackColor,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(30), topRight: Radius.circular(30))),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            bottomBarButtons(
                iconPath: IconsApp.homeIcon,
                onTap: () {
                  bottomR.changePageIndex(index: 0);
                },
                iconColor: bottomW.pageIndex == 0
                    ? AppColors.primaryColor
                    : Colors.white),
            bottomBarButtons(
                iconPath: IconsApp.reservationIcon,
                onTap: () {
                  bottomR.changePageIndex(index: 1);
                },
                iconColor: bottomW.pageIndex == 1
                    ? AppColors.primaryColor
                    : Colors.white),
            Container(
              height: h * 0.07,
              width: w * 0.14,
              clipBehavior: Clip.antiAlias,
              decoration: const BoxDecoration(
                  color: AppColors.primaryColor, shape: BoxShape.circle),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                    onTap: () {
                      bottomR.changePageIndex(index: 2);
                    },
                    splashColor: Colors.white,
                    child: Padding(
                      padding:
                          EdgeInsets.only(left: w * 0.035, right: w * 0.035),
                      child: Image.asset(IconsApp.qrCodeIcon),
                    )),
              ),
            ),
            bottomBarButtons(
                iconPath: IconsApp.favouriteIcon,
                onTap: () {
                  bottomR.changePageIndex(index: 3);
                },
                iconColor: bottomW.pageIndex == 3
                    ? AppColors.primaryColor
                    : Colors.white),
            bottomBarButtons(
                iconPath: IconsApp.cartIcon,
                onTap: () {
                  bottomR.changePageIndex(index: 4);
                },
                iconColor: bottomW.pageIndex == 4
                    ? AppColors.primaryColor
                    : Colors.white),
          ],
        ),
      ),
    ));
  }
}

//--------------------------------BottomBar Buttons---------------------------------//

Widget bottomBarButtons(
    {required String iconPath, required onTap, required Color iconColor}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: h * 0.8,
        width: w * 0.13,
        padding: EdgeInsets.only(left: w * 0.04, right: w * 0.04),
        child: Image.asset(
          iconPath,
          color: iconColor,
        ),
      ),
    );
  });
}
