import 'package:mealmap/utilz/constants/exports.dart';

class ImagePickerController extends ChangeNotifier {
  final db = FirebaseStorage.instance;
  File? profileImage;
  final ImagePicker _picker = ImagePicker();

  Future<void> pickImage(ImageSource source) async {
    final pickedFile = await _picker.pickImage(source: source);
    if (pickedFile != null) {
      profileImage = File(pickedFile.path);
      notifyListeners();
    }
  }

  void clearImage() {
    if (profileImage != null) {
      profileImage = null;
    }
    notifyListeners();
  }

  //----------------------------------------------//
}
