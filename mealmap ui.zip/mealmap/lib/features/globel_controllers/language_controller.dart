
import 'package:mealmap/utilz/constants/exports.dart';

class LanguageControlllerr extends ChangeNotifier {
  final GetStorage _storage = GetStorage();
  static const String _languageKey = 'language';

  Locale _locale = const Locale('en'); // Default locale

  Locale get locale => _locale;

  LanguageControlllerr() {
    // Load the saved language preference from GetStorage
    String? savedLanguage = _storage.read<String>(_languageKey);
    if (savedLanguage != null) {
      _locale = Locale(savedLanguage);
    }
    // Notify listeners if locale is initialized with saved language
    notifyListeners();
  }

  void changeLanguage(String languageCode) {
    _locale = Locale(languageCode);
    _storage.write(_languageKey, languageCode);
    notifyListeners();
  }
}
