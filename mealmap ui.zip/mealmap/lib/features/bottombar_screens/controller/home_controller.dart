import 'package:mealmap/utilz/constants/exports.dart';

class HomeController extends ChangeNotifier {
  int methodSelectedIndex = -1;
  String methodSelectedName = '';
  updatemethodSelectedIndex({required int index, required String methodName}) {
    methodSelectedIndex = index;
    methodSelectedName = methodName;
    notifyListeners();
  }
}
