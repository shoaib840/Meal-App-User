import 'dart:developer';
import 'package:mealmap/utilz/constants/exports.dart';

import 'package:qr_code_scanner/qr_code_scanner.dart';

class QRViewExample extends StatefulWidget {
  const QRViewExample({super.key});

  @override
  State<StatefulWidget> createState() => _QRViewExampleState();
}

class _QRViewExampleState extends State<QRViewExample> {
  Barcode? result;
  QRViewController? controller;
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');

  // In order to get hot reload to work we need to pause the camera if the platform
  // is android, or resume the camera if the platform is iOS.
  @override
  void reassemble() {
    super.reassemble();
    if (controller != null) {
      if (Platform.isAndroid) {
        controller!.pauseCamera();
      } else if (Platform.isIOS) {
        controller!.resumeCamera();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.backgroundColor,
        body: SizedBox(
          height: h,
          width: w,
          child: Column(
            children: [
              SizedBox(
                height: h * 0.7,
                width: w,
                child: _buildQrView(context),
              ),
              SizedBox(
                height: h * 0.02,
              ),
              // Expanded(flex: 4, child: _buildQrView(context)),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (result != null)
                      appText(myText: result!.code!, isbold: true)
                    // Text(
                    //     'Barcode Type: ${describeEnum(result!.format)}   Data: ${result!.code}')
                    else
                      appText(
                        myText: "Scan QR",
                        isbold: true,
                        myColors: AppColors.primaryColor,
                        myfontSize: 16,
                      ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        SizedBox(
                          height: h * 0.065,
                          width: w * 0.45,
                          child: FutureBuilder(
                            future: controller?.getFlashStatus(),
                            builder: (context, snapshot) {
                              String buttonText;
                              if (snapshot.connectionState ==
                                  ConnectionState.waiting) {
                                buttonText =
                                    "Flash"; // Show Flash while waiting for the future to resolve
                              } else if (snapshot.hasData) {
                                if (snapshot.data == true) {
                                  buttonText = "Flash: On";
                                } else if (snapshot.data == false) {
                                  buttonText = "Flash: Off";
                                } else {
                                  buttonText = "Flash";
                                }
                              } else {
                                buttonText = "Flash";
                              }
                              return appButton(
                                buttonText: buttonText,
                                ontapfunction: () async {
                                  await controller?.toggleFlash();
                                  setState(() {});
                                },
                              );
                            },
                          ),
                        ),
                        SizedBox(
                          height: h * 0.065,
                          width: w * 0.45,
                          child: FutureBuilder(
                            future: controller?.getCameraInfo(),
                            builder: (context, snapshot) {
                              String buttonText;
                              if (snapshot.connectionState ==
                                  ConnectionState.waiting) {
                                buttonText =
                                    "Loading..."; // Show while waiting for the future to resolve
                              } else if (snapshot.hasData) {
                                if (snapshot.data == CameraFacing.back) {
                                  buttonText = "Front Camera";
                                } else if (snapshot.data ==
                                    CameraFacing.front) {
                                  buttonText = "Back Camera";
                                } else {
                                  buttonText = "Unknown Camera";
                                }
                              } else {
                                buttonText = "Error";
                              }
                              return appButton(
                                buttonText: buttonText,
                                ontapfunction: () async {
                                  await controller?.flipCamera();
                                  setState(() {});
                                },
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.center,
                    //   crossAxisAlignment: CrossAxisAlignment.center,
                    //   children: <Widget>[
                    //     Container(
                    //       margin: const EdgeInsets.all(8),
                    //       child: ElevatedButton(
                    //         onPressed: () async {
                    //           await controller?.pauseCamera();
                    //         },
                    //         child: const Text('pause',
                    //             style: TextStyle(fontSize: 20)),
                    //       ),
                    //     ),
                    //     Container(
                    //       margin: const EdgeInsets.all(8),
                    //       child: ElevatedButton(
                    //         onPressed: () async {
                    //           await controller?.resumeCamera();
                    //         },
                    //         child: const Text('resume',
                    //             style: TextStyle(fontSize: 20)),
                    //       ),
                    //     )
                    //   ],
                    // ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQrView(BuildContext context) {
    // For this example we check how width or tall the device is and change the scanArea and overlay accordingly.
    var scanArea = (MediaQuery.of(context).size.width < 400 ||
            MediaQuery.of(context).size.height < 400)
        ? 250.0
        : 350.0;
    // To ensure the Scanner view is properly sizes after rotation
    // we need to listen for Flutter SizeChanged notification and update controller
    return QRView(
      key: qrKey,
      onQRViewCreated: _onQRViewCreated,
      overlay: QrScannerOverlayShape(
          borderColor: AppColors.primaryColor,
          borderRadius: 10,
          borderLength: 30,
          borderWidth: 10,
          cutOutSize: scanArea),
      onPermissionSet: (ctrl, p) => _onPermissionSet(context, ctrl, p),
    );
  }

  void _onQRViewCreated(QRViewController controller) {
    setState(() {
      this.controller = controller;
    });
    controller.scannedDataStream.listen((scanData) {
      setState(() {
        result = scanData;
      });
    });
  }

  void _onPermissionSet(BuildContext context, QRViewController ctrl, bool p) {
    log('${DateTime.now().toIso8601String()}_onPermissionSet $p');
    if (!p) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('no Permission')),
      );
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }
}
