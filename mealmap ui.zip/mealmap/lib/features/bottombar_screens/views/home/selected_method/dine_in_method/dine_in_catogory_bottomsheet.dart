import 'package:mealmap/utilz/constants/exports.dart';

class DineInCotogoryBottomSheet extends StatefulWidget {
  const DineInCotogoryBottomSheet({super.key});

  @override
  State<DineInCotogoryBottomSheet> createState() =>
      _DineInCotogoryBottomSheetState();
}

class _DineInCotogoryBottomSheetState extends State<DineInCotogoryBottomSheet> {
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primaryColor, // Header background color
              onPrimary: AppColors.whiteColor, // Header text color
              onSurface: AppColors.primaryColor, // Body text color
            ),
            dialogBackgroundColor: AppColors.primaryColor, // Background color
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }
  //--------------------------------------------------//

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primaryColor, // Header background color
              onPrimary: Colors.white, // Header text color
              onSurface: AppColors.primaryColor, // Body text color
            ),
            dialogBackgroundColor: AppColors.primaryColor, // Background color
          ),
          child: child!,
        );
      },
    );
    if (pickedTime != null && pickedTime != _selectedTime) {
      setState(() {
        _selectedTime = pickedTime;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: const BoxDecoration(
            color: AppColors.whiteColor,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15), topRight: Radius.circular(15))),
        margin: EdgeInsets.only(
          left: w * 0.04,
          right: w * 0.04,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        height: h * 0.55,
        child: Column(
          children: [
            SizedBox(
              height: h * 0.06,
              width: w,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: w * 0.1,
                  ),
                  appText(myText: "Select food category", isbold: true),
                  IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.close))
                ],
              ),
            ),
            //------------------------------------------------------------------//
            SizedBox(
              height: h * 0.095,
              width: w,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    for (int i = 0; i < 20; i++) ...{
                      SizedBox(
                        height: h * 0.1,
                        width: w * 0.2,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                              height: h * 0.065,
                              width: w * 0.2,
                              child: Image.asset(ImagesApp.foodImage),
                            ),
                            appText(myText: "Italian", isbold: true)
                          ],
                        ),
                      ),
                    }
                  ],
                ),
              ),
            ),
            SizedBox(
              height: h * 0.02,
            ),
            //-----------------------------------------------------------------------------------------------//
            appText(myText: "Select time for reservation", isbold: true),
            SizedBox(
              height: h * 0.02,
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                    height: h * 0.065,
                    width: w * 0.35,
                    child: appButton(
                        buttonText: _selectedDate == null
                            ? "Select Date"
                            : _selectedDate.toString().substring(0, 10),
                        ontapfunction: () {
                          _selectDate(context);
                        })),
                SizedBox(
                    height: h * 0.065,
                    width: w * 0.35,
                    child: appButton(
                        buttonText: _selectedTime == null
                            ? "Select Time"
                            : _selectedTime!.format(context).toString(),
                        ontapfunction: () {
                          _selectTime(context);
                        }))
              ],
            ),
            SizedBox(
              height: h * 0.02,
            ),
            customTextField(
              mYhintText: "Persons",
              keyBordType: TextInputType.number,
            ),
            const Spacer(),
            SizedBox(
              height: h * 0.065,
              width: w,
              child: appButton(buttonText: "Search", ontapfunction: () {
                Navigator.push(context, createRoute(newPage: const MapOfDineInSearch()));
              }),
            )
          ],
        ),
      ),
    );
  }
}
