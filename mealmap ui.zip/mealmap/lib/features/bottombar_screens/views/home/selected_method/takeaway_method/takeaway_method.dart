import 'package:mealmap/utilz/constants/exports.dart';

class TakeawayMethod extends StatefulWidget {
  const TakeawayMethod({super.key});

  @override
  State<TakeawayMethod> createState() => _TakeawayMethodState();
}

class _TakeawayMethodState extends State<TakeawayMethod> {
  GoogleMapController? controller;
  static const LatLng _center =
      LatLng(37.7749, -122.4194); // San Francisco coordinates

  final Set<Marker> markers = {
    const Marker(
      markerId: MarkerId('defaultMarker'),
      position: _center,
      infoWindow: InfoWindow(title: 'San Francisco'),
      icon: BitmapDescriptor.defaultMarker,
    ),
  };
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Column(
      children: [
        SizedBox(
          height: h * 0.08,
          width: w,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              appText(
                  myText: appLocal!.viewonmap, // "View on map",
                  isbold: true,
                  myfontSize: 18),
              appText(
                  myText:
                      appLocal.selectatakeawayspot, //"Select a takeaway spot",
                  isbold: true,
                  myColors: AppColors.greyColor),
            ],
          ),
        ),
        Container(
          height: h * 0.2,
          width: w,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: GoogleMap(
              initialCameraPosition: const CameraPosition(
                target: _center,
                zoom: 13,
              ),
              markers: markers,
              onMapCreated: (GoogleMapController controller) {
                controller = controller;
              },
            ),
          ),
        ),
      ],
    );
  }
}
