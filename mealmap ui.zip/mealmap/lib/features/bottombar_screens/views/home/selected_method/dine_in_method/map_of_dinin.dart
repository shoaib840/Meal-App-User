import 'package:mealmap/utilz/constants/exports.dart';

class MapOfDineInSearch extends StatefulWidget {
  const MapOfDineInSearch({super.key});

  @override
  State<MapOfDineInSearch> createState() => _MapOfDineInSearchState();
}

class _MapOfDineInSearchState extends State<MapOfDineInSearch> {
  Set<Marker> _markers = <Marker>{};

  @override
  void initState() {
    super.initState();
    // Add sample markers
    _markers.add(
      Marker(
        markerId: MarkerId('restaurant1'),
        position: LatLng(32.4279, 53.6880), // Sample coordinates
        infoWindow: InfoWindow(
          title: 'Restaurant 1',
          snippet: 'Best restaurant in town',
        ),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
      ),
    );
    _markers.add(
      Marker(
        markerId: MarkerId('restaurant2'),
        position: LatLng(32.4278, 53.6885), // Sample coordinates
        infoWindow: InfoWindow(
          title: 'Restaurant 2',
          snippet: 'Another great spot',
        ),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
      ),
    );
    // Add more markers as needed
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;

    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.backgroundColor,
        body: Column(
          children: [
            SizedBox(
              height: h * 0.01,
            ),
            Row(
              children: [
                arrowBack(),
                SizedBox(
                  width: w * 0.02,
                ),
                appText(myText: "Map", isbold: true),
              ],
            ),
            SizedBox(
              height: h * 0.01,
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: w * 0.02),
              height: h * 0.07,
              width: w,
              child: Row(
                children: [
                  SizedBox(
                    width: w * 0.65,
                    child: customTextField(
                      prefixIcon: Icons.search,
                      mYhintText: "Restaurant name, dish name",
                      keyBordType: TextInputType.name,
                    ),
                  ),
                  SizedBox(
                    width: w * 0.02,
                  ),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {},
                      child: Container(
                        height: h * 0.062,
                        decoration: BoxDecoration(
                          color: AppColors.secondaryColor,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Center(
                          child: appText(
                            myText: "Takeaway",
                            isbold: true,
                            myfontSize: 10,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: h * 0.02,
            ),
            Expanded(
              child: GoogleMap(
                initialCameraPosition: const CameraPosition(
                    target: LatLng(32.4279, 53.6880), zoom: 15),
                markers: _markers,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
