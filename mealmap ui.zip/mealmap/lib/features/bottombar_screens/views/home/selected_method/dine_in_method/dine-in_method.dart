import 'package:mealmap/utilz/constants/exports.dart';

class DineInMethod extends StatefulWidget {
  const DineInMethod({super.key});

  @override
  State<DineInMethod> createState() => _DineInMethodState();
}

class _DineInMethodState extends State<DineInMethod> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SizedBox(
      width: w,
      // color: Colors.red,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              appText(
                  myText: appLocal!.setcriteria, //"Set criteria",
                  isbold: true,
                  myfontSize: 18),
              Container(
                height: 30,
                width: 30,
                decoration: const BoxDecoration(
                    color: AppColors.secondaryColor, shape: BoxShape.circle),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                      onTap: () {
                        showModalBottomSheet(
                          backgroundColor: Colors.transparent,
                          isScrollControlled: true,
                          context: context,
                          builder: (BuildContext context) {
                            return const DineInCotogoryBottomSheet();
                          },
                        );
                      },
                      splashColor: AppColors.whiteColor,
                      child: Padding(
                        padding: const EdgeInsets.all(6.0),
                        child: Image.asset(IconsApp.dineinlocationIcon),
                      )),
                ),
              )
            ],
          ),
          appText(
              myText: appLocal
                  .searchadineinspotbasedonyourcriteria, //"Search a dine-in spot based on your criteria",
              myColors: AppColors.greyColor,
              isbold: true),
          SizedBox(
            height: h * 0.01,
          ),
          Container(
            padding: EdgeInsets.symmetric(
                horizontal: w * 0.015, vertical: h * 0.005),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: AppColors.secondaryColor),
            child: appText(myText: "${appLocal.step} 1", isbold: true),
          ),
          SizedBox(
            height: h * 0.01,
          ),
          appText(
              myText: appLocal
                  .choosethedatetimeandnumberofguestsyouwanttoreserveatablefor, // "Choose the date, time and number of guests you want to reserve a table for.",
              isbold: true),
          SizedBox(
            height: h * 0.01,
          ),
          Container(
            padding: EdgeInsets.symmetric(
                horizontal: w * 0.015, vertical: h * 0.005),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: AppColors.secondaryColor),
            child: appText(myText: "${appLocal.step} 2", isbold: true),
          ),
          SizedBox(
            height: h * 0.01,
          ),
          appText(
              myText: appLocal
                  .selectarestaurantofyourchoicefromthelistshownonmap, // "Select a restaurant of your choice from the list shown on map.",
              isbold: true),
          SizedBox(
            height: h * 0.01,
          ),
        ],
      ),
    );
  }
}
