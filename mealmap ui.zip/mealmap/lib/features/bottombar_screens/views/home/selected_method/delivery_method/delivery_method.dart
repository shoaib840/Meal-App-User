import 'package:mealmap/utilz/constants/exports.dart';

class DeliveryMethod extends StatefulWidget {
  const DeliveryMethod({super.key});

  @override
  State<DeliveryMethod> createState() => _DeliveryMethodState();
}

class _DeliveryMethodState extends State<DeliveryMethod> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Column(
      children: [
        SizedBox(
          height: h * 0.1,
          width: w,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: h * 0.06,
                width: w,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    appText(
                        myText: appLocal!.recentlyviewed, //"Recently viewed",
                        isbold: true,
                        myfontSize: 14),
                    SizedBox(
                      height: h * 0.045,
                      width: w * 0.2,
                      child: appButton(
                          boxShadow: false,
                          buttonColor: AppColors.yellowColor,
                          buttonText: appLocal.clear, //"Clear",
                          borderColor: AppColors.yellowColor,
                          ontapfunction: () {}),
                    )
                  ],
                ),
              ),
              appText(
                  myText: appLocal
                      .revisittherestaurantyouwereexploring, //"Revisit the restaurant you were exploring",
                  isbold: true,
                  myfontSize: 9,
                  myColors: AppColors.greyColor)
            ],
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              for (int i = 0; i < 10; i++) ...{
                resturantsWidget(
                    onTap: () {
                      Navigator.push(context,
                          createRoute(newPage: const ResturantsDetailScreen()));
                    },
                    resturantImagePath: ImagesApp.resturantImage,
                    resturantFood: "Asian",
                    resturantName: "BigBang IV",
                    location: "75008, Paris",
                    rating: "9.2",
                    price: "\$222",
                    kmaway: "5 Km",
                    awayinTime: "10m")
              }
            ],
          ),
        ),
      ],
    );
  }
}
