import 'package:mealmap/utilz/constants/exports.dart';

class LocationSelectedScreen extends StatefulWidget {
  const LocationSelectedScreen({super.key});

  @override
  State<LocationSelectedScreen> createState() => _LocationSelectedScreenState();
}

class _LocationSelectedScreenState extends State<LocationSelectedScreen> {
  List listOfCountry = [
    {"flag": IconsApp.locationIcon, "name": "Current location"},
    {"flag": IconsApp.spainFlagIcon, "name": "Madrid, Spain"},
    {"flag": IconsApp.franceFlagIcon, "name": "Paris, France"},
    {"flag": IconsApp.italyFlagIcon, "name": "Rome, Italy"},
    {"flag": IconsApp.germanyFlagIcon, "name": "Berlin, Germany"},
    {"flag": IconsApp.portugalFlagIcon, "name": "Lisbon, Portugal"},
  ];

  int selectedIndex = -1;
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              height: h,
              width: w,
              padding: EdgeInsets.symmetric(horizontal: w * 0.02),
              child: Column(
                children: [
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Row(
                    children: [
                      arrowBack(),
                      SizedBox(
                        width: w * 0.02,
                      ),
                      appText(myText: "Select city", isbold: true),
                    ],
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  customTextField(
                      prefixIcon: Icons.search,
                      mYhintText: "Address, city",
                      keyBordType: TextInputType.name),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Expanded(
                      child: SingleChildScrollView(
                    child: Column(
                      children: [
                        for (int i = 0; i < listOfCountry.length; i++) ...{
                          GestureDetector(
                              onTap: () {
                                selectedIndex = i;
                                setState(() {});
                              },
                              child: Container(
                                margin: EdgeInsets.only(bottom: h * 0.01),
                                height: h * 0.06,
                                width: w,
                                decoration: BoxDecoration(
                                    color: selectedIndex == i
                                        ? AppColors.secondaryColor
                                        : AppColors.whiteColor,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Row(
                                  children: [
                                    SizedBox(
                                      width: w * 0.02,
                                    ),
                                    SizedBox(
                                      height: h * 0.03,
                                      width: w * 0.06,
                                      child:
                                          Image.asset(listOfCountry[i]['flag']),
                                    ),
                                    SizedBox(
                                      width: w * 0.1,
                                    ),
                                    appText(
                                        myText: listOfCountry[i]['name'],
                                        isbold: true,
                                        myfontSize: 10)
                                  ],
                                ),
                              ))
                        }
                      ],
                    ),
                  ))
                ],
              ),
            )));
  }
}
