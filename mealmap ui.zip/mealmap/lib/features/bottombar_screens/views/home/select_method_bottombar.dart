import 'package:mealmap/utilz/constants/exports.dart';

class SelectMethodBottomBarHome extends StatefulWidget {
  const SelectMethodBottomBarHome({super.key});

  @override
  State<SelectMethodBottomBarHome> createState() =>
      _SelectMethodBottomBarHomeState();
}

class _SelectMethodBottomBarHomeState extends State<SelectMethodBottomBarHome> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final homeR = context.read<HomeController>();
    final homeW = context.watch<HomeController>();
    final appLocal = AppLocalizations.of(context);

    List selectMethodType = [
      {"name": appLocal!.delivery, "iconPath": IconsApp.deliveryIcon},
      {"name": appLocal.takeaway, "iconPath": IconsApp.takeawayIcon},
      {"name": appLocal.dinein, "iconPath": IconsApp.dineinIcon}
    ];
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: const BoxDecoration(
            color: AppColors.backgroundColor,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15), topRight: Radius.circular(15))),
        margin: EdgeInsets.only(
          left: w * 0.04,
          right: w * 0.04,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        height: h * 0.4,
        width: w,
        child: Column(
          children: [
            SizedBox(
              height: h * 0.06,
              width: w,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: w * 0.1,
                  ),
                  appText(
                      myText: appLocal
                          .selectinteractionmethod, // "Select interaction method",
                      isbold: true),
                  IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.close))
                ],
              ),
            ),
            SizedBox(
              height: h * 0.02,
            ),
            for (int i = 0; i < selectMethodType.length; i++) ...{
              homeBottomBarWidget(
                  onTap: () async {
                    await homeR.updatemethodSelectedIndex(
                        index: i, methodName: selectMethodType[i]['name']);
                    // ignore: use_build_context_synchronously
                    Navigator.pop(context);
                  },
                  iconPath: selectMethodType[i]['iconPath'],
                  name: selectMethodType[i]['name'],
                  color: homeW.methodSelectedIndex == i
                      ? AppColors.secondaryColor
                      : Colors.white)
            }
          ],
        ),
      ),
    );
  }
}

Widget homeBottomBarWidget(
    {required onTap,
    required String iconPath,
    required String name,
    required color}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: h * 0.08,
        width: w,
        padding: EdgeInsets.symmetric(horizontal: w * 0.02),
        decoration: BoxDecoration(
            color: color, borderRadius: BorderRadius.circular(10)),
        child: Row(
          children: [
            SizedBox(
              height: h * 0.03,
              width: w * 0.06,
              child: Image.asset(iconPath),
            ),
            SizedBox(
              width: w * 0.04,
            ),
            appText(myText: name, isbold: true, myfontSize: 13)
          ],
        ),
      ),
    );
  });
}
