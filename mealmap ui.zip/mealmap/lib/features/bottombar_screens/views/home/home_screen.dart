import 'package:mealmap/utilz/constants/exports.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final homeW = context.watch<HomeController>();
    final authsWatch = context.watch<AuthssController>();
    final appLocal = AppLocalizations.of(context);
    return SizedBox(
      height: h,
      width: w,
      child: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: h * 0.01,
            ),
            Container(
              padding: EdgeInsets.only(left: w * 0.02, right: w * 0.02),
              child: Column(
                children: [
                  SizedBox(
                    height: h * 0.06,
                    width: w,
                    child: Row(
                      children: [
                        Container(
                          height: h * 0.05,
                          width: w * 0.15,
                          padding: EdgeInsets.all(
                              authsWatch.userData!['profileImage'] != ""
                                  ? 0
                                  : 8),
                          clipBehavior: Clip.antiAlias,
                          decoration: BoxDecoration(
                              color: AppColors.blueColor.withOpacity(0.3),
                              shape: BoxShape.circle),
                          child: authsWatch.userData!['profileImage'] != ""
                              ? Image.network(
                                  fit: BoxFit.cover,
                                  authsWatch.userData!['profileImage'])
                              : Image.asset(
                                  IconsApp.personIcon,
                                  color: AppColors.blueColor,
                                ),
                        ),
                        SizedBox(
                          width: w * 0.02,
                        ),
                        appText(myText: "753637, Paris", isbold: true),
                        IconButton(
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  createRoute(
                                      newPage: const LocationSelectedScreen()));
                            },
                            icon:
                                const Icon(Icons.keyboard_arrow_down_rounded)),
                        const Spacer(),
                        //-----------------------------
                        Container(
                          height: h * 0.05,
                          width: w * 0.1,
                          clipBehavior: Clip.antiAlias,
                          decoration: BoxDecoration(
                              color: AppColors.primaryColor.withOpacity(0.3),
                              shape: BoxShape.circle),
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    createRoute(
                                        newPage: const DeliveryDetailScreen()));
                              },
                              splashColor: AppColors.whiteColor,
                              child: Center(
                                child: Icon(
                                  Icons.my_location_sharp,
                                  size: w * 0.05,
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: w * 0.02,
                        ),

                        //---------------------------------------
                        Container(
                          height: h * 0.05,
                          width: w * 0.1,
                          clipBehavior: Clip.antiAlias,
                          decoration: BoxDecoration(
                              color: AppColors.primaryColor.withOpacity(0.3),
                              shape: BoxShape.circle),
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () {},
                              splashColor: AppColors.whiteColor,
                              child: Center(
                                child: Icon(
                                  Icons.notifications_none_outlined,
                                  size: w * 0.05,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  //---------------------------------------------------------------------------------------//
                  SizedBox(
                    height: h * 0.01,
                  ),
                  SizedBox(
                    height: h * 0.07,
                    width: w,
                    child: Row(
                      children: [
                        SizedBox(
                          width: w * 0.65,
                          child: customTextField(
                              prefixIcon: Icons.search,
                              mYhintText: appLocal!
                                  .restaurantname, // "Restaurant name",
                              keyBordType: TextInputType.name),
                        ),
                        SizedBox(
                          width: w * 0.02,
                        ),
                        Expanded(
                          child: GestureDetector(
                            onTap: () {
                              showModalBottomSheet(
                                backgroundColor: Colors.transparent,
                                isScrollControlled: true,
                                context: context,
                                builder: (BuildContext context) {
                                  return const SelectMethodBottomBarHome();
                                },
                              );
                            },
                            child: Container(
                              height: h * 0.062,
                              decoration: BoxDecoration(
                                  color: AppColors.secondaryColor,
                                  borderRadius: BorderRadius.circular(30)),
                              child: Center(
                                  child: appText(
                                      textAlign: TextAlign.center,
                                      myText: homeW.methodSelectedName == ''
                                          ? appLocal
                                              .selectmethod //"Select Method"
                                          : homeW.methodSelectedName,
                                      isbold: true,
                                      myfontSize: 10)),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  //----------------------------------------------------------//
                  SizedBox(
                    height: h * 0.02,
                  ),
                  SizedBox(
                    height: h * 0.095,
                    width: w,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          for (int i = 0; i < 20; i++) ...{
                            SizedBox(
                              height: h * 0.1,
                              width: w * 0.2,
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  SizedBox(
                                    height: h * 0.065,
                                    width: w * 0.2,
                                    child: Image.asset(ImagesApp.foodImage),
                                  ),
                                  appText(myText: "Italian", isbold: true)
                                ],
                              ),
                            ),
                          }
                        ],
                      ),
                    ),
                  ),
                  //--------------------------------------------------------------------------//
                  SizedBox(
                    height: h * 0.02,
                  ),
                  //------------------------------------------------------------------------------------//

                  homeW.methodSelectedIndex == 1
                      ? const TakeawayMethod()
                      : homeW.methodSelectedIndex == 2
                          ? const DineInMethod()
                          : const DeliveryMethod(),

                  //--------------------------------------------------------------------------------------//

                  SizedBox(
                    height: h * 0.02,
                  ),
                  SizedBox(
                    height: h * 0.1,
                    width: w,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: h * 0.06,
                          width: w,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              appText(
                                  myText: appLocal
                                      .wethinkyoulllike, // "We think you’ll like...",
                                  isbold: true,
                                  myfontSize: 11),
                              SizedBox(
                                height: h * 0.047,
                                width: w * 0.3,
                                child: appButton(
                                    boxShadow: false,
                                    buttonColor: AppColors.yellowColor,
                                    borderColor: AppColors.yellowColor,
                                    buttonText: appLocal.seemore, //"See more",
                                    ontapfunction: () {}),
                              )
                            ],
                          ),
                        ),
                        appText(
                            myText: appLocal
                                .recommendedspotsforyou, // "Recommended spots for you",
                            myColors: AppColors.greyColor,
                            myfontSize: 9,
                            isbold: true)
                      ],
                    ),
                  ),
                  //----------------------------------------------------------------------------------//
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        for (int i = 0; i < 10; i++) ...{
                          resturantsWidget(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    createRoute(
                                        newPage:
                                            const ResturantsDetailScreen()));
                              },
                              resturantImagePath: ImagesApp.resturantImage,
                              resturantFood: "Asian",
                              resturantName: "BigBang IV",
                              location: "75008, Paris",
                              rating: "9.2",
                              price: "\$222",
                              kmaway: "5 Km",
                              awayinTime: "10m")
                        }
                      ],
                    ),
                  ),
                ],
              ),
            ),

            //----------------------------------------------------------------------------//
            SizedBox(
              height: h * 0.02,
            ),
            Container(
              width: w,
              color: AppColors.yellowColor,
              padding: EdgeInsets.only(left: w * 0.02, right: w * 0.02),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: h * 0.02,
                  ),
                  appText(
                      myText: "${appLocal.upto} 50% ${appLocal.off}",
                      isbold: true,
                      myfontSize: 18),
                  appText(
                      myText: appLocal
                          .findthebestoffersatselectedrestaurants, //"Find the best offers at selected restaurants",
                      myColors: AppColors.greyColor,
                      isbold: true),
                  SizedBox(
                    height: h * 0.04,
                  ),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        for (int i = 0; i < 10; i++) ...{
                          resturantsWidget(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    createRoute(
                                        newPage:
                                            const ResturantsDetailScreen()));
                              },
                              resturantImagePath: ImagesApp.resturantImage,
                              resturantFood: "Asian",
                              resturantName: "BigBang IV",
                              location: "75888, Paris",
                              rating: "9.2",
                              price: "\$22",
                              kmaway: "5 Km",
                              awayinTime: "10m")
                        }
                      ],
                    ),
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: h * 0.1,
            ),
          ],
        ),
      ),
    );
  }
}
