import 'package:mealmap/utilz/constants/exports.dart';

class BottomSheetItemSelectedOfResturant extends StatefulWidget {
  const BottomSheetItemSelectedOfResturant({super.key});

  @override
  State<BottomSheetItemSelectedOfResturant> createState() =>
      _BottomSheetItemSelectedOfResturantState();
}

class _BottomSheetItemSelectedOfResturantState
    extends State<BottomSheetItemSelectedOfResturant> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Container(
      width: w,
      height: h * 0.93,
      padding: EdgeInsets.symmetric(horizontal: w * 0.02, vertical: h * 0.005),
      decoration: const BoxDecoration(
          color: AppColors.whiteColor,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(15), topRight: Radius.circular(15))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              IconButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: const Icon(Icons.close))
            ],
          ),
          SizedBox(
            height: h * 0.2,
            width: w,
            child: Image.asset(IconsApp.menuDishIcon),
          ),
          appText(myText: "Spaghetti", isbold: true, myfontSize: 18),
          SizedBox(
            height: h * 0.01,
          ),
          Container(
            decoration: BoxDecoration(
                color: AppColors.secondaryColor,
                borderRadius: BorderRadius.circular(30)),
            padding:
                EdgeInsets.symmetric(horizontal: w * 0.02, vertical: h * 0.005),
            child: appText(myText: "\$25", isbold: true),
          ),
          SizedBox(
            height: h * 0.01,
          ),
          SizedBox(
            height: h * 0.09,
            width: w,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  for (int i = 0; i < 10; i++) ...{
                    orderByWidget(
                        itemNumber: "#${i + 1}",
                        firstText:
                            "${appLocal!.orderedby} 20+ ${appLocal.others}",
                        secondText: "Barbecue sauce, Chilli sauce")
                  }
                ],
              ),
            ),
          ),
          SizedBox(
            height: h * 0.01,
          ),
          SizedBox(
            height: h * 0.06,
            width: w,
            child: Row(
              children: [
                SizedBox(
                  height: h * 0.6,
                  width: w * 0.8,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      appText(
                          myText: appLocal!.sauce, //"Sauce",
                          isbold: true,
                          myfontSize: 14),
                      appText(myText: appLocal.chooseany2sauces)
                    ],
                  ),
                ),
                Expanded(
                    child: Center(
                  child: Container(
                    height: 25,
                    width: 25,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.greyColor.withOpacity(0.2)),
                    child: Center(child: appText(myText: "0")),
                  ),
                ))
              ],
            ),
          ), //---------------------------------------------------------------------//
          Divider(
            color: AppColors.greyColor.withOpacity(0.2),
            thickness: 2,
          ),

          SizedBox(
            height: h * 0.01,
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: w * 0.02),
            height: h * 0.25,
            width: w,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  for (int i = 0; i < 20; i++) ...{
                    resturantMenuItems(
                        onitemClick: () {},
                        dishImagePath: ImagesApp.cilliSouseImage,
                        dishName: "Ice Cold Pepsi",
                        percent: " 88%",
                        totalOrder: "(218)",
                        backgroundColour: AppColors.greyColor.withOpacity(0.1),
                        addOnTap: () {})
                  }
                ],
              ),
            ),
          ),
          SizedBox(
            height: h * 0.01,
          ),
          Row(
            children: [
              Container(
                height: h * 0.03,
                width: w * 0.08,
                decoration: const BoxDecoration(
                    color: AppColors.secondaryColor, shape: BoxShape.circle),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                      onTap: () {},
                      splashColor: AppColors.whiteColor,
                      child: Center(child: appText(myText: "+", isbold: true))),
                ),
              ),
              SizedBox(
                width: w * 0.02,
              ),
              appText(
                  myText: "2 ${appLocal.piece}", isbold: true, myfontSize: 14),
              SizedBox(
                width: w * 0.02,
              ),
              Container(
                height: h * 0.03,
                width: w * 0.08,
                decoration: const BoxDecoration(
                    color: AppColors.secondaryColor, shape: BoxShape.circle),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                      onTap: () {},
                      splashColor: AppColors.whiteColor,
                      child: Center(child: appText(myText: "+", isbold: true))),
                ),
              )
            ],
          ),
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: h * 0.05,
                width: w * 0.8,
                child: appButton(
                    buttonText: appLocal.addtocart, //"Add to cart",
                    ontapfunction: () {}),
              ),
            ],
          )
        ],
      ),
    );
  }
}

Widget orderByWidget({
  required String itemNumber,
  required String firstText,
  required String secondText,
}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Container(
      height: h * 0.08,
      width: w * 0.7,
      margin: EdgeInsets.only(right: w * 0.02),
      padding: EdgeInsets.symmetric(horizontal: w * 0.01),
      decoration: BoxDecoration(
          color: AppColors.secondaryColor,
          borderRadius: BorderRadius.circular(15)),
      child: Row(
        children: [
          Container(
            decoration: BoxDecoration(
                color: AppColors.primaryColor,
                borderRadius: BorderRadius.circular(20)),
            padding:
                EdgeInsets.symmetric(horizontal: w * 0.02, vertical: h * 0.005),
            child: appText(myText: itemNumber, isbold: true),
          ),
          SizedBox(
            width: w * 0.015,
          ),
          Expanded(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              appText(myText: firstText, isbold: true),
              appText(myText: secondText, myfontSize: 10)
            ],
          ))
        ],
      ),
    );
  });
}
