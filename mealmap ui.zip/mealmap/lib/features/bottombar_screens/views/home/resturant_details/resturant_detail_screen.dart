import 'package:mealmap/utilz/constants/exports.dart';

class ResturantsDetailScreen extends StatefulWidget {
  const ResturantsDetailScreen({super.key});

  @override
  State<ResturantsDetailScreen> createState() => _ResturantsDetailScreenState();
}

class _ResturantsDetailScreenState extends State<ResturantsDetailScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  List<String> listOfImages = [
    ImagesApp.newResturantImage,
    ImagesApp.newResturantImage,
    ImagesApp.newResturantImage,
    ImagesApp.newResturantImage,
  ];
  int imageIndex = 0;
  PageController pageController = PageController();
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _startTimer();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 2), (Timer timer) {
      if (imageIndex < listOfImages.length - 1) {
        imageIndex++;
      } else {
        imageIndex = 0;
      }

      pageController.animateToPage(
        imageIndex,
        duration: const Duration(seconds: 1),
        curve: Curves.easeIn,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _tabController.dispose();
    pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.backgroundColor,
        body: SizedBox(
          height: h,
          width: w,
          child: Column(
            children: [
              Stack(
                children: [
                  SizedBox(
                    height: h * 0.25,
                    width: w,
                    child: PageView.builder(
                      controller: pageController,
                      onPageChanged: (index) {
                        setState(() {
                          imageIndex = index;
                        });
                      },
                      itemCount: listOfImages.length,
                      itemBuilder: (context, index) {
                        return Image.asset(
                          listOfImages[index],
                          fit: BoxFit.fill,
                        );
                      },
                    ),
                  ),
                  Positioned(left: 10, top: 10, child: arrowBack())
                ],
              ),
              SizedBox(
                height: h * 0.01,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (int i = 0; i < listOfImages.length; i++)
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: const EdgeInsets.symmetric(horizontal: 4.0),
                      width: imageIndex == i ? 6.0 : 4.0,
                      height: imageIndex == i ? 6.0 : 4.0,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: imageIndex == i
                            ? AppColors.blackColor
                            : AppColors.greyColor,
                      ),
                    ),
                ],
              ),
              //--------------------------------------------------------//
              SizedBox(
                height: h * 0.02,
              ),
              Container(
                height: h * 0.05,
                width: w * 0.98,
                decoration: BoxDecoration(
                  color: AppColors.primaryColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: TabBar(
                  dividerColor: Colors.transparent,
                  indicatorColor: AppColors.blackColor,
                  controller: _tabController,
                  labelColor: AppColors.primaryColor,
                  tabs: [
                    Tab(
                      child: appText(
                        myText: appLocal!.menu, //"Menu",
                        isbold: true,
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Tab(
                      child: appText(
                        textAlign: TextAlign.center,
                        myText: appLocal.information, //"Information",
                        isbold: true,
                      ),
                    ),
                    Tab(
                      child: appText(
                        textAlign: TextAlign.center,
                        myText: appLocal.reviews, //"Reviews",
                        isbold: true,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: h * 0.02,
              ),
              Expanded(
                  child: TabBarView(
                      controller: _tabController,
                      children: const [
                    ResturantMenuScreen(),
                    ResturantInformationScreen(),
                    ResturantReviewsScreen()
                  ]))
            ],
          ),
        ),
      ),
    );
  }
}
