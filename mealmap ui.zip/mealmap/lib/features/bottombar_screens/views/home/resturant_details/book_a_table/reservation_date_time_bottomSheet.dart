import 'package:mealmap/utilz/constants/exports.dart';

class ReservationDateTimeBottomSheet extends StatefulWidget {
  final bool? isNotEdit;
  const ReservationDateTimeBottomSheet({super.key, this.isNotEdit = true});

  @override
  // ignore: library_private_types_in_public_api
  _ReservationDateTimeBottomSheetState createState() =>
      _ReservationDateTimeBottomSheetState();
}

class _ReservationDateTimeBottomSheetState
    extends State<ReservationDateTimeBottomSheet> {
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primaryColor, // Header background color
              onPrimary: AppColors.whiteColor, // Header text color
              onSurface: AppColors.primaryColor, // Body text color
            ),
            dialogBackgroundColor: AppColors.primaryColor, // Background color
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }
  //--------------------------------------------------//

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primaryColor, // Header background color
              onPrimary: Colors.white, // Header text color
              onSurface: AppColors.primaryColor, // Body text color
            ),
            dialogBackgroundColor: AppColors.primaryColor, // Background color
          ),
          child: child!,
        );
      },
    );
    if (pickedTime != null && pickedTime != _selectedTime) {
      setState(() {
        _selectedTime = pickedTime;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: const BoxDecoration(
            color: AppColors.whiteColor,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15), topRight: Radius.circular(15))),
        margin: EdgeInsets.only(
          left: w * 0.04,
          right: w * 0.04,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        height: h * 0.45,
        child: Column(
          children: [
            appText(
              myText: appLocal!
                  .selectdateandtimeforreservation, //"Select date and time for reservation",
              isbold: true,
            ),
            SizedBox(
              height: h * 0.04,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                    height: h * 0.065,
                    width: w * 0.35,
                    child: appButton(
                        buttonText: _selectedDate == null
                            ? appLocal.date //"Date"
                            : _selectedDate.toString().substring(0, 10),
                        ontapfunction: () {
                          _selectDate(context);
                        })),
                SizedBox(
                    height: h * 0.065,
                    width: w * 0.35,
                    child: appButton(
                        buttonText: _selectedTime == null
                            ? appLocal.time //"Time"
                            : _selectedTime!.format(context).toString(),
                        ontapfunction: () {
                          _selectTime(context);
                        }))
              ],
            ),
            SizedBox(
              height: h * 0.02,
            ),
            customTextField(
              mYhintText: appLocal.persons, //"Persons",
              keyBordType: TextInputType.number,
            ),
            const Spacer(),
            SizedBox(
              height: h * 0.065,
              width: w,
              child: appButton(
                  buttonText: widget.isNotEdit!
                      ? appLocal.book //"Book"
                      : appLocal.save, //"Save",
                  ontapfunction: () {
                    if (widget.isNotEdit!) {
                      Navigator.pop(context);
                      Navigator.push(context,
                          createRoute(newPage: const BookATableScreen()));
                    } else {
                      Navigator.pop(context);
                    }
                  }),
            )
          ],
        ),
      ),
    );
  }
}
