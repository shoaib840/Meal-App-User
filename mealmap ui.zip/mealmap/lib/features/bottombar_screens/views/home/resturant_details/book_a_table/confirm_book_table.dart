import 'package:mealmap/utilz/constants/exports.dart';

class ConfirmBookATableScreen extends StatefulWidget {
  const ConfirmBookATableScreen({super.key});

  @override
  State<ConfirmBookATableScreen> createState() =>
      _ConfirmBookATableScreenState();
}

class _ConfirmBookATableScreenState extends State<ConfirmBookATableScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              height: h,
              width: w,
              padding: EdgeInsets.symmetric(horizontal: w * 0.02),
              child: Column(
                children: [
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Row(
                    children: [
                      arrowBack(),
                      SizedBox(
                        width: w * 0.02,
                      ),
                      appText(myText: "Don Giovanni", isbold: true),
                    ],
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Row(
                    children: [
                      appText(
                          myText: appLocal!
                              .pleasereviewyourreservationdetails, //"Please review your reservation details",
                          isbold: true,
                          myfontSize: 14),
                    ],
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  //----------------------------------------------------------------//

                  SizedBox(
                    height: h * 0.06,
                    width: w,
                    child: Row(
                      children: [
                        Container(
                          height: h * 0.06,
                          width: w * 0.75,
                          decoration: BoxDecoration(
                              color: AppColors.secondaryColor,
                              borderRadius: BorderRadius.circular(10)),
                          child: Row(
                            children: [
                              SizedBox(
                                height: h * 0.06,
                                width: w * 0.25,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      height: h * 0.05,
                                      width: w * 0.04,
                                      child: Image.asset(IconsApp.calenderIcon),
                                    ),
                                    SizedBox(
                                      width: w * 0.01,
                                    ),
                                    appText(
                                        myText: "22/12/2024",
                                        isbold: true,
                                        myfontSize: 10)
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: h * 0.06,
                                width: w * 0.24,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      height: h * 0.05,
                                      width: w * 0.04,
                                      child: Image.asset(IconsApp.clockIcon),
                                    ),
                                    SizedBox(
                                      width: w * 0.01,
                                    ),
                                    appText(
                                        myText: "11:00",
                                        isbold: true,
                                        myfontSize: 10)
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: h * 0.06,
                                width: w * 0.26,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      height: h * 0.05,
                                      width: w * 0.04,
                                      child: Image.asset(IconsApp.personsIcon),
                                    ),
                                    SizedBox(
                                      width: w * 0.01,
                                    ),
                                    appText(
                                        myText: "2 ${appLocal.persons}",
                                        isbold: true,
                                        myfontSize: 10)
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                        SizedBox(
                          width: w * 0.01,
                        ),
                        Expanded(
                            child: Container(
                          height: h * 0.06,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColors.yellowColor),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              SizedBox(
                                height: h * 0.05,
                                width: w * 0.035,
                                child: Image.asset(
                                  IconsApp.dollarBadgeIcon,
                                ),
                              ),
                              appText(
                                  myText: "30%", myfontSize: 10, isbold: true)
                            ],
                          ),
                        ))
                      ],
                    ),
                  ),
                  //------------------------------------------------------------------------//
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Container(
                    height: h * 0.06,
                    width: w,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: AppColors.secondaryColor),
                    child: Row(
                      children: [
                        appText(myText: "       ${appLocal.specialrequest}")
                      ],
                    ),
                  ),
                  const Spacer(),
                  SizedBox(
                    height: h * 0.065,
                    width: w * 0.8,
                    child: appButton(
                        buttonText: appLocal
                            .confirmyourbooking, //"Confirm your booking",
                        ontapfunction: () {}),
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),

                  appText(
                      textAlign: TextAlign.center,
                      myText: appLocal
                          .byclickingconfirmyourbookingIagreetoMealMapTermsofuse, //"By clicking “Confirm your booking”, I agree to MealMap’s Terms of use",
                      isbold: true,
                      myfontSize: 7),
                  SizedBox(
                    height: h * 0.02,
                  )
                ],
              ),
            )));
  }
}
