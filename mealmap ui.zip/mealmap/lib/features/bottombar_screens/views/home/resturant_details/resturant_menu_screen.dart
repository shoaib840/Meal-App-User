import 'package:mealmap/utilz/constants/exports.dart';

class ResturantMenuScreen extends StatefulWidget {
  const ResturantMenuScreen({super.key});

  @override
  State<ResturantMenuScreen> createState() => _ResturantMenuScreenState();
}

class _ResturantMenuScreenState extends State<ResturantMenuScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    _tabController = TabController(length: 4, vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    final bottomR = context.read<BottomBarProvider>();
    return Stack(
      children: [
        Container(
          height: h,
          width: w,
          color: AppColors.backgroundColor,
          child: Column(
            children: [
              Container(
                height: h * 0.05,
                width: w,
                decoration: BoxDecoration(
                  color: AppColors.secondaryColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: TabBar(
                  dividerColor: Colors.transparent,
                  indicatorColor: AppColors.blackColor,
                  controller: _tabController,
                  labelColor: AppColors.secondaryColor,
                  tabs: [
                    Tab(
                      child: appText(
                          myText: appLocal!.pasta, //"Pasta",
                          isbold: true,
                          myfontSize: 10),
                    ),
                    Tab(
                      child: appText(
                          myText: appLocal.vegan, //"Vegan",
                          isbold: true,
                          myfontSize: 10),
                    ),
                    Tab(
                      child: appText(
                          myText: appLocal.desserts, //"Desserts",
                          isbold: true,
                          myfontSize: 10),
                    ),
                    Tab(
                      child: appText(
                          myText: appLocal.drinks, //"Drinks",
                          isbold: true,
                          myfontSize: 10),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: h * 0.01,
              ),

              //----------------------------------------------------------//
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: w * 0.02),
                        child: Row(
                          children: [
                            appText(
                                myText: appLocal.mostpopular, //"Most Popular",
                                isbold: true,
                                myfontSize: 18),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: h * 0.02,
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: w * 0.02),
                        height: h * 0.25,
                        width: w,
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: [
                              for (int i = 0; i < 20; i++) ...{
                                resturantMenuItems(
                                    onitemClick: () {
                                      showModalBottomSheet(
                                        backgroundColor: Colors.transparent,
                                        isScrollControlled: true,
                                        context: context,
                                        builder: (BuildContext context) {
                                          return const BottomSheetItemSelectedOfResturant();
                                        },
                                      );
                                    },
                                    dishPrice: "\$25",
                                    itemNumber: "# ${i + 1}",
                                    favOnTap: () {},
                                    dishImagePath: IconsApp.menuDishIcon,
                                    dishName: "Spicy Spaghetti",
                                    percent: " 88%",
                                    totalOrder: "(218)",
                                    backgroundColour: AppColors.secondaryColor,
                                    addOnTap: () {})
                              }
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: h * 0.04,
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: w * 0.02),
                        height: h * 0.25,
                        width: w,
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: [
                              for (int i = 0; i < 20; i++) ...{
                                resturantMenuItems(
                                    onitemClick: () {
                                      showModalBottomSheet(
                                        backgroundColor: Colors.transparent,
                                        isScrollControlled: true,
                                        context: context,
                                        builder: (BuildContext context) {
                                          return const BottomSheetItemSelectedOfResturant();
                                        },
                                      );
                                    },
                                    dishPrice: "\$10",
                                    itemNumber: "",
                                    favOnTap: () {},
                                    dishImagePath: ImagesApp.coldDrinkImage,
                                    dishName: "Ice Cold Pepsi",
                                    percent: " 88%",
                                    totalOrder: "(218)",
                                    backgroundColour:
                                        AppColors.greyColor.withOpacity(0.1),
                                    addOnTap: () {})
                              }
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: h * 0.1,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        //------------------------------------------------------------------------------------//
        Positioned(
          bottom: h * 0.02,
          left: w * 0.12,
          child: Container(
            height: h * 0.06,
            width: w * 0.76,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: AppColors.primaryColor),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                    width: w * 0.35,
                    height: h * 0.6,
                    child: appButton(
                        boxShadow: false,
                        buttonText: appLocal.bookatable, //"Book a table",
                        ontapfunction: () {
                          showModalBottomSheet(
                            backgroundColor: Colors.transparent,
                            isScrollControlled: true,
                            context: context,
                            builder: (BuildContext context) {
                              return const ReservationDateTimeBottomSheet();
                            },
                          );
                        })),
                const VerticalDivider(
                  endIndent: 5,
                  indent: 5,
                  color: AppColors.blackColor,
                ),
                SizedBox(
                    width: w * 0.35,
                    height: h * 0.6,
                    child: appButton(
                        boxShadow: false,
                        buttonText: appLocal.gotocart,

                        ///"Go to cart",
                        ontapfunction: () {
                          bottomR.changePageIndex(index: 4);
                          Navigator.push(
                            context,
                            createRoute(newPage: const DrawerWithBottomBar()),
                          );
                        }))
              ],
            ),
          ),
        ),
      ],
    );
  }
}
