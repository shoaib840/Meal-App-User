import 'package:mealmap/utilz/constants/exports.dart';

class BookATableScreen extends StatefulWidget {
  const BookATableScreen({super.key});

  @override
  State<BookATableScreen> createState() => _BookATableScreenState();
}

class _BookATableScreenState extends State<BookATableScreen> {
  bool getOffer = true;
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              height: h,
              width: w,
              padding: EdgeInsets.symmetric(horizontal: w * 0.02),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Row(
                    children: [
                      arrowBack(),
                      SizedBox(
                        width: w * 0.02,
                      ),
                      appText(myText: "Don Giovanni", isbold: true),
                    ],
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  appText(
                      myText: appLocal!.selectanoffer, //"Select an offer",
                      isbold: true,
                      myfontSize: 14),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  //------------------------------------------------------------------------------------//
                  Container(
                    height: h * 0.06,
                    width: w,
                    decoration: BoxDecoration(
                        color: AppColors.secondaryColor,
                        borderRadius: BorderRadius.circular(10)),
                    child: Row(
                      children: [
                        SizedBox(
                          height: h * 0.06,
                          width: w * 0.25,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                height: h * 0.05,
                                width: w * 0.04,
                                child: Image.asset(IconsApp.calenderIcon),
                              ),
                              SizedBox(
                                width: w * 0.01,
                              ),
                              appText(
                                  myText: "22/12/2024",
                                  isbold: true,
                                  myfontSize: 10)
                            ],
                          ),
                        ),
                        SizedBox(
                          height: h * 0.06,
                          width: w * 0.24,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                height: h * 0.05,
                                width: w * 0.04,
                                child: Image.asset(IconsApp.clockIcon),
                              ),
                              SizedBox(
                                width: w * 0.01,
                              ),
                              appText(
                                  myText: "11:00", isbold: true, myfontSize: 10)
                            ],
                          ),
                        ),
                        SizedBox(
                          height: h * 0.06,
                          width: w * 0.26,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                height: h * 0.05,
                                width: w * 0.04,
                                child: Image.asset(IconsApp.personsIcon),
                              ),
                              SizedBox(
                                width: w * 0.01,
                              ),
                              appText(
                                  myText: "2 ${appLocal.persons}",
                                  isbold: true,
                                  myfontSize: 10)
                            ],
                          ),
                        ),
                        Expanded(
                            child: Center(
                          child: Container(
                            height: 25,
                            width: 25,
                            clipBehavior: Clip.antiAlias,
                            decoration: const BoxDecoration(
                                color: AppColors.whiteColor,
                                shape: BoxShape.circle),
                            child: Material(
                              color: Colors.transparent,
                              child: InkWell(
                                onTap: () {
                                  showModalBottomSheet(
                                    backgroundColor: Colors.transparent,
                                    isScrollControlled: true,
                                    context: context,
                                    builder: (BuildContext context) {
                                      return const ReservationDateTimeBottomSheet(
                                        isNotEdit: false,
                                      );
                                    },
                                  );
                                },
                                splashColor: AppColors.primaryColor,
                                child: const Icon(
                                  Icons.edit,
                                  size: 12,
                                  color: AppColors.primaryColor,
                                ),
                              ),
                            ),
                          ),
                        ))
                      ],
                    ),
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  choiceOfferOrNotWidget(
                      topic: "30% ${appLocal.offoffer}",
                      topicDetail: appLocal
                          .presetmenusanddrinksarenotincludedSubjecttoarrivalatthereservedtime, //"Preset menus and drinks are not included. Subject to arrival at the reserved time",
                      backgroundColor: getOffer
                          ? AppColors.yellowColor
                          : AppColors.whiteColor,
                      clickUnclickColor:
                          getOffer ? AppColors.blackColor : Colors.transparent,
                      onTap: () {
                        setState(() {
                          getOffer = true;
                        });
                      }),
                  choiceOfferOrNotWidget(
                      topic: appLocal
                          .bookwithoutanoffer, //"Book without an offer",
                      backgroundColor: getOffer
                          ? AppColors.whiteColor
                          : AppColors.yellowColor,
                      clickUnclickColor:
                          getOffer ? Colors.transparent : AppColors.blackColor,
                      onTap: () {
                        setState(() {
                          getOffer = false;
                        });
                      }),
                  const Spacer(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: w * 0.8,
                        height: h * 0.065,
                        child: appButton(
                            buttonText: appLocal.continuee, //"Continue",
                            ontapfunction: () {
                              Navigator.push(
                                  context,
                                  createRoute(
                                      newPage:
                                          const ConfirmBookATableScreen()));
                            }),
                      ),
                    ],
                  ),

                  SizedBox(
                    height: h * 0.02,
                  ),
                ],
              ),
            )));
  }
}

Widget choiceOfferOrNotWidget(
    {required String topic,
    required backgroundColor,
    required clickUnclickColor,
    required onTap,
    String topicDetail = ''}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: h * 0.1,
        width: w,
        padding: EdgeInsets.symmetric(horizontal: w * 0.02),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(10),
        ),
        clipBehavior: Clip.antiAlias,
        child: Row(
          children: [
            SizedBox(
              height: h * 0.1,
              width: w * 0.8,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  appText(myText: topic, isbold: true, myfontSize: 12),
                  topicDetail.isNotEmpty
                      ? appText(myText: topicDetail, myfontSize: 10)
                      : const SizedBox()
                ],
              ),
            ),
            Expanded(
                child: Center(
              child: Container(
                height: 18,
                width: 18,
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                    border: Border.all(color: AppColors.blackColor),
                    shape: BoxShape.circle),
                child: Container(
                  decoration: BoxDecoration(
                      color: clickUnclickColor, shape: BoxShape.circle),
                ),
              ),
            ))
          ],
        ),
      ),
    );
  });
}
