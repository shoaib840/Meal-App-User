import 'package:mealmap/utilz/constants/exports.dart';

class ResturantReviewsScreen extends StatefulWidget {
  const ResturantReviewsScreen({super.key});

  @override
  State<ResturantReviewsScreen> createState() => _ResturantReviewsScreenState();
}

class _ResturantReviewsScreenState extends State<ResturantReviewsScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Stack(
      children: [
        Container(
          height: h,
          width: w,
          padding: EdgeInsets.symmetric(horizontal: w * 0.05),
          child: Column(
            children: [
              Container(
                height: h * 0.09,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                ),
                clipBehavior: Clip.antiAlias,
                child: CircularPercentIndicator(
                    radius: h * 0.04,
                    lineWidth: 3.0,
                    percent: .94,
                    center:
                        appText(myText: "9.4", isbold: true, myfontSize: 16),
                    progressColor: AppColors.primaryColor,
                    backgroundColor: AppColors.greyColor.withOpacity(0.2),
                    fillColor: AppColors.secondaryColor.withOpacity(0.2)),
              ),
              SizedBox(
                height: h * 0.01,
              ),
              appText(
                  textAlign: TextAlign.center,
                  myText:
                      "${appLocal!.basedon} 1,337 ${appLocal.reviewsfromourusers}"),
              SizedBox(
                height: h * 0.01,
              ),
              reviewRatingWidget(
                  reviewNumber: "10",
                  percentIndicatorProgress: 0.7,
                  reviewNumberTotalReview: "545"),
              reviewRatingWidget(
                  reviewNumber: "9",
                  percentIndicatorProgress: 0.6,
                  reviewNumberTotalReview: "445"),
              reviewRatingWidget(
                  reviewNumber: "8",
                  percentIndicatorProgress: 0.5,
                  reviewNumberTotalReview: "345"),
              reviewRatingWidget(
                  reviewNumber: "7",
                  percentIndicatorProgress: 0.4,
                  reviewNumberTotalReview: "245"),
              reviewRatingWidget(
                  reviewNumber: "6",
                  percentIndicatorProgress: 0.3,
                  reviewNumberTotalReview: "145"),
              SizedBox(
                height: h * 0.02,
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      for (int i = 0; i < 10; i++) ...{
                        resturantCommentReviewWidget(
                            commentSenderName: "Janet R.",
                            commentDate: "18/8/2024",
                            reviewPoints: "8.5",
                            comment:
                                "Beautiful little restaurant with authentic and absolutely delicious Italian food. Warm and welcoming staff and great service. Plus extremely reasonable pricing. Will go back definitely.")
                      }
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
        Positioned(
          bottom: h * 0.02,
          left: w * 0.17,
          child: Container(
              height: h * 0.06,
              width: w * 0.65,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  color: AppColors.primaryColor),
              child: appButton(
                  buttonText: appLocal.bookatable, //"Book a table",
                  ontapfunction: () {
                    showModalBottomSheet(
                      backgroundColor: Colors.transparent,
                      isScrollControlled: true,
                      context: context,
                      builder: (BuildContext context) {
                        return const ReservationDateTimeBottomSheet();
                      },
                    );
                    // Navigator.push(context,
                    //     createRoute(newPage: const BookATableScreen()));
                  })),
        ),
      ],
    );
  }
}

Widget reviewRatingWidget(
    {required String reviewNumber,
    required double percentIndicatorProgress,
    required String reviewNumberTotalReview}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        appText(myText: reviewNumber, myfontSize: 10, isbold: true),
        SizedBox(
          height: h * 0.02,
          width: w * 0.8,
          child: LinearPercentIndicator(
            width: w * 0.8,
            lineHeight: h * 0.01,
            percent: percentIndicatorProgress,
            backgroundColor: AppColors.greyColor.withOpacity(0.2),
            progressColor: AppColors.primaryColor,
            barRadius: const Radius.circular(10),
          ),
        ),
        appText(myText: reviewNumberTotalReview, myfontSize: 10, isbold: true),
      ],
    );
  });
}
