import 'package:mealmap/utilz/constants/exports.dart';

class ResturantInformationScreen extends StatefulWidget {
  const ResturantInformationScreen({super.key});

  @override
  State<ResturantInformationScreen> createState() =>
      _ResturantInformationScreenState();
}

class _ResturantInformationScreenState
    extends State<ResturantInformationScreen> {
  GoogleMapController? controller;
  static const LatLng _center =
      LatLng(37.7749, -122.4194); // San Francisco coordinates

  final Set<Marker> markers = {
    const Marker(
      markerId: MarkerId('defaultMarker'),
      position: _center,
      infoWindow: InfoWindow(title: 'San Francisco'),
      icon: BitmapDescriptor.defaultMarker,
    ),
  };
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Stack(
      children: [
        Container(
          height: h,
          width: w,
          padding: EdgeInsets.symmetric(horizontal: w * 0.05),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    appText(
                        myText: "Don Giovanni", isbold: true, myfontSize: 14),
                    Column(
                      children: [
                        Container(
                          height: h * 0.025,
                          width: w * 0.1,
                          decoration: BoxDecoration(
                              color: AppColors.secondaryColor,
                              borderRadius: BorderRadius.circular(10)),
                          child: Center(
                            child: appText(
                                myText: "9.6", isbold: true, myfontSize: 10),
                          ),
                        ),
                        SizedBox(
                          height: h * 0.005,
                        ),
                        appText(myText: "(1,234)", myfontSize: 10),
                      ],
                    )
                  ],
                ), //------------------------------------------------------------//

                Row(
                  children: [
                    SizedBox(
                      height: h * 0.02,
                      width: w * 0.04,
                      child: Image.asset(IconsApp.locationIcon),
                    ),
                    SizedBox(
                      width: w * 0.005,
                    ),
                    appText(
                        myText: "19, rue Français Miran 75004 Paris, France",
                        myfontSize: 10)
                  ],
                ),
                //----------------------------------------------------------------------//
                SizedBox(height: h * 0.01),
                Container(
                  decoration: BoxDecoration(
                      color: AppColors.secondaryColor,
                      borderRadius: BorderRadius.circular(30)),
                  padding: EdgeInsets.symmetric(
                      horizontal: w * 0.02, vertical: h * 0.005),
                  child:
                      appText(myText: "Italian", myfontSize: 10, isbold: true),
                ),
                SizedBox(height: h * 0.01),
                //----------------------------------------------------
                //-----------------------------------------------------------------------------------//
                //----------------------------------------------------------------------------------------//

                Row(
                  children: [
                    Container(
                      height: h * 0.03,
                      width: w * 0.16,
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: AppColors.secondaryColor),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          SizedBox(
                            height: h * 0.015,
                            width: w * 0.03,
                            child: Image.asset(IconsApp.dollarIcon),
                          ),
                          appText(myText: "\$26", myfontSize: 10, isbold: true)
                        ],
                      ),
                    ),
                    SizedBox(
                      width: w * 0.01,
                    ),
                    Container(
                      height: h * 0.03,
                      width: w * 0.16,
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: AppColors.secondaryColor),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          SizedBox(
                            width: w * 0.03,
                            height: h * 0.015,
                            child: Image.asset(IconsApp.fromlocationIcon),
                          ),
                          appText(myText: "10km", myfontSize: 10, isbold: true)
                        ],
                      ),
                    ),
                    SizedBox(
                      width: w * 0.01,
                    ),
                    Container(
                      height: h * 0.03,
                      width: w * 0.16,
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: AppColors.secondaryColor),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          SizedBox(
                            width: w * 0.03,
                            height: h * 0.015,
                            child: Image.asset(IconsApp.clockIcon),
                          ),
                          appText(myText: "10m", myfontSize: 10, isbold: true)
                        ],
                      ),
                    ),
                    const Spacer(),
                    Container(
                      height: h * 0.035,
                      width: w * 0.08,
                      clipBehavior: Clip.antiAlias,
                      decoration: const BoxDecoration(
                          color: AppColors.primaryColor,
                          shape: BoxShape.circle),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () {},
                          splashColor: AppColors.whiteColor,
                          child: const Icon(
                            Icons.favorite,
                            size: 16,
                            color: AppColors.whiteColor,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: w * 0.01,
                    ),
                    Container(
                      height: h * 0.035,
                      width: w * 0.08,
                      decoration: const BoxDecoration(
                          color: AppColors.primaryColor,
                          shape: BoxShape.circle),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () {},
                          splashColor: AppColors.whiteColor,
                          child: const Icon(
                            Icons.share,
                            size: 16,
                          ),
                        ),
                      ),
                    )
                  ],
                ),
                //---------------------------------------------------------------------------//
                //----------------------------------------------------------------------------------------------------//
                SizedBox(
                  height: h * 0.01,
                ),
                appText(
                    myText: appLocal!.aboutus, //"About us",
                    myfontSize: 14,
                    isbold: true),
                appText(
                    myfontSize: 10,
                    myText:
                        "Located in the very heart of the historical neighbourhood, Don Giovanni provides a relaxing, welcoming ambiance with uncluttered decor - with exposed beams and subdue lighting."),
                SizedBox(
                  height: h * 0.01,
                ),
                //-----------------------------------------------------------------------------//
                //---------------------------------------------------------------------------------------------//
                Container(
                  height: h * 0.2,
                  width: w,
                  decoration:
                      BoxDecoration(borderRadius: BorderRadius.circular(10)),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: GoogleMap(
                      initialCameraPosition: const CameraPosition(
                        target: _center,
                        zoom: 13,
                      ),
                      markers: markers,
                      onMapCreated: (GoogleMapController controller) {
                        controller = controller;
                      },
                    ),
                  ),
                ),
                SizedBox(
                  height: h * 0.02,
                ),
                appText(
                    myText: appLocal.schedule, //"Schedule",
                    isbold: true),
                SizedBox(
                  height: h * 0.01,
                ),

                for (int i = 0; i < 7; i++) ...{
                  sheduleWidgetOfResturant(
                      dayName: "Monday", dayTimeOfShedule: "12:00 - 23:00")
                },
                Row(
                  children: [
                    SizedBox(
                      width: w * 0.3,
                      child: appText(myText: "Parking", isbold: true),
                    ),
                    appText(myText: "Available"),
                  ],
                ),
              ],
            ),
          ),
        ),
        Positioned(
          bottom: h * 0.02,
          left: w * 0.17,
          child: Container(
              height: h * 0.06,
              width: w * 0.65,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  color: AppColors.primaryColor),
              child: appButton(
                  buttonText: appLocal.bookatable, //"Book a table",
                  ontapfunction: () {
                    showModalBottomSheet(
                      backgroundColor: Colors.transparent,
                      isScrollControlled: true,
                      context: context,
                      builder: (BuildContext context) {
                        return const ReservationDateTimeBottomSheet();
                      },
                    );
                  })),
        ),
      ],
    );
  }
}
