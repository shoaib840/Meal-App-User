import 'package:mealmap/utilz/constants/exports.dart';

Widget resturantMenuItems(
    {String dishPrice = '',
    String itemNumber = '',
    favOnTap,
    required String dishImagePath,
    required String dishName,
    required String percent,
    required String totalOrder,
    required Color backgroundColour,
    required onitemClick,
    required addOnTap}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onitemClick,
      child: Container(
        margin: EdgeInsets.only(right: w * 0.01),
        width: w * 0.35,
        height: h * 0.25,
        // decoration: const BoxDecoration(color: Colors.red),
        child: Column(
          children: [
            Container(
              height: h * 0.2,
              width: w * 0.35,
              padding: EdgeInsets.symmetric(
                  horizontal: w * 0.01, vertical: h * 0.005),
              decoration: BoxDecoration(
                  color: backgroundColour,
                  borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10),
                      bottomRight: Radius.circular(10))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  dishPrice != ""
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            dishPrice != ""
                                ? Container(
                                    decoration: BoxDecoration(
                                        color: AppColors.primaryColor,
                                        borderRadius:
                                            BorderRadius.circular(30)),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: w * 0.02,
                                        vertical: h * 0.005),
                                    child: appText(
                                        myText: dishPrice,
                                        myfontSize: 10,
                                        isbold: true),
                                  )
                                : const SizedBox(),
                            itemNumber != ''
                                ? Container(
                                    decoration: BoxDecoration(
                                        color: AppColors.blackColor,
                                        borderRadius:
                                            BorderRadius.circular(30)),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: w * 0.02,
                                        vertical: h * 0.005),
                                    child: appText(
                                        myText: itemNumber,
                                        myfontSize: 10,
                                        myColors: AppColors.whiteColor,
                                        isbold: true),
                                  )
                                : const SizedBox(),
                            Container(
                              height: h * 0.03,
                              width: w * 0.07,
                              clipBehavior: Clip.antiAlias,
                              decoration: const BoxDecoration(
                                  color: AppColors.primaryColor,
                                  shape: BoxShape.circle),
                              child: Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  onTap: favOnTap,
                                  splashColor: AppColors.whiteColor,
                                  child: Icon(
                                    size: w * 0.04,
                                    Icons.favorite,
                                    color: AppColors.whiteColor,
                                  ),
                                ),
                              ),
                            )
                          ],
                        )
                      : SizedBox(
                          height: h * 0.02,
                        ),

                  //-----------------------------------------------------------------------------------
                  SizedBox(
                    height: h * 0.01,
                  ),
                  SizedBox(
                    height: h * 0.11,
                    width: w,
                    // color: Colors.red,
                    child: Image.asset(dishImagePath),
                  ),
                  SizedBox(
                    height: h * 0.01,
                  ),
                  appText(myText: dishName, isbold: true, myfontSize: 10)
                ],
              ),
            ),
            Expanded(
                child: Row(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: w * 0.01),
                  width: w * 0.25,
                  height: h,
                  decoration: BoxDecoration(
                      color: backgroundColour,
                      borderRadius: const BorderRadius.only(
                          bottomRight: Radius.circular(10),
                          bottomLeft: Radius.circular(10))),
                  child: Row(
                    children: [
                      SizedBox(
                        height: h * 0.022,
                        width: w * 0.07,
                        child: Image.asset(IconsApp.thumbsUpIcon),
                      ),
                      appText(myText: percent, isbold: true, myfontSize: 10),
                      appText(
                          myText: totalOrder,
                          myfontSize: 9,
                          isbold: true,
                          myColors: AppColors.greyColor)
                    ],
                  ),
                ),
                Expanded(
                    child: Padding(
                  padding: const EdgeInsets.only(left: 4, top: 4),
                  child: Container(
                    height: h,
                    decoration: BoxDecoration(
                        color: AppColors.blackColor,
                        borderRadius: BorderRadius.circular(10)),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        splashColor: AppColors.whiteColor,
                        onTap: addOnTap,
                        child: Center(
                          child: appText(
                              myText: "+",
                              myfontSize: 20,
                              isbold: true,
                              myColors: AppColors.whiteColor),
                        ),
                      ),
                    ),
                  ),
                ))
              ],
            ))
          ],
        ),
      ),
    );
  });
}

// Widget mostLikedItemsResturant(
//     {required String foodImagePath,
//     required String likedNumber,
//     required String foodName,
//     required String priceOfFood,
//     required String ratingAndOrders,
//     required onTapAddToCart}) {
//   return Builder(builder: (context) {
//     final h = MediaQuery.of(context).size.height;
//     final w = MediaQuery.of(context).size.width;
//     return Container(
//       margin: EdgeInsets.symmetric(horizontal: w * 0.01),
//       height: h * 0.22,
//       width: w * 0.3,
//       child: Column(
//         children: [
//           Stack(
//             children: [
//               Container(
//                 clipBehavior: Clip.antiAlias,
//                 height: h * 0.11,
//                 width: w * 0.3,
//                 decoration:
//                     BoxDecoration(borderRadius: BorderRadius.circular(10)),
//                 child: Image.asset(
//                   foodImagePath,
//                   fit: BoxFit.fill,
//                 ),
//               ),
//               Positioned(
//                 top: h * 0.005,
//                 left: w * 0.025,
//                 child: Container(
//                   height: h * 0.02,
//                   width: w * 0.25,
//                   decoration: BoxDecoration(
//                       color: AppColors.secondaryColor.withOpacity(0.9),
//                       borderRadius: BorderRadius.circular(20)),
//                   child: Center(
//                     child: appText(
//                         myText: likedNumber, isbold: true, myfontSize: 8),
//                   ),
//                 ),
//               )
//             ],
//           ),
//           SizedBox(
//             height: h * 0.005,
//           ),
//           appText(myText: foodName, isbold: true),
//           SizedBox(
//             height: h * 0.005,
//           ),
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//             children: [
//               Container(
//                 decoration: BoxDecoration(
//                     color: AppColors.secondaryColor,
//                     borderRadius: BorderRadius.circular(30)),
//                 padding: EdgeInsets.symmetric(
//                     horizontal: w * 0.02, vertical: h * 0.005),
//                 child:
//                     appText(myText: priceOfFood, myfontSize: 10, isbold: true),
//               ),
//               appText(myText: ratingAndOrders, myfontSize: 10)
//             ],
//           ),
//           SizedBox(
//             height: h * 0.01,
//           ),
//           Container(
//             height: h * 0.03,
//             width: w,
//             clipBehavior: Clip.antiAlias,
//             decoration: BoxDecoration(
//                 color: AppColors.blackColor,
//                 borderRadius: BorderRadius.circular(30)),
//             child: Material(
//               color: Colors.transparent,
//               child: InkWell(
//                 onTap: onTapAddToCart,
//                 splashColor: AppColors.whiteColor,
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     SizedBox(
//                       height: h * 0.016,
//                       width: w * 0.07,
//                       child: Image.asset(IconsApp.cartPlusIcon),
//                     ),
//                     appText(
//                         myText: "Add to cart",
//                         myColors: AppColors.whiteColor,
//                         isbold: true,
//                         myfontSize: 9)
//                   ],
//                 ),
//               ),
//             ),
//           )
//         ],
//       ),
//     );
//   });
// }
//----------------------------Resturant Catogories Item Widget

// Widget resturantCotogoriesItemsWidget(
//     {required String foodImagePath,
//     required String foodName,
//     required String foodDescription,
//     required String foodPrice,
//     required onTapAddCart}) {
//   return Builder(builder: (context) {
//     final h = MediaQuery.of(context).size.height;
//     final w = MediaQuery.of(context).size.width;
//     return Container(
//       height: h * 0.1,
//       width: w,
//       margin: EdgeInsets.only(bottom: h * 0.01),
//       clipBehavior: Clip.antiAlias,
//       decoration: BoxDecoration(
//           color: AppColors.greyColor.withOpacity(0.1),
//           borderRadius: BorderRadius.circular(10)),
//       child: Row(
//         children: [
//           Container(
//             height: h * 0.1,
//             width: w * 0.2,
//             decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)),
//             child: Image.asset(
//               foodImagePath,
//               fit: BoxFit.fill,
//             ),
//           ),
//           SizedBox(
//             width: w * 0.02,
//           ),
//           Expanded(
//               child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               appText(myText: foodName, isbold: true),
//               appText(myText: foodDescription, myfontSize: 10)
//             ],
//           )),
//           SizedBox(
//             height: h * 0.1,
//             width: w * 0.15,
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//               children: [
//                 Container(
//                   decoration: BoxDecoration(
//                       color: AppColors.secondaryColor,
//                       borderRadius: BorderRadius.circular(30)),
//                   padding: EdgeInsets.symmetric(
//                       horizontal: w * 0.02, vertical: h * 0.005),
//                   child:
//                       appText(myText: foodPrice, myfontSize: 10, isbold: true),
//                 ),
//                 Container(
//                   height: h * 0.03,
//                   width: w * 0.12,
//                   clipBehavior: Clip.antiAlias,
//                   decoration: BoxDecoration(
//                       color: AppColors.blackColor,
//                       borderRadius: BorderRadius.circular(15)),
//                   child: Material(
//                     color: Colors.transparent,
//                     child: InkWell(
//                       onTap: onTapAddCart,
//                       splashColor: AppColors.whiteColor,
//                       child: Padding(
//                         padding: const EdgeInsets.all(4.0),
//                         child: Image.asset(IconsApp.cartPlusIcon),
//                       ),
//                     ),
//                   ),
//                 )
//               ],
//             ),
//           )
//         ],
//       ),
//     );
//   });
// }

//--------------TimeShedule Widget

Widget sheduleWidgetOfResturant(
    {required String dayName, required String dayTimeOfShedule}) {
  return Builder(builder: (context) {
    final w = MediaQuery.of(context).size.width;
    return Row(
      children: [
        SizedBox(
          width: w * 0.3,
          child: appText(myText: dayName),
        ),
        appText(myText: dayTimeOfShedule)
      ],
    );
  });
}
//-----------------------------------Comment Widgets

Widget resturantCommentReviewWidget({
  required String commentSenderName,
  required String commentDate,
  required String reviewPoints,
  required String comment,
}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SizedBox(
      width: w,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: h * 0.05,
            width: w,
            child: Row(
              children: [
                Container(
                  height: h * 0.05,
                  width: w * 0.12,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.secondaryColor,
                  ),
                  child: Center(
                    child: appText(
                      myText: commentSenderName[0],
                      myfontSize: 14,
                      isbold: true,
                    ),
                  ),
                ),
                SizedBox(
                  width: w * 0.01,
                ),
                Expanded(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    appText(
                      myText: commentSenderName,
                      isbold: true,
                    ),
                    appText(myText: commentDate, myfontSize: 6, isbold: true)
                  ],
                )),
                SizedBox(
                  width: w * 0.02,
                ),
                Container(
                  height: h * 0.025,
                  width: w * 0.1,
                  decoration: BoxDecoration(
                      color: AppColors.secondaryColor,
                      borderRadius: BorderRadius.circular(10)),
                  child: Center(
                    child: appText(
                        myText: reviewPoints, isbold: true, myfontSize: 10),
                  ),
                ),
              ],
            ),
          ),
          //----------------------------------------------------------------//
          SizedBox(
            height: h * 0.01,
          ),
          appText(
              myText:
                  // "Beautiful little restaurant with authentic and absolutely delicious Italian food. Warm and welcoming staff and great service. Plus extremely reasonable pricing. Will go back definitely."
                  comment),
          Divider(
            color: AppColors.greyColor.withOpacity(0.5),
            thickness: 1,
          ),
          SizedBox(
            height: h * 0.01,
          ),
        ],
      ),
    );
  });
}
