import 'package:mealmap/utilz/constants/exports.dart';

Widget resturantsWidget({
  required String resturantImagePath,
  required String resturantFood,
  required String resturantName,
  required String location,
  required String rating,
  required String price,
  required String kmaway,
  required String awayinTime,
  required onTap,
}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        children: [
          Container(
            height: h * 0.22,
            width: w * 0.65,
            clipBehavior: Clip.antiAlias,
            margin: const EdgeInsets.only(right: 8),
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage(resturantImagePath), fit: BoxFit.fill),
                borderRadius: BorderRadius.circular(10)),
          ),
          Positioned(
            right: w * 0.03,
            top: h * 0.01,
            child: Container(
              height: h * 0.025,
              width: w * 0.1,
              decoration: BoxDecoration(
                  color: AppColors.secondaryColor,
                  borderRadius: BorderRadius.circular(10)),
              child: Center(
                child: appText(myText: rating, isbold: true, myfontSize: 10),
              ),
            ),
          ),
          Positioned(
            left: 0,
            top: h * 0.01,
            child: Container(
              height: h * 0.025,
              padding: EdgeInsets.symmetric(horizontal: w * 0.01),
              decoration: const BoxDecoration(
                  color: AppColors.yellowColor,
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(10),
                      topRight: Radius.circular(10))),
              child: Center(
                child: appText(
                    myText: "${appLocal!.spend} \$25",
                    isbold: true,
                    myfontSize: 10),
              ),
            ),
          ),
          Positioned(
            left: 0,
            top: h * 0.038,
            child: Container(
              height: h * 0.028,
              padding: EdgeInsets.symmetric(horizontal: w * 0.01),
              decoration: const BoxDecoration(
                  color: AppColors.blackColor,
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(10),
                      topRight: Radius.circular(10))),
              child: Center(
                child: appText(
                    myText: appLocal.getfreedelivery, //"Get free delivery",
                    isbold: true,
                    myfontSize: 10,
                    myColors: AppColors.whiteColor),
              ),
            ),
          ),
          Positioned(
            right: w * 0.03,
            top: h * 0.1,
            child: Container(
              height: h * 0.025,
              width: w * 0.12,
              decoration: BoxDecoration(
                  color: AppColors.secondaryColor,
                  borderRadius: BorderRadius.circular(10)),
              child: Center(
                child: appText(myText: price, isbold: true, myfontSize: 10),
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            child: Container(
                height: h * 0.07,
                width: w * 0.65,
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(
                    color: AppColors.whiteColor.withOpacity(0.9),
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                  children: [
                    Container(
                      height: h * 0.033,
                      width: w * 0.65,
                      padding: EdgeInsets.symmetric(horizontal: w * 0.02),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          appText(myText: resturantName, isbold: true),
                          Container(
                            decoration: BoxDecoration(
                                color: AppColors.greenColor.withOpacity(0.6),
                                borderRadius: BorderRadius.circular(10)),
                            padding: EdgeInsets.symmetric(
                                horizontal: w * 0.02, vertical: h * 0.002),
                            child: appText(
                                myText: resturantFood,
                                myfontSize: 8,
                                isbold: true),
                          )
                        ],
                      ),
                    ),
                    const Spacer(),
                    Container(
                      height: h * 0.033,
                      width: w * 0.65,
                      padding: EdgeInsets.symmetric(horizontal: w * 0.02),
                      child: Row(
                        children: [
                          SizedBox(
                            height: h * 0.015,
                            width: w * 0.03,
                            child: Image.asset(
                              IconsApp.locationIcon,
                              color: AppColors.blackColor,
                            ),
                          ),
                          SizedBox(
                            width: w * 0.01,
                          ),
                          appText(
                              myText: location, isbold: true, myfontSize: 9),
                          const Spacer(),
                          Container(
                            height: h * 0.03,
                            width: w * 0.16,
                            clipBehavior: Clip.antiAlias,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: AppColors.secondaryColor),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                SizedBox(
                                  width: w * 0.03,
                                  height: h * 0.015,
                                  child: Image.asset(IconsApp.clockIcon),
                                ),
                                appText(
                                    myText: awayinTime,
                                    myfontSize: 10,
                                    isbold: true)
                              ],
                            ),
                          ),
                          SizedBox(
                            width: w * 0.01,
                          ),
                          Container(
                            height: h * 0.03,
                            width: w * 0.16,
                            clipBehavior: Clip.antiAlias,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: AppColors.secondaryColor),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                SizedBox(
                                  width: w * 0.03,
                                  height: h * 0.015,
                                  child: Image.asset(IconsApp.fromlocationIcon),
                                ),
                                appText(
                                    myText: kmaway,
                                    myfontSize: 10,
                                    isbold: true)
                              ],
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                )),
          ),
        ],
      ),
    );
  });
}

// Widget resturantsWidget({
//   required String resturantImagePath,
//   required String resturantFood,
//   required String resturantName,
//   required String location,
//   required String rating,
//   required String price,
//   required String kmaway,
//   required String awayinTime,
//   required onTap,
// }) {
//   return Builder(builder: (context) {
//     final h = MediaQuery.of(context).size.height;
//     final w = MediaQuery.of(context).size.width;
//     return GestureDetector(
//       onTap: onTap,
//       child: Container(
//         height: h * 0.16,
//         width: w * 0.55,
//         clipBehavior: Clip.antiAlias,
//         margin: const EdgeInsets.only(right: 8),
//         decoration: BoxDecoration(
//             image: DecorationImage(
//                 image: AssetImage(resturantImagePath), fit: BoxFit.fill),
//             borderRadius: BorderRadius.circular(10)),
//         child: Container(
//           padding: const EdgeInsets.all(8),
//           decoration: const BoxDecoration(
//               image: DecorationImage(
//                   image: AssetImage(ImagesApp.showdowImage), fit: BoxFit.fill)),
//           child: Column(
//             children: [
//               SizedBox(
//                 height: h * 0.1,
//                 width: w,
//                 child: Row(
//                   children: [
//                     SizedBox(
//                       height: h * 0.1,
//                       width: w * 0.38,
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                         children: [
//                           appText(
//                               myText: resturantFood,
//                               isbold: true,
//                               myColors: AppColors.whiteColor),
//                           appText(
//                               myText: resturantName,
//                               isbold: true,
//                               myfontSize: 16,
//                               myColors: AppColors.whiteColor),
//                           appText(
//                               myText: location,
//                               isbold: true,
//                               myColors: AppColors.whiteColor)
//                         ],
//                       ),
//                     ),
//                     Expanded(
//                         child: Column(
//                       children: [
//                         Container(
//                           height: h * 0.025,
//                           width: w * 0.1,
//                           decoration: BoxDecoration(
//                               color: AppColors.secondaryColor,
//                               borderRadius: BorderRadius.circular(10)),
//                           child: Center(
//                             child: appText(
//                                 myText: rating, isbold: true, myfontSize: 10),
//                           ),
//                         )
//                       ],
//                     ))
//                   ],
//                 ),
//               ),
//               Expanded(
//                   child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Container(
//                     height: h * 0.03,
//                     width: w * 0.16,
//                     clipBehavior: Clip.antiAlias,
//                     decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         color: AppColors.secondaryColor),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       children: [
//                         SizedBox(
//                           height: h * 0.015,
//                           width: w * 0.03,
//                           child: Image.asset(IconsApp.dollarIcon),
//                         ),
//                         appText(myText: price, myfontSize: 10, isbold: true)
//                       ],
//                     ),
//                   ),
//                   Container(
//                     height: h * 0.03,
//                     width: w * 0.16,
//                     clipBehavior: Clip.antiAlias,
//                     decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         color: AppColors.secondaryColor),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       children: [
//                         SizedBox(
//                           width: w * 0.03,
//                           height: h * 0.015,
//                           child: Image.asset(IconsApp.fromlocationIcon),
//                         ),
//                         appText(myText: kmaway, myfontSize: 10, isbold: true)
//                       ],
//                     ),
//                   ),
//                   Container(
//                     height: h * 0.03,
//                     width: w * 0.16,
//                     clipBehavior: Clip.antiAlias,
//                     decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         color: AppColors.secondaryColor),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       children: [
//                         SizedBox(
//                           width: w * 0.03,
//                           height: h * 0.015,
//                           child: Image.asset(IconsApp.clockIcon),
//                         ),
//                         appText(
//                             myText: awayinTime, myfontSize: 10, isbold: true)
//                       ],
//                     ),
//                   )
//                 ],
//               ))
//             ],
//           ),
//         ),
//       ),
//     );
//   });
// }
