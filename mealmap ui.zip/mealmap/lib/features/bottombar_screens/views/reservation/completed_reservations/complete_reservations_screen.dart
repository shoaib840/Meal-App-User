import 'package:mealmap/utilz/constants/exports.dart';

class CompletedReservationScreen extends StatefulWidget {
  const CompletedReservationScreen({super.key});

  @override
  State<CompletedReservationScreen> createState() =>
      _CompletedReservationScreenState();
}

class _CompletedReservationScreenState
    extends State<CompletedReservationScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Container(
      color: AppColors.whiteColor,
      height: h,
      width: w,
      child: Column(
        children: [
          SizedBox(
            height: h * 0.01,
          ),
          Expanded(
              child: SingleChildScrollView(
            child: Column(
              children: [
                for (int i = 0; i < 10; i++) ...{
                  completereservationBox(
                      resturantImagePath: ImagesApp.resturantImage,
                      foodType: "Italian",
                      resturantName: "Don Giovanni",
                      locationOfRes: "75008, Paris",
                      resturantsRating: "9.5",
                      comingDaysLeftOfOrder: "22/08/2024",
                      timeOfOrder: "11:00 PM",
                      personsForOrder: "2 ${appLocal!.persons}",
                      percentDiscountOnOrder: "30%",
                      requestForBillOnTap: () {
                        Navigator.push(
                            context, createRoute(newPage: const BillScreen()));
                      })
                }
              ],
            ),
          ))
        ],
      ),
    );
  }
}
