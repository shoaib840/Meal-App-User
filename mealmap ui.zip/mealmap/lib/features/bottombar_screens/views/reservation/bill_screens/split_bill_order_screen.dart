import 'package:mealmap/utilz/constants/exports.dart';

class SplitBillScreen extends StatefulWidget {
  const SplitBillScreen({super.key});

  @override
  State<SplitBillScreen> createState() => _SplitBillScreenState();
}

class _SplitBillScreenState extends State<SplitBillScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              height: h,
              width: w,
              padding: EdgeInsets.symmetric(horizontal: w * 0.04),
              child: Column(
                children: [
                  SizedBox(
                    height: h * 0.01,
                  ),
                  Row(
                    children: [
                      arrowBack(),
                      SizedBox(
                        width: w * 0.02,
                      ),
                      appText(
                          myText:
                              "${appLocal!.split} ${appLocal.bill}", //"Split Bill",
                          isbold: true),
                    ],
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  SizedBox(
                    height: h * 0.05,
                    width: w * 0.1,
                    child: Image.asset(IconsApp.appIcon),
                  ),
                  SizedBox(
                    height: h * 0.01,
                  ),
                  appText(myText: "MealApp", isbold: true, myfontSize: 30),
                  SizedBox(
                    height: h * 0.04,
                  ),
                  appText(
                      myText: appLocal.yourbillis, //"Your bill is",
                      isbold: true,
                      myfontSize: 18),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Container(
                    width: w,
                    padding: EdgeInsets.symmetric(
                        horizontal: w * 0.02, vertical: h * 0.02),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.2),
                          spreadRadius: 3,
                          blurRadius: 5,
                          offset:
                              const Offset(0, 3), // changes position of shadow
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            appText(
                                myText:
                                    appLocal.ordersummary, //"Order summary",
                                isbold: true,
                                myfontSize: 14),
                          ],
                        ),
                        SizedBox(
                          height: h * 0.01,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            appText(
                                myText: appLocal.people, //"People",
                                isbold: true),
                            appText(myText: "3", isbold: true)
                          ],
                        ),
                        SizedBox(
                          height: h * 0.01,
                        ),
                        splistBillWidget(
                            filedName: appLocal.total, //"Total",
                            filedAns: "\$90"),
                        splistBillWidget(
                            filedName:
                                appLocal.amountperperson, //"Amount per person",
                            filedAns: "\$30"),
                        const Divider(
                          color: AppColors.greyColor,
                        ),
                        SizedBox(
                          height: h * 0.01,
                        ),
                        splistBillWidget(
                            filedName: "${appLocal.person} 1",
                            filedAns: "\$90"),
                        splistBillWidget(
                            filedName: "${appLocal.person} 2",
                            filedAns: "\$30"),
                        splistBillWidget(
                            filedName: "${appLocal.person} 3",
                            filedAns: "\$30"),
                      ],
                    ),
                  ),
                  const Spacer(),
                  SizedBox(
                    height: h * 0.065,
                    width: w * 0.8,
                    child: appButton(
                        buttonClickColor: AppColors.primaryColor,
                        buttonColor: AppColors.whiteColor,
                        buttonText: appLocal.modifyamounts, //"Modify amounts",
                        ontapfunction: () {}),
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  appText(myText: appLocal.or //"Or"
                      ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  SizedBox(
                    height: h * 0.065,
                    width: w * 0.8,
                    child: appButton(
                        buttonText:
                            appLocal.generateQRcode, //"Generate QR code",
                        ontapfunction: () {}),
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                ],
              ),
            )));
  }
}

Widget splistBillWidget({required filedName, required filedAns}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            appText(myText: filedName, isbold: true),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 15),
              decoration: BoxDecoration(
                  color: AppColors.secondaryColor,
                  borderRadius: BorderRadius.circular(10)),
              child: Center(child: appText(myText: filedAns)),
            )
          ],
        ),
        SizedBox(
          height: h * 0.01,
        )
      ],
    );
  });
}
