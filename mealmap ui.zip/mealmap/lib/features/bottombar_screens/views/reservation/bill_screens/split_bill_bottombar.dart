import 'package:mealmap/utilz/constants/exports.dart';

class SplitBillBottomBar extends StatefulWidget {
  const SplitBillBottomBar({super.key});

  @override
  State<SplitBillBottomBar> createState() => _SplitBillBottomBarState();
}

class _SplitBillBottomBarState extends State<SplitBillBottomBar> {
  int splitPersons = 0;
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: const BoxDecoration(
          color: AppColors.whiteColor,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(15), topRight: Radius.circular(15))),
      margin: EdgeInsets.only(
        left: w * 0.04,
        right: w * 0.04,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      height: h * 0.38,
      child: Column(
        children: [
          SizedBox(
            height: h * 0.06,
            width: w,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  width: w * 0.1,
                ),
                appText(
                    myText: appLocal!
                        .enternumberofpeople, //"Enter number of people",
                    isbold: true),
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(Icons.close))
              ],
            ),
          ),
          SizedBox(
            height: h * 0.05,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 25,
                width: 25,
                decoration: const BoxDecoration(
                    color: AppColors.primaryColor, shape: BoxShape.circle),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    splashColor: Colors.white,
                    onTap: () {
                      if (splitPersons > 0) {
                        setState(() {
                          splitPersons--;
                        });
                      }
                    },
                    child: Center(
                      child: appText(myText: "-", isbold: true, myfontSize: 14),
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: w * 0.04,
              ),
              Container(
                height: h * 0.08,
                width: w * 0.2,
                decoration: BoxDecoration(
                    color: AppColors.secondaryColor,
                    borderRadius: BorderRadius.circular(10)),
                child: Center(
                    child: appText(
                        myText: splitPersons.toString(),
                        isbold: true,
                        myfontSize: 28)),
              ),
              SizedBox(
                width: w * 0.04,
              ),
              Container(
                height: 25,
                width: 25,
                decoration: const BoxDecoration(
                    color: AppColors.primaryColor, shape: BoxShape.circle),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    splashColor: Colors.white,
                    onTap: () {
                      setState(() {
                        splitPersons++;
                      });
                    },
                    child: Center(
                      child: appText(myText: "+", isbold: true, myfontSize: 14),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const Spacer(),
          SizedBox(
            height: h * 0.065,
            width: w,
            child: appButton(
                buttonText: appLocal.continuee, //"Continue",
                ontapfunction: () {
                  Navigator.push(
                      context, createRoute(newPage: const SplitBillScreen()));
                }),
          ),
          SizedBox(
            height: h * 0.02,
          ),
        ],
      ),
    );
  }
}
