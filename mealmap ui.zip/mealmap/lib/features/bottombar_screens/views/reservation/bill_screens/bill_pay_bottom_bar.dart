import 'package:mealmap/utilz/constants/exports.dart';

class PayBillBottomBar extends StatefulWidget {
  final bool isReservationBill;
  const PayBillBottomBar({super.key, required this.isReservationBill});

  @override
  State<PayBillBottomBar> createState() => _PayBillBottomBarState();
}

class _PayBillBottomBarState extends State<PayBillBottomBar> {
  bool payWithCard = true;
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: const BoxDecoration(
          color: AppColors.whiteColor,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(15), topRight: Radius.circular(15))),
      margin: EdgeInsets.only(
        left: w * 0.04,
        right: w * 0.04,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      height: h * 0.38,
      child: Column(
        children: [
          SizedBox(
            height: h * 0.06,
            width: w,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  width: w * 0.1,
                ),
                appText(
                    myText: appLocal!
                        .selectpaymentmethod, //"Select payment method",
                    isbold: true),
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(Icons.close))
              ],
            ),
          ),
          SizedBox(
            height: h * 0.01,
          ),
          billBottomBarButton(
              imagePath: IconsApp.cardIcon,
              onTap: () {
                setState(() {
                  payWithCard = true;
                });
              },
              name: appLocal.card, //"Card",
              color: payWithCard
                  ? AppColors.secondaryColor
                  : AppColors.whiteColor),
          SizedBox(
            height: h * 0.01,
          ),
          billBottomBarButton(
              imagePath: IconsApp.dollarIcon,
              onTap: () {
                setState(() {
                  payWithCard = false;
                });
              },
              name: appLocal.mycash, //"My cash",
              color: payWithCard
                  ? AppColors.whiteColor
                  : AppColors.secondaryColor),
          const Spacer(),
          SizedBox(
            height: h * 0.065,
            width: w,
            child: appButton(
                buttonText: appLocal.continuee, //"Continue",
                ontapfunction: () {
                  if (widget.isReservationBill == false) {
                    Navigator.push(context,
                        createRoute(newPage: const CartCompleteBillScreen()));
                  }
                }),
          ),
          SizedBox(
            height: h * 0.02,
          ),
        ],
      ),
    );
  }
}

Widget billBottomBarButton(
    {required String imagePath,
    required onTap,
    required String name,
    required Color color}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: h * 0.07,
        width: w,
        padding: EdgeInsets.symmetric(horizontal: w * 0.02),
        decoration: BoxDecoration(
            color: color, borderRadius: BorderRadius.circular(10)),
        child: Row(
          children: [
            SizedBox(
              height: h * 0.03,
              width: w * 0.12,
              child: Image.asset(imagePath),
            ),
            SizedBox(
              width: w * 0.04,
            ),
            appText(myText: name, isbold: true)
          ],
        ),
      ),
    );
  });
}
