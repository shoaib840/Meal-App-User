import 'package:mealmap/utilz/constants/exports.dart';

class ReservationScreen extends StatefulWidget {
  const ReservationScreen({super.key});

  @override
  State<ReservationScreen> createState() => _ReservationScreenState();
}

class _ReservationScreenState extends State<ReservationScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: AppColors.backgroundColor,
        body: Container(
          height: h,
          width: w,
          padding: EdgeInsets.only(left: w * 0.02, right: w * 0.02),
          child: Column(
            children: [
              SizedBox(
                height: h * 0.01,
              ),
              Row(
                children: [
                  appText(
                      myText: appLocal!.reservations, //"Reservations",
                      isbold: true,
                      myfontSize: 14),
                ],
              ),
              SizedBox(
                height: h * 0.03,
              ),
              Container(
                height: h * 0.05,
                width: w,
                decoration: BoxDecoration(
                  color: AppColors.primaryColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: TabBar(
                  dividerColor: Colors.transparent,
                  indicatorColor: AppColors.blackColor,
                  controller: _tabController,
                  labelColor: AppColors.primaryColor,
                  tabs: [
                    Tab(
                      child: appText(
                        myText: appLocal.upcoming, //"Upcoming",
                        isbold: true,
                        myfontSize: 14,
                      ),
                    ),
                    Tab(
                      child: appText(
                        myText: appLocal.completed, //"Completed",
                        isbold: true,
                        myfontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: h * 0.02,
              ),
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: const [
                    UpcomingReserversions(),
                    CompletedReservationScreen()
                  ],
                ),
              ),
              SizedBox(
                height: h * 0.1,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
