import 'package:mealmap/utilz/constants/exports.dart';

class ManageUpcomingReservation extends StatefulWidget {
  const ManageUpcomingReservation({super.key});

  @override
  State<ManageUpcomingReservation> createState() =>
      _ManageUpcomingReservationState();
}

class _ManageUpcomingReservationState extends State<ManageUpcomingReservation> {
  GoogleMapController? controller;
  static const LatLng _center =
      LatLng(37.7749, -122.4194); // San Francisco coordinates

  final Set<Marker> markers = {
    const Marker(
      markerId: MarkerId('defaultMarker'),
      position: _center,
      infoWindow: InfoWindow(title: 'San Francisco'),
      icon: BitmapDescriptor.defaultMarker,
    ),
  };
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              padding: EdgeInsets.symmetric(horizontal: w * 0.02),
              height: h,
              width: w,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: h * 0.01,
                    ),
                    Row(
                      children: [
                        arrowBack(),
                        SizedBox(
                          width: w * 0.03,
                        ),
                        appText(
                            myText: appLocal!
                                .managereservation, //"Manage reservation",
                            isbold: true)
                      ],
                    ),
                    SizedBox(
                      height: h * 0.03,
                    ),
                    appText(
                        myText: appLocal
                            .pleasereviewyourreservationdetails //"Please review your reservation details"
                        ),
                    Container(
                      margin: EdgeInsets.only(
                        left: w * 0.01,
                        right: w * 0.01,
                        bottom: h * 0.01,
                      ),
                      padding: EdgeInsets.symmetric(
                          horizontal: h * 0.01, vertical: w * 0.02),
                      width: w,
                      decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.2),
                              spreadRadius: 2,
                              blurRadius: 4,
                              offset: const Offset(
                                  0, 3), // changes position of shadow
                            ),
                          ],
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10)),
                      child: Column(
                        children: [
                          SizedBox(
                            height: h * 0.13,
                            width: w,
                            child: Row(
                              children: [
                                Container(
                                  height: h * 0.13,
                                  width: w * 0.38,
                                  clipBehavior: Clip.antiAlias,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10)),
                                  child: Image.asset(
                                    ImagesApp.resturantImage,
                                    fit: BoxFit.fill,
                                  ),
                                ),
                                SizedBox(
                                  width: w * 0.02,
                                ),
                                //-----------------------------------//
                                SizedBox(
                                  height: h * 0.13,
                                  width: w * 0.39,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      appText(myText: "Italian"),
                                      appText(
                                          myText: "Don Giovanni",
                                          myfontSize: 14,
                                          isbold: true),
                                      appText(
                                          myText: "75008, Paris",
                                          myfontSize: 10),
                                      Container(
                                        height: h * 0.03,
                                        width: w * 0.27,
                                        clipBehavior: Clip.antiAlias,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          color: AppColors.greenColor,
                                        ),
                                        child: Row(
                                          children: [
                                            SizedBox(
                                              width: w * 0.01,
                                            ),
                                            Container(
                                              height: h * 0.025,
                                              width: w * 0.05,
                                              decoration: const BoxDecoration(
                                                  color: AppColors.whiteColor,
                                                  shape: BoxShape.circle),
                                              child: const Icon(
                                                Icons.check,
                                                color: AppColors.greenColor,
                                                size: 10,
                                              ),
                                            ),
                                            SizedBox(
                                              width: w * 0.01,
                                            ),
                                            appText(
                                                myText: appLocal
                                                    .confirmed, //"Confirmed",
                                                myfontSize: 8,
                                                isbold: true)
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                const Spacer(),
                                SizedBox(
                                  height: h * 0.13,
                                  width: w * 0.1,
                                  child: Column(
                                    children: [
                                      Container(
                                        height: h * 0.025,
                                        width: w * 0.1,
                                        decoration: BoxDecoration(
                                            color: AppColors.secondaryColor,
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: Center(
                                          child: appText(
                                              myText: "8.8",
                                              isbold: true,
                                              myfontSize: 10),
                                        ),
                                      ),
                                      const Spacer(),
                                      SizedBox(
                                        height: h * 0.01,
                                      )
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                          //---------------------------------------------------------------------------------------------//
                          SizedBox(
                            height: h * 0.01,
                          ),
                          SizedBox(
                            height: h * 0.06,
                            width: w,
                            child: Row(
                              children: [
                                Container(
                                  height: h * 0.06,
                                  width: w * 0.75,
                                  decoration: BoxDecoration(
                                      color: AppColors.secondaryColor,
                                      borderRadius: BorderRadius.circular(10)),
                                  child: Row(
                                    children: [
                                      SizedBox(
                                        height: h * 0.06,
                                        width: w * 0.25,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                              height: h * 0.05,
                                              width: w * 0.04,
                                              child: Image.asset(
                                                  IconsApp.calenderIcon),
                                            ),
                                            SizedBox(
                                              width: w * 0.01,
                                            ),
                                            appText(
                                                myText: "22/08/2024",
                                                isbold: true,
                                                myfontSize: 10)
                                          ],
                                        ),
                                      ),
                                      SizedBox(
                                        height: h * 0.06,
                                        width: w * 0.24,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                              height: h * 0.05,
                                              width: w * 0.04,
                                              child: Image.asset(
                                                  IconsApp.clockIcon),
                                            ),
                                            SizedBox(
                                              width: w * 0.01,
                                            ),
                                            appText(
                                                myText: "11:20PM",
                                                isbold: true,
                                                myfontSize: 10)
                                          ],
                                        ),
                                      ),
                                      SizedBox(
                                        height: h * 0.06,
                                        width: w * 0.26,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                              height: h * 0.05,
                                              width: w * 0.04,
                                              child: Image.asset(
                                                  IconsApp.personsIcon),
                                            ),
                                            SizedBox(
                                              width: w * 0.01,
                                            ),
                                            appText(
                                                myText: "2 ${appLocal.persons}",
                                                isbold: true,
                                                myfontSize: 10)
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: w * 0.01,
                                ),
                                Expanded(
                                    child: Container(
                                  height: h * 0.06,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: AppColors.yellowColor),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      SizedBox(
                                        height: h * 0.05,
                                        width: w * 0.035,
                                        child: Image.asset(
                                          IconsApp.dollarBadgeIcon,
                                        ),
                                      ),
                                      appText(
                                          myText: "30%",
                                          myfontSize: 10,
                                          isbold: true)
                                    ],
                                  ),
                                ))
                              ],
                            ),
                          ),
                          //----------------------------------------------------------------------------------------//
                          SizedBox(
                            height: h * 0.02,
                          ),
                          Container(
                            height: h * 0.05,
                            width: w,
                            clipBehavior: Clip.antiAlias,
                            decoration: BoxDecoration(
                                color: AppColors.blackColor,
                                borderRadius: BorderRadius.circular(20)),
                            child: Row(
                              children: [
                                GestureDetector(
                                  onTap: () {},
                                  child: SizedBox(
                                    height: h * 0.05,
                                    width: w * 0.4,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          height: h * 0.025,
                                          width: w * 0.08,
                                          child:
                                              Image.asset(IconsApp.callingIcon),
                                        ),
                                        appText(
                                            myText: appLocal
                                                        .callrestaurant.length <
                                                    16
                                                ? appLocal.callrestaurant
                                                : "${appLocal.callrestaurant.toString().substring(0, 15)}...", //"Call restaurant",
                                            myfontSize: 10,
                                            myColors: AppColors.whiteColor)
                                      ],
                                    ),
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () {},
                                  child: SizedBox(
                                    height: h * 0.05,
                                    width: w * 0.22,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          height: h * 0.022,
                                          width: w * 0.08,
                                          child: const Icon(
                                            size: 15,
                                            Icons.edit,
                                            color: AppColors.primaryColor,
                                          ),
                                        ),
                                        appText(
                                            myText: appLocal.edit.length < 7
                                                ? appLocal.edit
                                                : "${appLocal.edit.toString().substring(0, 6)}..", // "Edit",
                                            myfontSize: 10,
                                            myColors: AppColors.whiteColor)
                                      ],
                                    ),
                                  ),
                                ),
                                Expanded(
                                    child: GestureDetector(
                                  onTap: () {},
                                  child: Container(
                                    height: h * 0.05,
                                    decoration: BoxDecoration(
                                        color: Colors.red,
                                        borderRadius:
                                            BorderRadius.circular(20)),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          height: h * 0.025,
                                          width: w * 0.08,
                                          child:
                                              Image.asset(IconsApp.cancelIcon),
                                        ),
                                        appText(
                                            myText: appLocal.cancel.length < 8
                                                ? appLocal.cancel
                                                : "${appLocal.cancel.toString().substring(0, 7)}...", //"Cancel",
                                            myfontSize: 10,
                                            myColors: AppColors.whiteColor)
                                      ],
                                    ),
                                  ),
                                ))
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                    //-----------------------------------------------------------------------------//

                    SizedBox(
                      height: h * 0.02,
                    ),
                    appText(
                        myText: appLocal
                            .abouttherestaurant, //"About the restaurant",
                        isbold: true),
                    appText(
                        myText:
                            "Located in the very heart of the historical neighbourhood, Don Giovanni provides a relaxing, welcoming ambiance with uncluttered decor - with exposed beams and subdue lighting."),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    Row(
                      children: [
                        SizedBox(
                          height: 15,
                          width: 15,
                          child: Image.asset(IconsApp.locationIcon),
                        ),
                        SizedBox(
                          width: w * 0.01,
                        ),
                        appText(
                            myText:
                                "19, rue Français Miran 75004 Paris, France",
                            isbold: true)
                      ],
                    ),
                    //---------------------------------------------------------------------------//
                    SizedBox(
                      height: h * 0.02,
                    ),
                    Container(
                      height: h * 0.2,
                      width: w,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10)),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: GoogleMap(
                          initialCameraPosition: const CameraPosition(
                            target: _center,
                            zoom: 13,
                          ),
                          markers: markers,
                          onMapCreated: (GoogleMapController controller) {
                            controller = controller;
                          },
                        ),
                      ),
                    ),
                    SizedBox(
                      height: h * 0.05,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          height: h * 0.065,
                          width: w * 0.8,
                          child: appButton(
                              buttonColor: AppColors.greenColor,
                              borderColor: AppColors.greenColor,
                              buttonText:
                                  appLocal.markascomplete, //"Mark as complete",
                              ontapfunction: () {}),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: h * 0.02,
                    )
                  ],
                ),
              ),
            )));
  }
}
