import 'package:mealmap/utilz/constants/exports.dart';

Widget upcomingReservationBox({
  required String resturantImagePath,
  required String foodType,
  required String resturantName,
  required String locationOfRes,
  required String resturantsRating,
  required onTapEditThis,
  required String comingDaysLeftOfOrder,
  required String timeOfOrder,
  required String personsForOrder,
  required String percentDiscountOnOrder,
  required onTapCallingResturant,
  required onTapShare,
  required onTapCancel,
}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Container(
      margin: EdgeInsets.only(
        left: w * 0.01,
        right: w * 0.01,
        bottom: h * 0.01,
      ),
      padding: EdgeInsets.symmetric(horizontal: h * 0.01, vertical: w * 0.02),
      width: w,
      decoration: BoxDecoration(boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.2),
          spreadRadius: 2,
          blurRadius: 4,
          offset: const Offset(0, 3), // changes position of shadow
        ),
      ], color: Colors.white, borderRadius: BorderRadius.circular(10)),
      child: Column(
        children: [
          SizedBox(
            height: h * 0.13,
            width: w,
            child: Row(
              children: [
                Container(
                  height: h * 0.13,
                  width: w * 0.38,
                  clipBehavior: Clip.antiAlias,
                  decoration:
                      BoxDecoration(borderRadius: BorderRadius.circular(10)),
                  child: Image.asset(
                    resturantImagePath,
                    fit: BoxFit.fill,
                  ),
                ),
                SizedBox(
                  width: w * 0.02,
                ),
                //-----------------------------------//
                SizedBox(
                  height: h * 0.13,
                  width: w * 0.39,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      appText(myText: foodType),
                      appText(
                          myText: resturantName, myfontSize: 14, isbold: true),
                      appText(myText: locationOfRes, myfontSize: 10),
                      Container(
                        height: h * 0.03,
                        width: w * 0.27,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: AppColors.greenColor,
                        ),
                        child: Row(
                          children: [
                            SizedBox(
                              width: w * 0.01,
                            ),
                            Container(
                              height: h * 0.025,
                              width: w * 0.05,
                              decoration: const BoxDecoration(
                                  color: AppColors.whiteColor,
                                  shape: BoxShape.circle),
                              child: const Icon(
                                Icons.check,
                                color: AppColors.greenColor,
                                size: 10,
                              ),
                            ),
                            SizedBox(
                              width: w * 0.01,
                            ),
                            appText(
                                myText: appLocal!.confirmed, //"Confirmed",
                                myfontSize: 8,
                                isbold: true)
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                const Spacer(),
                SizedBox(
                  height: h * 0.13,
                  width: w * 0.1,
                  child: Column(
                    children: [
                      Container(
                        height: h * 0.025,
                        width: w * 0.1,
                        decoration: BoxDecoration(
                            color: AppColors.secondaryColor,
                            borderRadius: BorderRadius.circular(10)),
                        child: Center(
                          child: appText(
                              myText: resturantsRating,
                              isbold: true,
                              myfontSize: 10),
                        ),
                      ),
                      const Spacer(),
                      Container(
                        height: h * 0.032,
                        width: w * 0.09,
                        decoration: const BoxDecoration(
                            color: AppColors.primaryColor,
                            shape: BoxShape.circle),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: onTapEditThis,
                            splashColor: AppColors.whiteColor,
                            child: const Icon(
                              Icons.edit,
                              color: AppColors.blackColor,
                              size: 10,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: h * 0.01,
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
          //---------------------------------------------------------------------------------------------//
          SizedBox(
            height: h * 0.01,
          ),
          SizedBox(
            height: h * 0.06,
            width: w,
            child: Row(
              children: [
                Container(
                  height: h * 0.06,
                  width: w * 0.75,
                  decoration: BoxDecoration(
                      color: AppColors.secondaryColor,
                      borderRadius: BorderRadius.circular(10)),
                  child: Row(
                    children: [
                      SizedBox(
                        height: h * 0.06,
                        width: w * 0.25,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: h * 0.05,
                              width: w * 0.04,
                              child: Image.asset(IconsApp.calenderIcon),
                            ),
                            SizedBox(
                              width: w * 0.01,
                            ),
                            appText(
                                myText: comingDaysLeftOfOrder,
                                isbold: true,
                                myfontSize: 10)
                          ],
                        ),
                      ),
                      SizedBox(
                        height: h * 0.06,
                        width: w * 0.24,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: h * 0.05,
                              width: w * 0.04,
                              child: Image.asset(IconsApp.clockIcon),
                            ),
                            SizedBox(
                              width: w * 0.01,
                            ),
                            appText(
                                myText: timeOfOrder,
                                isbold: true,
                                myfontSize: 10)
                          ],
                        ),
                      ),
                      SizedBox(
                        height: h * 0.06,
                        width: w * 0.26,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: h * 0.05,
                              width: w * 0.04,
                              child: Image.asset(IconsApp.personsIcon),
                            ),
                            SizedBox(
                              width: w * 0.01,
                            ),
                            appText(
                                myText: personsForOrder,
                                isbold: true,
                                myfontSize: 10)
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  width: w * 0.01,
                ),
                Expanded(
                    child: Container(
                  height: h * 0.06,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: AppColors.yellowColor),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        height: h * 0.05,
                        width: w * 0.035,
                        child: Image.asset(
                          IconsApp.dollarBadgeIcon,
                        ),
                      ),
                      appText(
                          myText: percentDiscountOnOrder,
                          myfontSize: 10,
                          isbold: true)
                    ],
                  ),
                ))
              ],
            ),
          ),
          //----------------------------------------------------------------------------------------//
          SizedBox(
            height: h * 0.02,
          ),
          Container(
            height: h * 0.05,
            width: w,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
                color: AppColors.blackColor,
                borderRadius: BorderRadius.circular(20)),
            child: Row(
              children: [
                GestureDetector(
                  onTap: onTapCallingResturant,
                  child: SizedBox(
                    height: h * 0.05,
                    width: w * 0.4,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          height: h * 0.025,
                          width: w * 0.08,
                          child: Image.asset(IconsApp.callingIcon),
                        ),
                        appText(
                            myText: appLocal.callrestaurant.length < 17
                                ? appLocal.callrestaurant
                                : "${appLocal.callrestaurant.toString().substring(0, 16)}...", //"Call restaurant",
                            myfontSize: 10,
                            myColors: AppColors.whiteColor)
                      ],
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: onTapShare,
                  child: SizedBox(
                    height: h * 0.05,
                    width: w * 0.22,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          height: h * 0.022,
                          width: w * 0.08,
                          child: Image.asset(IconsApp.shareNewIcon),
                        ),
                        appText(
                            myText: appLocal.share.length < 7
                                ? appLocal.share
                                : "${appLocal.share.toString().substring(0, 6)}..", //"Share",
                            myfontSize: 10,
                            myColors: AppColors.whiteColor)
                      ],
                    ),
                  ),
                ),
                Expanded(
                    child: GestureDetector(
                  onTap: onTapCancel,
                  child: Container(
                    height: h * 0.05,
                    decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(20)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          height: h * 0.025,
                          width: w * 0.08,
                          child: Image.asset(IconsApp.cancelIcon),
                        ),
                        appText(
                            myText: appLocal.cancel.length < 8
                                ? appLocal.cancel
                                : "${appLocal.cancel.toString().substring(0, 7)}...", //"Cancel",
                            myfontSize: 10,
                            myColors: AppColors.whiteColor)
                      ],
                    ),
                  ),
                ))
              ],
            ),
          )
        ],
      ),
    );
  });
}
