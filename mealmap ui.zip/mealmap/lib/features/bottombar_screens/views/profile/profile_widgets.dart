import 'package:mealmap/utilz/constants/exports.dart';

Widget profileCustomTextField({
  required String fieldName,
  required String mYhintText,
  myControler,
  fieldValidator,
  bool? removeBorder = true,
  bool obsecureText = false,
  required keyBordType,
  double? borderRadius,
  suffixIconOnTap,
  suffixIcon,
  prefixIcon,
  prefixIconOnTap,
  boxShadow = false,
  bool textInputTypeNumber = false,
  bool readOnly = false,
  onChange,
  int maxLiness = 1,
  int? maxLength, // Add this line for setting maximum character limit
}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        appText(myText: "  $fieldName"),
        SizedBox(
          height: h * 0.01,
        ),
        TextFormField(
          onChanged: onChange,
          validator: fieldValidator,
          maxLines: maxLiness,
          maxLength: maxLength, // Set the maximum character limit
          keyboardType: keyBordType,
          controller: myControler,
          obscureText: obsecureText,
          readOnly: readOnly,
          style: const TextStyle(fontFamily: "Poppins"),
          inputFormatters: <TextInputFormatter>[
            textInputTypeNumber == true
                ? FilteringTextInputFormatter.digitsOnly
                : FilteringTextInputFormatter.singleLineFormatter
          ],
          decoration: InputDecoration(
            prefixIcon: prefixIcon != null
                ? GestureDetector(
                    onTap: prefixIconOnTap,
                    child: Container(
                      height: h * 0.06,
                      width: w * 0.04,
                      padding: const EdgeInsets.all(14),
                      child: Icon(
                        prefixIcon,
                        color: AppColors.blackColor,
                      ),
                    ),
                  )
                : null,
            suffixIcon: suffixIcon != null
                ? GestureDetector(
                    onTap: suffixIconOnTap,
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Container(
                        height: h * 0.04,
                        width: w * 0.04,
                        decoration: const BoxDecoration(
                            color: AppColors.whiteColor,
                            shape: BoxShape.circle),
                        child: Center(
                          child: Icon(
                            suffixIcon,
                            size: 14,
                            color: AppColors.primaryColor,
                          ),
                        ),
                      ),
                    ),
                  )
                : null,
            hintText: mYhintText,
            hintStyle: const TextStyle(
              color: AppColors.blackColor,
              fontSize: 12,
              fontFamily: "Poppins",
            ),
            contentPadding: const EdgeInsets.fromLTRB(20.0, 5.0, 20.0, 5.0),
            filled: true,
            fillColor: AppColors.secondaryColor,
            focusColor: Colors.white,
            hoverColor: Colors.white,
            disabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(
                color: AppColors.primaryColor,
                width: 2.0,
              ),
              borderRadius: BorderRadius.circular(borderRadius ?? 30.0),
            ),
            border: OutlineInputBorder(
              borderSide: BorderSide(
                color: removeBorder == true
                    ? Colors.transparent
                    : AppColors.primaryColor,
                width: 2.0,
              ),
              borderRadius: BorderRadius.circular(borderRadius ?? 30.0),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: removeBorder == true
                    ? Colors.transparent
                    : AppColors.primaryColor,
                width: 2.0,
              ),
              borderRadius: BorderRadius.circular(borderRadius ?? 30.0),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: removeBorder == true
                    ? Colors.transparent
                    : AppColors.primaryColor,
                width: 2.0,
              ),
              borderRadius: BorderRadius.circular(borderRadius ?? 30.0),
            ),
            errorBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: removeBorder == true
                    ? Colors.transparent
                    : AppColors.primaryColor,
                width: 2.0,
              ),
              borderRadius: BorderRadius.circular(borderRadius ?? 30.0),
            ),
          ),
        ),
      ],
    );
  });
}

//-------------------------------------------

Widget newProfileWidgetForEditAndShow(
    {required String iconPath,
    required String filedName,
    required String filedAns,
    required onEditTap}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SizedBox(
      width: w,
      child: Column(
        children: [
          SizedBox(
            height: h * 0.04,
            width: w,
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  height: h * 0.035,
                  width: w * 0.07,
                  child: Image.asset(
                    iconPath,
                    color: AppColors.primaryColor,
                  ),
                ),
                SizedBox(
                  width: w * 0.02,
                ),
                appText(
                  myText: filedName,
                  myfontSize: 13,
                  isbold: true,
                )
              ],
            ),
          ),
          Row(
            children: [
              Container(
                width: w * 0.09,
              ),
              appText(myText: filedAns, isbold: true, myfontSize: 10),
              const Spacer(),
              editBoxWidget(onTap: onEditTap)
            ],
          )
        ],
      ),
    );
  });
}
