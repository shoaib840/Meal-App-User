import 'package:mealmap/utilz/constants/exports.dart';

class EditAddressBottomsheet extends StatefulWidget {
  const EditAddressBottomsheet({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _EditAddressBottomsheetState createState() => _EditAddressBottomsheetState();
}

class _EditAddressBottomsheetState extends State<EditAddressBottomsheet> {
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  final TextEditingController confirmNewPasswordController =
      TextEditingController();

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: const BoxDecoration(
            color: AppColors.whiteColor,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15), topRight: Radius.circular(15))),
        margin: EdgeInsets.only(
          left: w * 0.04,
          right: w * 0.04,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        height: h * 0.8,
        child: Column(
          children: [
            SizedBox(
              height: h * 0.06,
              width: w,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: w * 0.1,
                  ),
                  appText(
                      myText: appLocal!.editaddress, //"Edit address",
                      isbold: true),
                  IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.close))
                ],
              ),
            ),
            SizedBox(
              height: h * 0.02,
            ),
            profileCustomTextField(
              fieldName: appLocal.streetaddress, //"Street address",
              myControler: passwordController,
              readOnly: false,
              mYhintText: "",
              keyBordType: TextInputType.name,
            ),
            SizedBox(
              height: h * 0.02,
            ),
            profileCustomTextField(
              fieldName: appLocal.city, // "City",
              myControler: newPasswordController,
              readOnly: false,
              mYhintText: "",
              keyBordType: TextInputType.name,
            ),
            SizedBox(
              height: h * 0.02,
            ),
            profileCustomTextField(
              fieldName: appLocal.state, //"State",
              myControler: confirmNewPasswordController,
              readOnly: false,
              mYhintText: "",
              keyBordType: TextInputType.name,
            ),
            SizedBox(
              height: h * 0.02,
            ),
            profileCustomTextField(
              fieldName: appLocal.postcode, //"Post code",
              myControler: passwordController,
              readOnly: false,
              mYhintText: "",
              keyBordType: TextInputType.name,
            ),
            SizedBox(
              height: h * 0.02,
            ),
            profileCustomTextField(
              fieldName: appLocal.country, //"Country",
              myControler: newPasswordController,
              readOnly: false,
              mYhintText: "",
              keyBordType: TextInputType.name,
            ),
            SizedBox(
              height: h * 0.02,
            ),
            const Spacer(),
            SizedBox(
              height: h * 0.065,
              width: w,
              child: appButton(
                  buttonText: appLocal.save, //"Save",
                  ontapfunction: () {}),
            )
          ],
        ),
      ),
    );
  }
}
