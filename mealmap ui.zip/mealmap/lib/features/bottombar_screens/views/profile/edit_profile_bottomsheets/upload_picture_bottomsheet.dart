import 'package:mealmap/utilz/constants/exports.dart';

class EditPictureBottomSheet extends StatefulWidget {
  const EditPictureBottomSheet({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _EditPictureBottomSheetState createState() => _EditPictureBottomSheetState();
}

class _EditPictureBottomSheetState extends State<EditPictureBottomSheet> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final imagePickRead = context.read<ImagePickerController>();
    final appLocal = AppLocalizations.of(context);
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: const BoxDecoration(
            color: AppColors.whiteColor,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15), topRight: Radius.circular(15))),
        margin: EdgeInsets.only(
          left: w * 0.04,
          right: w * 0.04,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        height: h * 0.3,
        child: Column(
          children: [
            SizedBox(
              height: h * 0.06,
              width: w,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: w * 0.1,
                  ),
                  appText(
                      myText: appLocal!.uploadpicture, // "Upload picture",
                      isbold: true),
                  IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.close))
                ],
              ),
            ),
            SizedBox(
              height: h * 0.02,
            ),
            GestureDetector(
              onTap: () {
                imagePickRead.pickImage(ImageSource.camera);
                Navigator.pop(context);
              },
              child: Container(
                height: h * 0.07,
                width: w,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: AppColors.secondaryColor.withOpacity(0.5)),
                child: Row(
                  children: [
                    SizedBox(
                      height: h * 0.025,
                      width: w * 0.18,
                      child: Image.asset(IconsApp.cameraIcon),
                    ),
                    appText(
                        myText: appLocal.camera, // "Camera",
                        isbold: true)
                  ],
                ),
              ),
            ),
            SizedBox(
              height: h * 0.01,
            ),
            GestureDetector(
              onTap: () {
                imagePickRead.pickImage(ImageSource.gallery);
                Navigator.pop(context);
              },
              child: Container(
                height: h * 0.07,
                width: w,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: AppColors.secondaryColor.withOpacity(0.5)),
                child: Row(
                  children: [
                    SizedBox(
                      height: h * 0.025,
                      width: w * 0.18,
                      child: Image.asset(IconsApp.galleryIcon),
                    ),
                    appText(
                        myText: appLocal.gallery, // "Gallery",
                        isbold: true)
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
