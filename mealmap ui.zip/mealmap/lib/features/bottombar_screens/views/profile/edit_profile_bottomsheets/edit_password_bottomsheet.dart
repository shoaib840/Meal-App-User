import 'package:mealmap/utilz/constants/exports.dart';

class EditPasswordBottomSheet extends StatefulWidget {
  const EditPasswordBottomSheet({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _EditPasswordBottomSheetState createState() =>
      _EditPasswordBottomSheetState();
}

class _EditPasswordBottomSheetState extends State<EditPasswordBottomSheet> {
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  final TextEditingController confirmNewPasswordController =
      TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  bool isCurrentPassShow = true;
  bool isNewPassShow = true;
  bool isConfirmPassShow = true;

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final authsWatch = context.watch<AuthssController>();
    final appLocal = AppLocalizations.of(context);
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: const BoxDecoration(
            color: AppColors.whiteColor,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15), topRight: Radius.circular(15))),
        margin: EdgeInsets.only(
          left: w * 0.04,
          right: w * 0.04,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        height: h * 0.65,
        child: authsWatch.isloading == false
            ? Form(
                key: formKey,
                child: Column(
                  children: [
                    SizedBox(
                      height: h * 0.06,
                      width: w,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            width: w * 0.1,
                          ),
                          appText(
                              myText: appLocal!.password, //"Change password",
                              isbold: true),
                          IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: const Icon(Icons.close))
                        ],
                      ),
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    profileCustomTextField(
                      fieldName: appLocal.password, //"Password",
                      myControler: passwordController,
                      readOnly: false,
                      obsecureText: isCurrentPassShow,
                      suffixIconOnTap: () {
                        isCurrentPassShow = !isCurrentPassShow;
                        setState(() {});
                      },
                      suffixIcon: isCurrentPassShow
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      fieldValidator: (value) {
                        if (value == null || value.isEmpty) {
                          return appLocal.required; //'Required';
                        }
                        if (value.toString().length < 6) {
                          return appLocal
                              .passwordIsTooSmall; //'Password is to small';
                        }
                        return null;
                      },
                      mYhintText: "*********",
                      keyBordType: TextInputType.name,
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    profileCustomTextField(
                      fieldName: appLocal.newpassword, //"New password",
                      myControler: newPasswordController,
                      readOnly: false,
                      obsecureText: isNewPassShow,
                      suffixIconOnTap: () {
                        isNewPassShow = !isNewPassShow;
                        setState(() {});
                      },
                      suffixIcon: isNewPassShow
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      fieldValidator: (value) {
                        if (value == null || value.isEmpty) {
                          return appLocal.required; //'Required';
                        }
                        if (value.toString().length < 6) {
                          return appLocal
                              .passwordIsTooSmall; //  return 'Password is to small';
                        }
                        return null;
                      },
                      mYhintText: "*********",
                      keyBordType: TextInputType.name,
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    profileCustomTextField(
                      fieldName:
                          appLocal.confirmnewpassword, //"Confirm new password",
                      myControler: confirmNewPasswordController,
                      readOnly: false,
                      mYhintText: "*********",
                      obsecureText: isConfirmPassShow,
                      suffixIconOnTap: () {
                        isConfirmPassShow = !isConfirmPassShow;
                        setState(() {});
                      },
                      suffixIcon: isConfirmPassShow
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      fieldValidator: (value) {
                        if (value == null || value.isEmpty) {
                          return appLocal.required; // 'Required';
                        }
                        if (value.toString().length < 6) {
                          return appLocal
                              .passwordIsTooSmall; //   return 'Password is to small';
                        }
                        if (value.toString() != newPasswordController.text) {
                          return appLocal
                              .passwordnotmatched; //"Password not matched";
                        }
                        return null;
                      },
                      keyBordType: TextInputType.name,
                    ),
                    const Spacer(),
                    SizedBox(
                      height: h * 0.065,
                      width: w,
                      child: appButton(
                          buttonText: appLocal.save, //"Save",
                          ontapfunction: () async {
                            if (formKey.currentState!.validate()) {
                              context.read<AuthssController>().changePassword(
                                  email: authsWatch.userData!['email'],
                                  currentPassword: passwordController.text,
                                  newPassword: newPasswordController.text,
                                  context: context);
                            }
                          }),
                    )
                  ],
                ),
              )
            : loading(backDardColor: false),
      ),
    );
  }
}
