import 'package:mealmap/utilz/constants/exports.dart';

class EditPhoneBottomsheet extends StatefulWidget {
  final String phone;
  const EditPhoneBottomsheet({super.key, required this.phone});

  @override
  // ignore: library_private_types_in_public_api
  _EditPhoneBottomsheetState createState() => _EditPhoneBottomsheetState();
}

class _EditPhoneBottomsheetState extends State<EditPhoneBottomsheet> {
  TextEditingController phoneNumberController = TextEditingController();
  String completePhoneNumber = '';

  @override
  void initState() {
    phoneNumberController = TextEditingController(text: widget.phone);
    super.initState();
  }

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final authsWatch = context.watch<AuthssController>();
    final authsRead = context.read<AuthssController>();
    final appLocal = AppLocalizations.of(context);
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: const BoxDecoration(
            color: AppColors.whiteColor,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15), topRight: Radius.circular(15))),
        margin: EdgeInsets.only(
          left: w * 0.04,
          right: w * 0.04,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        height: h * 0.37,
        child: authsWatch.isloading == false
            ? Form(
                key: formKey,
                child: Column(
                  children: [
                    SizedBox(
                      height: h * 0.06,
                      width: w,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            width: w * 0.1,
                          ),
                          appText(
                              myText: appLocal!
                                  .editphonenumber, //"Edit phone number",
                              isbold: true),
                          IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: const Icon(Icons.close))
                        ],
                      ),
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    profileCustomTextField(
                        fieldName: appLocal.phonenumber, // "Phone number",
                        mYhintText: appLocal.phonenumber, //"phone",
                        fieldValidator: (value) {
                          if (value == null || value.isEmpty) {
                            return appLocal.required; //'Required';
                          }
                          return null;
                        },
                        myControler: phoneNumberController,
                        keyBordType: TextInputType.number),
                    const Spacer(),
                    SizedBox(
                      height: h * 0.065,
                      width: w,
                      child: appButton(
                          buttonText: appLocal.save, //"Save",
                          ontapfunction: () async {
                            if (formKey.currentState!.validate()) {
                              await authsRead.changeUserPhone(
                                  phone: phoneNumberController.text);
                              await authsRead.getUserData();
                              // ignore: use_build_context_synchronously
                              Navigator.pop(context);
                            }
                          }),
                    )
                  ],
                ),
              )
            : loading(backDardColor: false),
      ),
    );
  }
}
