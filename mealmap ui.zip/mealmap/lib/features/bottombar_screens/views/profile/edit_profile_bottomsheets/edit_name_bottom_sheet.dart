import 'package:mealmap/utilz/constants/exports.dart';

class EditNameBottomSheet extends StatefulWidget {
  final String firstName;
  final String lastName;
  const EditNameBottomSheet(
      {super.key, required this.firstName, required this.lastName});

  @override
  // ignore: library_private_types_in_public_api
  _EditNameBottomSheetState createState() => _EditNameBottomSheetState();
}

class _EditNameBottomSheetState extends State<EditNameBottomSheet> {
  TextEditingController _firstNameController = TextEditingController();
  TextEditingController _lastNameController = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _firstNameController = TextEditingController(text: widget.firstName);
    _lastNameController = TextEditingController(text: widget.lastName);
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final authsRead = context.read<AuthssController>();
    final authsWatch = context.watch<AuthssController>();
    final appLocal = AppLocalizations.of(context);
    return SingleChildScrollView(
        child: Container(
      padding: const EdgeInsets.all(16.0),
      decoration: const BoxDecoration(
          color: AppColors.whiteColor,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(15), topRight: Radius.circular(15))),
      margin: EdgeInsets.only(
        left: w * 0.04,
        right: w * 0.04,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      height: h * 0.45,
      child: authsWatch.isloading == false
          ? Form(
              key: formKey,
              child: Column(
                children: [
                  SizedBox(
                    height: h * 0.06,
                    width: w,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: w * 0.1,
                        ),
                        appText(
                            myText: appLocal!.editname, // "Edit Name",
                            isbold: true),
                        IconButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            icon: const Icon(Icons.close))
                      ],
                    ),
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  profileCustomTextField(
                    fieldName: appLocal.firstname, //"First name",
                    myControler: _firstNameController,
                    readOnly: false,
                    fieldValidator: (value) {
                      if (value == null || value.isEmpty) {
                        return appLocal.required; //'Required';
                      }
                      return null;
                    },
                    mYhintText: appLocal.firstname, // "First name",
                    keyBordType: TextInputType.name,
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  profileCustomTextField(
                    fieldName: appLocal.lastname, // "Last name",
                    myControler: _lastNameController,
                    fieldValidator: (value) {
                      if (value == null || value.isEmpty) {
                        return appLocal.required; // 'Required';
                      }
                      return null;
                    },
                    readOnly: false,
                    mYhintText: appLocal.lastname, //"Last name",
                    keyBordType: TextInputType.name,
                  ),
                  const Spacer(),
                  SizedBox(
                    height: h * 0.065,
                    width: w,
                    child: appButton(
                        buttonText: appLocal.save, //"Save",
                        ontapfunction: () async {
                          if (formKey.currentState!.validate()) {
                            await authsRead.changeUserName(
                                firstName: _firstNameController.text,
                                secondName: _lastNameController.text);
                            await authsRead.getUserData();

                            Navigator.pop(context);
                          }
                        }),
                  )
                ],
              ),
            )
          : loading(backDardColor: false),
    ));
  }
}
