import 'package:mealmap/utilz/constants/exports.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  void initState() {
    context.read<ImagePickerController>().clearImage();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final authsWatch = context.watch<AuthssController>();
    final imagePickerWatch = context.watch<ImagePickerController>();
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: authsWatch.isloading == false
                ? Container(
                    height: h,
                    width: w,
                    padding: EdgeInsets.only(left: w * 0.05, right: w * 0.05),
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          SizedBox(
                            height: h * 0.08,
                            width: w,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                arrowBack(),
                                appText(
                                    myText: appLocal!.profile, // "Profile",
                                    isbold: true,
                                    myfontSize: 14),
                                SizedBox(
                                  width: w * 0.08,
                                )
                              ],
                            ),
                          ),
                          SizedBox(
                            height: h * 0.03,
                          ),
                          GestureDetector(
                            onTap: () {
                              _showBottomSheet(
                                  context, const EditPictureBottomSheet());
                            },
                            child: Stack(
                              children: [
                                Container(
                                  height: h * 0.12,
                                  width: w * 0.25,
                                  clipBehavior: Clip.antiAlias,
                                  decoration: BoxDecoration(
                                      color: AppColors.secondaryColor
                                          .withOpacity(0.5),
                                      shape: BoxShape.circle),
                                  child: imagePickerWatch.profileImage == null
                                      ? authsWatch.userData!['profileImage'] !=
                                              ''
                                          ? Image.network(
                                              authsWatch
                                                  .userData!['profileImage'],
                                              fit: BoxFit.cover,
                                            )
                                          : Image.asset(
                                              IconsApp.personIcon,
                                              // color: AppColors.blueColor,
                                            )
                                      : Image.file(
                                          imagePickerWatch.profileImage!,
                                          fit: BoxFit.cover,
                                        ),
                                ),
                                Positioned(
                                  bottom: 5,
                                  right: 4,
                                  child: Container(
                                    height: 15,
                                    width: 15,
                                    decoration: BoxDecoration(
                                        color: AppColors.whiteColor,
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.grey.withOpacity(0.3),
                                            spreadRadius: 3,
                                            blurRadius: 5,
                                            offset: const Offset(0,
                                                3), // changes position of shadow
                                          ),
                                        ],
                                        shape: BoxShape.circle),
                                    child: const Icon(
                                      color: AppColors.primaryColor,
                                      Icons.edit,
                                      size: 8,
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                          //--------------------------------------------------------//
                          SizedBox(
                            height: h * 0.01,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              appText(
                                  myText:
                                      "${authsWatch.userData!['firstName']} ${authsWatch.userData!['lastName']}",
                                  isbold: true,
                                  myfontSize: 15),
                              SizedBox(
                                width: w * 0.02,
                              ),
                              editBoxWidget(onTap: () {
                                _showBottomSheet(
                                    context,
                                    EditNameBottomSheet(
                                      firstName:
                                          authsWatch.userData!['firstName'],
                                      lastName:
                                          authsWatch.userData!['lastName'],
                                    ));
                              })
                            ],
                          ),
                          appText(
                            myText: authsWatch.userData!['email'],
                            isbold: true,
                          ),
                          SizedBox(
                            height: h * 0.04,
                          ),
                          newProfileWidgetForEditAndShow(
                              iconPath: IconsApp.lockIcon,
                              filedName: appLocal.password,
                              filedAns: "*****************",
                              onEditTap: () {
                                _showBottomSheet(
                                    context, const EditPasswordBottomSheet());
                              }),
                          SizedBox(
                            height: h * 0.01,
                          ),
                          newProfileWidgetForEditAndShow(
                              iconPath: IconsApp.phoneIcon,
                              filedName: appLocal.phonenumber, //"Phone number",
                              filedAns: authsWatch.userData!['phone'],
                              onEditTap: () {
                                _showBottomSheet(
                                    context,
                                    EditPhoneBottomsheet(
                                      phone: authsWatch.userData!['phone'],
                                    ));
                              }),
                          SizedBox(
                            height: h * 0.01,
                          ),
                          newProfileWidgetForEditAndShow(
                              iconPath: IconsApp.locationIcon,
                              filedName: appLocal.address, // //"Address",
                              filedAns:
                                  "19, rue Français Miran 75004 Paris, France",
                              onEditTap: () {
                                _showBottomSheet(
                                    context, const EditAddressBottomsheet());
                              }),

                          SizedBox(
                            height: h * 0.2,
                          ),
                          imagePickerWatch.profileImage != null
                              ? SizedBox(
                                  height: h * 0.065,
                                  width: w * 0.8,
                                  child: appButton(
                                      buttonText: appLocal
                                          .changeimage, //"Change Image",
                                      ontapfunction: () async {
                                        await context
                                            .read<AuthssController>()
                                            .changeProfilePicture(
                                                imagePath: imagePickerWatch
                                                    .profileImage);
                                        await context
                                            .read<AuthssController>()
                                            .getUserData();
                                        context
                                            .read<ImagePickerController>()
                                            .clearImage();
                                      }),
                                )
                              : const SizedBox(),
                          SizedBox(
                            height: h * 0.02,
                          ),
                        ],
                      ),
                    ),
                  )
                : loading()));
  }

  void _showBottomSheet(BuildContext context, Widget className) {
    showModalBottomSheet(
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      context: context,
      builder: (BuildContext context) {
        return className;
      },
    );
  }
} /////////////////////////////////////////\
//---------------------------------------------------------------------------------//

