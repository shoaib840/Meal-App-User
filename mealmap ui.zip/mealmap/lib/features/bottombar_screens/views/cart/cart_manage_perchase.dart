import 'package:mealmap/utilz/constants/exports.dart';

class CartManagePerchases extends StatefulWidget {
  const CartManagePerchases({super.key});

  @override
  State<CartManagePerchases> createState() => _CartManagePerchasesState();
}

class _CartManagePerchasesState extends State<CartManagePerchases> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Column(
      children: [
        Row(
          children: [
            appText(
                myText: appLocal!.managepurchase, //"Manage purchase",
                isbold: true),
          ],
        ),
        SizedBox(
          height: h * 0.02,
        ),
        Expanded(
            child: SingleChildScrollView(
          child: Column(
            children: [
              for (int i = 0; i < 2; i++) ...{
                cartListItem(
                    foodImagePath: ImagesApp.newFoodImage,
                    restuarantName: "Don Giovanni",
                    foodName: "Crocché",
                    foodPrice: "\$40",
                    onDeletePress: () {},
                    onAddPress: () {},
                    onMinusPress: () {},
                    pieces: "2 ${appLocal.piece}")
              }
            ],
          ),
        )),
        SizedBox(
          height: h * 0.01,
        ),
        SizedBox(
          height: h * 0.065,
          width: w * 0.8,
          child: appButton(
              buttonText: appLocal.checkout, //"Checkout",
              ontapfunction: () {
                Navigator.push(
                    context, createRoute(newPage: const OrderConfirmScreen()));
              }),
        )
      ],
    );
  }
}
