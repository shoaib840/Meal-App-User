import 'package:mealmap/utilz/constants/exports.dart';

class CartBillScreen extends StatefulWidget {
  const CartBillScreen({super.key});

  @override
  State<CartBillScreen> createState() => _CartBillScreenState();
}

class _CartBillScreenState extends State<CartBillScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
      backgroundColor: AppColors.whiteColor,
      body: Container(
        height: h,
        width: w,
        padding: EdgeInsets.symmetric(horizontal: w * 0.02),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: h * 0.02,
              ),
              Row(
                children: [
                  arrowBack(),
                  SizedBox(
                    width: w * 0.02,
                  ),
                  appText(
                      myText: appLocal!.bill, //"Bill",
                      isbold: true),
                ],
              ),
              SizedBox(
                height: h * 0.02,
              ),
              SizedBox(
                height: h * 0.05,
                width: w * 0.1,
                child: Image.asset(IconsApp.appIcon),
              ),
              SizedBox(
                height: h * 0.01,
              ),
              appText(myText: "MealApp", isbold: true, myfontSize: 30),
              SizedBox(
                height: h * 0.04,
              ),
              appText(
                  myText: appLocal.yourbillis, //"Your bill is",
                  isbold: true,
                  myfontSize: 18),
              SizedBox(
                height: h * 0.04,
              ),
              Container(
                height: h * 0.12,
                width: w * 0.24,
                decoration: const BoxDecoration(
                  color: AppColors.secondaryColor,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: appText(myText: "\$120", isbold: true, myfontSize: 16),
                ),
              ),
              SizedBox(
                height: h * 0.04,
              ),
              appText(
                  textAlign: TextAlign.center,
                  myText: "${appLocal.postareviewandget} 1% ${appLocal.off}",
                  isbold: true),
              SizedBox(
                height: h * 0.02,
              ),
              Container(
                height: 50,
                width: 50,
                // padding: const EdgeInsets.all(15),
                decoration: const BoxDecoration(
                    color: AppColors.primaryColor, shape: BoxShape.circle),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                      onTap: () {
                        Navigator.push(context,
                            createRoute(newPage: const ReviewScreen()));
                      },
                      splashColor: AppColors.whiteColor,
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Image.asset(IconsApp.starmessageIcon),
                      )),
                ),
              ),
              SizedBox(
                height: h * 0.2,
              ),
              SizedBox(
                height: h * 0.065,
                width: w * 0.8,
                child: appButton(
                    buttonText: appLocal.pay, //"Pay",
                    ontapfunction: () {
                      showModalBottomSheet(
                        backgroundColor: Colors.transparent,
                        isScrollControlled: true,
                        context: context,
                        builder: (BuildContext context) {
                          return const PayBillBottomBar(
                            isReservationBill: false,
                          );
                        },
                      );
                    }),
              ),
              SizedBox(
                height: h * 0.02,
              ),
            ],
          ),
        ),
      ),
    ));
  }
}
