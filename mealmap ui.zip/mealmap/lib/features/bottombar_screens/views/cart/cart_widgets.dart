import 'package:mealmap/utilz/constants/exports.dart';

Widget cartListItem(
    {required String foodImagePath,
    required String restuarantName,
    required String foodName,
    required String foodPrice,
    required onDeletePress,
    required onAddPress,
    required onMinusPress,
    required String pieces}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Container(
      height: h * 0.12,
      width: w,
      margin: EdgeInsets.only(
        left: w * 0.01,
        right: w * 0.01,
        bottom: h * 0.01,
      ),
      padding: EdgeInsets.symmetric(horizontal: h * 0.01, vertical: w * 0.02),
      decoration: BoxDecoration(boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.2),
          spreadRadius: 2,
          blurRadius: 4,
          offset: const Offset(0, 3), // changes position of shadow
        ),
      ], color: Colors.white, borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          Container(
            height: h * 0.1,
            width: w * 0.2,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)),
            child: Image.asset(
              foodImagePath,
              fit: BoxFit.fill,
            ),
          ),
          SizedBox(
            width: w * 0.01,
          ),
          Expanded(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  appText(myText: "${appLocal!.from}  ", myfontSize: 10),
                  appText(myText: restuarantName, isbold: true, myfontSize: 10)
                ],
              ),
              appText(myText: foodName, isbold: true),
              Container(
                decoration: BoxDecoration(
                    color: AppColors.secondaryColor,
                    borderRadius: BorderRadius.circular(30)),
                padding: EdgeInsets.symmetric(
                    horizontal: w * 0.02, vertical: h * 0.005),
                child: appText(myText: foodPrice, myfontSize: 10),
              )
            ],
          )),
          SizedBox(
            width: w * 0.01,
          ),
          SizedBox(
            height: h * 0.1,
            width: w * 0.3,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  height: h * 0.035,
                  width: w * 0.08,
                  clipBehavior: Clip.antiAlias,
                  decoration: const BoxDecoration(
                      color: AppColors.redColor, shape: BoxShape.circle),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: onDeletePress,
                      splashColor: AppColors.whiteColor,
                      child: const Center(
                          child: Icon(
                        Icons.delete_outline_outlined,
                        color: AppColors.whiteColor,
                        size: 14,
                      )),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: h * 0.03,
                      width: w * 0.06,
                      clipBehavior: Clip.antiAlias,
                      decoration: const BoxDecoration(
                          color: AppColors.secondaryColor,
                          shape: BoxShape.circle),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                            onTap: onMinusPress,
                            splashColor: AppColors.whiteColor,
                            child: Center(
                                child: appText(myText: "-", isbold: true))),
                      ),
                    ),
                    appText(myText: pieces, isbold: true, myfontSize: 10),
                    Container(
                      height: h * 0.03,
                      width: w * 0.06,
                      clipBehavior: Clip.antiAlias,
                      decoration: const BoxDecoration(
                          color: AppColors.secondaryColor,
                          shape: BoxShape.circle),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                            onTap: onAddPress,
                            splashColor: AppColors.whiteColor,
                            child: Center(
                                child: appText(myText: "+", isbold: true))),
                      ),
                    )
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  });
}

//----------------------------

Widget choiceBottonWidget(
    {required String topic,
    required backgroundColor,
    required clickUnclickColor,
    var icon,
    iconOnPress,
    String charges = '',
    required onTap,
    String topicDetail = ''}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: h * 0.1,
        width: w,
        padding: EdgeInsets.symmetric(horizontal: w * 0.02),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(10),
        ),
        clipBehavior: Clip.antiAlias,
        child: Row(
          children: [
            SizedBox(
              height: h * 0.1,
              width: w * 0.8,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: h * 0.04,
                    child: Row(
                      children: [
                        appText(myText: topic, isbold: true, myfontSize: 12),
                        icon != null
                            ? IconButton(onPressed: iconOnPress, icon: icon)
                            : const SizedBox()
                      ],
                    ),
                  ),
                  topicDetail.isNotEmpty
                      ? Container(
                          width: w,
                          alignment: Alignment.centerLeft,
                          child: Row(
                            children: [
                              appText(myText: topicDetail, myfontSize: 10),
                              const SizedBox(
                                width: 2,
                              ),
                              charges != ''
                                  ? Container(
                                      decoration: BoxDecoration(
                                          color: AppColors.secondaryColor,
                                          borderRadius:
                                              BorderRadius.circular(30)),
                                      padding: EdgeInsets.symmetric(
                                          horizontal: w * 0.02,
                                          vertical: h * 0.005),
                                      child: appText(
                                          myText: charges,
                                          myfontSize: 10,
                                          isbold: true),
                                    )
                                  : const SizedBox()
                            ],
                          ),
                        )
                      : const SizedBox()
                ],
              ),
            ),
            Expanded(
                child: Center(
              child: Container(
                height: 18,
                width: 18,
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                    border: Border.all(color: AppColors.blackColor),
                    shape: BoxShape.circle),
                child: Container(
                  decoration: BoxDecoration(
                      color: clickUnclickColor, shape: BoxShape.circle),
                ),
              ),
            ))
          ],
        ),
      ),
    );
  });
}
