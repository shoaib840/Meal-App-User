import 'package:mealmap/utilz/constants/exports.dart';

class EmptyCardScreen extends StatefulWidget {
  const EmptyCardScreen({super.key});

  @override
  State<EmptyCardScreen> createState() => _EmptyCardScreenState();
}

class _EmptyCardScreenState extends State<EmptyCardScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(
          height: h * 0.2,
          width: w * 0.5,
          child: Image.asset(IconsApp.trolleyIcon),
        ),
        SizedBox(
          height: h * 0.02,
        ),
        appText(
            myText:
                appLocal!.additemstostartacart, //"Add items to start a cart",
            isbold: true,
            myfontSize: 16),
        SizedBox(
          height: h * 0.02,
        ),
        appText(
            textAlign: TextAlign.center,
            isbold: true,
            myColors: AppColors.greyColor,
            myText: appLocal
                .onceyouadditemsfromarestaurantyourcartwillappearhere //"Once you add items from a restaurant, your cart will appear here."
            )
      ],
    );
  }
}
