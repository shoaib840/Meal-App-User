import 'package:mealmap/utilz/constants/exports.dart';

class CartCompleteBillScreen extends StatefulWidget {
  const CartCompleteBillScreen({super.key});

  @override
  State<CartCompleteBillScreen> createState() => _CartCompleteBillScreenState();
}

class _CartCompleteBillScreenState extends State<CartCompleteBillScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.whiteColor,
            body: Container(
              height: h,
              width: w,
              padding: EdgeInsets.symmetric(horizontal: w * 0.02),
              child: Column(
                children: [
                  SizedBox(
                    height: h * 0.08,
                  ),
                  SizedBox(
                    height: h * 0.05,
                    width: w * 0.1,
                    child: Image.asset(IconsApp.appIcon),
                  ),
                  SizedBox(
                    height: h * 0.01,
                  ),
                  appText(myText: "MealApp", isbold: true, myfontSize: 30),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Container(
                    height: h * 0.3,
                    width: w * 0.8,
                    decoration: const BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage(IconsApp.celebrationIcon))),
                    child: Center(
                      child: Container(
                        height: h * 0.1,
                        width: w * 0.2,
                        decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppColors.greenColor),
                        child: const Icon(
                          Icons.check,
                          color: AppColors.whiteColor,
                          size: 50,
                        ),
                      ),
                    ),
                  ),

                  //---------------------------------------------------------------------//
                  SizedBox(
                    height: h * 0.03,
                  ),
                  appText(
                      myText: appLocal!
                          .billpaidsuccessfully, //"Bill paid successfully!",
                      isbold: true,
                      myfontSize: 16),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  appText(
                      textAlign: TextAlign.center,
                      myText: appLocal
                          .youwillreceiveyourorderwithinapproximately20minutes, //"You will receive your order within approximately 20 minutes!",
                      isbold: true),
                  const Spacer(),
                  SizedBox(
                    height: h * 0.065,
                    width: w * 0.8,
                    child: appButton(
                        buttonText: appLocal.backtohome, //"Back to home",
                        ontapfunction: () {
                          Navigator.pop(context);
                        }),
                  ),
                  SizedBox(
                    height: h * 0.04,
                  ),
                ],
              ),
            )));
  }
}
