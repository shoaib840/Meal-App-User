import 'package:mealmap/utilz/constants/exports.dart';

class OrderConfirmScreen extends StatefulWidget {
  const OrderConfirmScreen({super.key});

  @override
  State<OrderConfirmScreen> createState() => _OrderConfirmScreenState();
}

class _OrderConfirmScreenState extends State<OrderConfirmScreen> {
  bool savedLocation = true;
  bool isDelivery = true;
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              height: h,
              width: w,
              padding: EdgeInsets.symmetric(horizontal: w * 0.02),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: h * 0.01,
                    ),
                    Row(
                      children: [
                        arrowBack(),
                        SizedBox(
                          width: w * 0.02,
                        ),
                        appText(
                            myText: appLocal!.checkout, //"Checkout",
                            isbold: true),
                      ],
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    Row(
                      children: [
                        appText(
                            myText: appLocal
                                .pleasereviewyourorder, //"Please review your order",
                            myfontSize: 14,
                            isbold: true),
                      ],
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    //-----------------------------------------------------------------------//
                    SizedBox(
                      height: h * 0.28,
                      width: w,
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            for (int i = 0; i < 10; i++) ...{
                              orderConfirmItemWidget(
                                  foodImagePath: ImagesApp.newFoodImage,
                                  resturantName: "Don Giovanni",
                                  foodName: "Crocché",
                                  foodPrice: "\$30",
                                  howManyPieces: "2 ${appLocal.piece}")
                            }
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    Container(
                      width: w,
                      padding: EdgeInsets.symmetric(
                          horizontal: w * 0.02, vertical: h * 0.01),
                      decoration: BoxDecoration(
                          color: AppColors.lightyellowColor,
                          borderRadius: BorderRadius.circular(10)),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              appText(
                                  myText:
                                      appLocal.ordersummary, //"Order summary",
                                  isbold: true,
                                  myfontSize: 15),
                            ],
                          ),
                          SizedBox(
                            height: h * 0.01,
                          ),
                          for (int i = 0; i < 2; i++) ...{
                            orderSummaryRowWidget(
                                foodName: "Crocché",
                                foodXValue: "x2",
                                foodTotalPrice: "\$78")
                          },
                          const Divider(
                            color: AppColors.greyColor,
                          ),
                          SizedBox(
                            height: h * 0.01,
                          ),
                          orderSummaryRowWidget(
                              foodName: appLocal.total, //"Total",
                              foodXValue: "",
                              foodTotalPrice: "\$376")
                        ],
                      ),
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    appText(
                        textAlign: TextAlign.center,
                        myText: appLocal
                            .confirmyouraddress, //"Confirm your address",
                        isbold: true,
                        myfontSize: 15),
                    SizedBox(
                      height: h * 0.01,
                    ),

                    choiceBottonWidget(
                        onTap: () {
                          setState(() {
                            savedLocation = true;
                          });
                        },
                        iconOnPress: () {},
                        icon: const Icon(
                          size: 15,
                          Icons.edit,
                          color: AppColors.greyColor,
                        ),
                        topic: appLocal.savedaddress, //"Saved address",
                        backgroundColor: savedLocation
                            ? AppColors.secondaryColor
                            : Colors.transparent,
                        clickUnclickColor:
                            savedLocation ? Colors.black : Colors.transparent,
                        topicDetail:
                            "19, rue Français Miran 75004 Paris, France"),
                    choiceBottonWidget(
                      onTap: () {
                        setState(() {
                          savedLocation = false;
                        });
                      },
                      topic: appLocal.currentlocation, //"Current location",
                      backgroundColor: savedLocation
                          ? Colors.transparent
                          : AppColors.secondaryColor,
                      clickUnclickColor:
                          savedLocation ? Colors.transparent : Colors.black,
                    ),

                    //---------------------------------------------------------------//
                    SizedBox(
                      height: h * 0.02,
                    ),
                    appText(
                      textAlign: TextAlign.center,
                      myText: appLocal
                          .howwouldyouliketoreceiveyourorder, //"How would you like to receive your order",
                      isbold: true,
                    ),
                    SizedBox(
                      height: h * 0.01,
                    ),
                    choiceBottonWidget(
                      onTap: () {
                        setState(() {
                          isDelivery = true;
                        });
                      },
                      topic: appLocal.delivery, //"Delivery",
                      charges: "\$3",
                      topicDetail:
                          appLocal.delieverycharges, //"Delievery charges",
                      backgroundColor: isDelivery
                          ? AppColors.greyColor.withOpacity(0.3)
                          : Colors.transparent,
                      clickUnclickColor:
                          isDelivery ? Colors.black : Colors.transparent,
                    ),
                    SizedBox(
                      height: h * 0.01,
                    ),
                    choiceBottonWidget(
                      onTap: () {
                        setState(() {
                          isDelivery = false;
                        });
                      },
                      topic: appLocal.takeaway, //"Takeaway",
                      backgroundColor: isDelivery == false
                          ? AppColors.greyColor.withOpacity(0.3)
                          : Colors.transparent,
                      clickUnclickColor: isDelivery == false
                          ? Colors.black
                          : Colors.transparent,
                    ),
                    SizedBox(
                      height: h * 0.03,
                    ),
                    SizedBox(
                      width: w * 0.8,
                      height: h * 0.065,
                      child: appButton(
                          buttonText:
                              appLocal.confirmyourorder, //"Confirm your order",
                          ontapfunction: () {
                            Navigator.push(context,
                                createRoute(newPage: const CartBillScreen()));
                          }),
                    ),
                    SizedBox(
                      height: h * 0.03,
                    ),
                  ],
                ),
              ),
            )));
  }
}

//---------------------------------------------------------------//

Widget orderConfirmItemWidget(
    {required String foodImagePath,
    required String resturantName,
    required String foodName,
    required String foodPrice,
    required String howManyPieces}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Container(
      height: h * 0.12,
      width: w,
      margin: EdgeInsets.only(
        left: w * 0.01,
        right: w * 0.01,
        bottom: h * 0.01,
      ),
      padding: EdgeInsets.symmetric(horizontal: h * 0.01, vertical: w * 0.02),
      decoration: BoxDecoration(boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.2),
          spreadRadius: 2,
          blurRadius: 4,
          offset: const Offset(0, 3), // changes position of shadow
        ),
      ], color: Colors.white, borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          Container(
            height: h * 0.1,
            width: w * 0.2,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)),
            child: Image.asset(
              foodImagePath,
              fit: BoxFit.fill,
            ),
          ),
          SizedBox(
            width: w * 0.01,
          ),
          Expanded(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  appText(myText: "${appLocal!.from} ", myfontSize: 10),
                  appText(myText: resturantName, isbold: true, myfontSize: 10)
                ],
              ),
              appText(myText: foodName, isbold: true),
              Container(
                decoration: BoxDecoration(
                    color: AppColors.secondaryColor,
                    borderRadius: BorderRadius.circular(30)),
                padding: EdgeInsets.symmetric(
                    horizontal: w * 0.02, vertical: h * 0.005),
                child: appText(myText: foodPrice, myfontSize: 10),
              )
            ],
          )),
          SizedBox(
            width: w * 0.01,
          ),
          SizedBox(
            height: h * 0.1,
            width: w * 0.18,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: h * 0.035,
                  width: w * 0.12,
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                      color: AppColors.blackColor,
                      borderRadius: BorderRadius.circular(30)),
                  child: Image.asset(
                    IconsApp.cartPlusIcon,
                    color: AppColors.whiteColor,
                  ),
                ),
                appText(myText: howManyPieces, isbold: true)
              ],
            ),
          )
        ],
      ),
    );
  });
}

//-----------------------------------------

Widget orderSummaryRowWidget(
    {required String foodName,
    required String foodXValue,
    required foodTotalPrice}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Container(
      padding: EdgeInsets.only(bottom: h * 0.01),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          appText(
            myText: "$foodName $foodXValue",
            isbold: true,
          ),
          Container(
            decoration: BoxDecoration(
                color: AppColors.secondaryColor,
                borderRadius: BorderRadius.circular(30)),
            padding:
                EdgeInsets.symmetric(horizontal: w * 0.02, vertical: h * 0.005),
            child:
                appText(myText: foodTotalPrice, myfontSize: 10, isbold: true),
          )
        ],
      ),
    );
  });
}
//------------------------------------Choice button Widget
