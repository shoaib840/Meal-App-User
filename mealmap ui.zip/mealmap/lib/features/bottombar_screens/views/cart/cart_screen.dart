import 'package:mealmap/utilz/constants/exports.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Container(
      height: h,
      width: w,
      padding: EdgeInsets.symmetric(horizontal: w * 0.02),
      child: Column(
        children: [
          SizedBox(
            height: h * 0.01,
          ),
          Row(
            children: [
              appText(
                  myText: appLocal!.cart, //"Cart",
                  isbold: true,
                  myfontSize: 14),
            ],
          ),
          SizedBox(
            height: h * 0.03,
          ),
          const Expanded(child: CartManagePerchases() //EmptyCardScreen()
              ),
          SizedBox(
            height: h * 0.1,
          ),
        ],
      ),
    );
  }
}
