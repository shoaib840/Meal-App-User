import 'package:mealmap/utilz/constants/exports.dart';

class TipRiderBottomSheet extends StatefulWidget {
  const TipRiderBottomSheet({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _TipRiderBottomSheetState createState() => _TipRiderBottomSheetState();
}

class _TipRiderBottomSheetState extends State<TipRiderBottomSheet> {
  int _selectedChipIndex = -1;
  List<String> giftPrices = ["2", "5", "10"];
  int tipAmount = 0;
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: const BoxDecoration(
            color: AppColors.whiteColor,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15), topRight: Radius.circular(15))),
        margin: EdgeInsets.only(
          left: w * 0.04,
          right: w * 0.04,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        height: h * 0.5,
        child: Column(
          children: [
            SizedBox(
              height: h * 0.06,
              width: w,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: w * 0.1,
                  ),
                  appText(
                      myText:
                          appLocal!.enteramounttotip, //"Enter amount to tip",
                      isbold: true),
                  IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.close))
                ],
              ),
            ),
            SizedBox(
              height: h * 0.01,
            ),
            Container(
              height: h * 0.1,
              width: w * 0.22,
              clipBehavior: Clip.antiAlias,
              decoration: const BoxDecoration(
                  color: AppColors.secondaryColor, shape: BoxShape.circle),
              child: Center(
                  child: appText(
                      myText: "\$$tipAmount", isbold: true, myfontSize: 22)),
            ),
            SizedBox(
              height: h * 0.02,
            ),
            appText(
                myText: appLocal.selectamount, //"Select amount",
                isbold: true),
            SizedBox(
              height: h * 0.01,
            ),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: w * 0.03, // Space between chips
              children: List.generate(giftPrices.length, (index) {
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _selectedChipIndex = index;
                      tipAmount = int.parse(giftPrices[index]);
                    });
                  },
                  child: Chip(
                    label:
                        appText(myText: "\$${giftPrices[index]}", isbold: true),
                    backgroundColor: _selectedChipIndex == index
                        ? AppColors.greenColor
                        : AppColors.secondaryColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(
                        color: _selectedChipIndex == index
                            ? AppColors.greenColor
                            : AppColors.secondaryColor,
                      ),
                    ),
                  ),
                );
              }),
            ),
            //---------------------------------------------------//
            const Spacer(),
            SizedBox(
              height: h * 0.065,
              width: w,
              child: appButton(
                  buttonText: appLocal.pay, //"Pay",
                  ontapfunction: () {}),
            )
          ],
        ),
      ),
    );
  }
}
