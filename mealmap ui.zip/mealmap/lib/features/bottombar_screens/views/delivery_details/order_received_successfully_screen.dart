import 'package:mealmap/utilz/constants/exports.dart';

class OrderReceviedSuccfullyScreen extends StatefulWidget {
  const OrderReceviedSuccfullyScreen({super.key});

  @override
  State<OrderReceviedSuccfullyScreen> createState() =>
      _OrderReceviedSuccfullyScreenState();
}

class _OrderReceviedSuccfullyScreenState
    extends State<OrderReceviedSuccfullyScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
      backgroundColor: AppColors.backgroundColor,
      body: Container(
        height: h,
        width: w,
        padding: EdgeInsets.symmetric(horizontal: w * 0.02),
        child: Column(
          children: [
            SizedBox(
              height: h * 0.03,
            ),
            SizedBox(
              height: h * 0.05,
              width: w * 0.1,
              child: Image.asset(IconsApp.appIcon),
            ),
            SizedBox(
              height: h * 0.01,
            ),
            appText(myText: "MealApp", isbold: true, myfontSize: 30),
            SizedBox(
              height: h * 0.02,
            ),
            Container(
              height: h * 0.3,
              width: w * 0.8,
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(IconsApp.celebrationIcon))),
              child: Center(
                child: Container(
                  height: h * 0.1,
                  width: w * 0.2,
                  decoration: const BoxDecoration(
                      shape: BoxShape.circle, color: AppColors.greenColor),
                  child: const Icon(
                    Icons.check,
                    color: AppColors.whiteColor,
                    size: 50,
                  ),
                ),
              ),
            ),

            //---------------------------------------------------------------------//
            SizedBox(
              height: h * 0.02,
            ),
            appText(
                myText: appLocal!
                    .orderreceivedsuccessfully, //"Order received successfully!",
                isbold: true,
                myfontSize: 14),
            SizedBox(
              height: h * 0.02,
            ),
            appText(
              myText: appLocal.tipyourrider, //"Tip your rider",
              isbold: true,
            ),
            SizedBox(
              height: h * 0.01,
            ),
            Container(
              height: 40,
              width: 40,
              clipBehavior: Clip.antiAlias,
              decoration: const BoxDecoration(
                  color: AppColors.primaryColor, shape: BoxShape.circle),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  splashColor: AppColors.whiteColor,
                  onTap: () {
                    showModalBottomSheet(
                      backgroundColor: Colors.transparent,
                      isScrollControlled: true,
                      context: context,
                      builder: (BuildContext context) {
                        return const TipRiderBottomSheet();
                      },
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Image.asset(IconsApp.tipIcon),
                  ),
                ),
              ),
            ),

            SizedBox(
              height: h * 0.15,
            ),
            SizedBox(
              width: w * 0.8,
              height: h * 0.06,
              child: appButton(
                  buttonText: appLocal.backtohome, //"Back to home",
                  ontapfunction: () {
                    Navigator.pop(context);
                  }),
            )
          ],
        ),
      ),
    ));
  }
}
