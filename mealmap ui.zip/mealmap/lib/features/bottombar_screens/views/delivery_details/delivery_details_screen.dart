import 'package:mealmap/utilz/constants/exports.dart';

class DeliveryDetailScreen extends StatefulWidget {
  const DeliveryDetailScreen({super.key});

  @override
  State<DeliveryDetailScreen> createState() => _DeliveryDetailScreenState();
}

class _DeliveryDetailScreenState extends State<DeliveryDetailScreen> {
  bool _isExpanded = false;
  GoogleMapController? controller;
  static const LatLng _center =
      LatLng(37.7749, -122.4194); // San Francisco coordinates

  // final Set<Marker> markers = {
  //   const Marker(
  //     markerId: MarkerId('defaultMarker'),
  //     position: _center,
  //     infoWindow: InfoWindow(title: 'San Francisco'),
  //     icon: BitmapDescriptor.defaultMarker,
  //   ),
  // };
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Stack(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: w * 0.02),
                  height: h,
                  width: w,
                  child: Column(
                    children: [
                      SizedBox(
                        height: h * 0.02,
                      ),
                      Row(
                        children: [
                          arrowBack(),
                          SizedBox(
                            width: w * 0.02,
                          ),
                          appText(
                              myText: appLocal!
                                  .deliverydetails, //"Delivery details",
                              isbold: true),
                        ],
                      ),
                      SizedBox(
                        height: h * 0.02,
                      ),
                      //----------------------------------------------------------------------------//
                      Container(
                        height: h * 0.23,
                        width: w,
                        padding: EdgeInsets.symmetric(vertical: h * 0.01),
                        decoration: BoxDecoration(
                            color: AppColors.whiteColor,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 3,
                                blurRadius: 4,
                                offset: const Offset(
                                    0, 3), // changes position of shadow
                              ),
                            ],
                            borderRadius: BorderRadius.circular(10)),
                        child: Column(
                          children: [
                            appText(
                                textAlign: TextAlign.center,
                                myText:
                                    "${appLocal.yourorderisestimatedtoarriveat} 11:15 pm",
                                isbold: true),
                            SizedBox(
                              height: h * 0.02,
                            ),
                            Expanded(
                                child: Row(
                              children: [
                                SizedBox(
                                  width: w * 0.3,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      appText(
                                        textAlign: TextAlign.center,
                                        myText: appLocal
                                            .arrivaltime, //"Arrival time",
                                        isbold: true,
                                      ),
                                      SizedBox(
                                        height: h * 0.02,
                                      ),
                                      Container(
                                        height: h * 0.035,
                                        width: w * 0.18,
                                        decoration: BoxDecoration(
                                            color: AppColors.secondaryColor,
                                            borderRadius:
                                                BorderRadius.circular(20)),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                              height: h * 0.05,
                                              width: w * 0.04,
                                              child: Image.asset(
                                                  IconsApp.clockIcon),
                                            ),
                                            SizedBox(
                                              width: w * 0.01,
                                            ),
                                            appText(
                                                myText: "20m",
                                                isbold: true,
                                                myfontSize: 10)
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Expanded(
                                    child: Container(
                                  height: h * 0.12,
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                  ),
                                  clipBehavior: Clip.antiAlias,
                                  child: CircularPercentIndicator(
                                      radius: h * 0.06,
                                      lineWidth: 3.0,
                                      percent: .59,
                                      center: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          appText(
                                              myText: "9:44",
                                              isbold: true,
                                              myfontSize: 16),
                                          appText(
                                              textAlign: TextAlign.center,
                                              myText:
                                                  "${appLocal.remaining}\n${appLocal.time}",
                                              myfontSize: 7,
                                              isbold: true)
                                        ],
                                      ),
                                      progressColor: AppColors.greenColor,
                                      backgroundColor:
                                          AppColors.greyColor.withOpacity(0.2),
                                      fillColor: AppColors.secondaryColor
                                          .withOpacity(0.2)),
                                )),
                                SizedBox(
                                  width: w * 0.3,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      appText(
                                        myText: appLocal.distance, //"Distance",
                                        isbold: true,
                                      ),
                                      SizedBox(
                                        height: h * 0.02,
                                      ),
                                      Container(
                                        height: h * 0.035,
                                        width: w * 0.18,
                                        decoration: BoxDecoration(
                                            color: AppColors.secondaryColor,
                                            borderRadius:
                                                BorderRadius.circular(20)),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                              height: h * 0.05,
                                              width: w * 0.04,
                                              child: Image.asset(
                                                  IconsApp.fromlocationIcon),
                                            ),
                                            SizedBox(
                                              width: w * 0.01,
                                            ),
                                            appText(
                                                myText: "5KM",
                                                isbold: true,
                                                myfontSize: 10)
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ))
                          ],
                        ),
                      ),
                      //--------------------------------------------------------------------------//

                      SizedBox(
                        height: h * 0.02,
                      ),
                      Expanded(
                        child: GoogleMap(
                          initialCameraPosition: const CameraPosition(
                            target: _center,
                            zoom: 13,
                          ),
                          onMapCreated: (GoogleMapController controller) {
                            controller = controller;
                          },
                        ),
                      ),
                      SizedBox(
                        height: h * 0.08,
                      )
                    ],
                  ),
                ),

                //------------------------------------------------------------------//

                Positioned(
                  bottom: 0,
                  child: GestureDetector(
                    onTap: () {
                      _isExpanded = !_isExpanded;
                      setState(() {});
                    },
                    child: AnimatedContainer(
                      duration: const Duration(seconds: 1),
                      height: _isExpanded ? h * 0.62 : h * 0.12,
                      width: w,
                      child: Stack(
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              AnimatedContainer(
                                duration: const Duration(seconds: 1),
                                height: _isExpanded ? h * 0.59 : h * 0.09,
                                width: w,
                                padding:
                                    EdgeInsets.symmetric(horizontal: w * 0.02),
                                decoration: const BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(30),
                                        topRight: Radius.circular(30))),
                                child: Column(
                                  children: [
                                    SizedBox(
                                      height: h * 0.04,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        appText(
                                            myText: "Gianluca Zambrotta ",
                                            isbold: true,
                                            myfontSize: 14),
                                        SizedBox(
                                          height: 20,
                                          width: 20,
                                          child:
                                              Image.asset(IconsApp.riderIcon),
                                        )
                                      ],
                                    ),

                                    //--------------------------------------------------------------//
                                    SizedBox(
                                      height: h * 0.02,
                                    ),
                                    Visibility(
                                        visible: _isExpanded,
                                        child: Column(
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                SizedBox(
                                                  width: w * 0.8,
                                                  child: customTextField(
                                                      mYhintText: appLocal
                                                          .sendamessage, //"Send a message",
                                                      keyBordType:
                                                          TextInputType.name),
                                                ),
                                                Container(
                                                  height: 40,
                                                  width: 40,
                                                  padding:
                                                      const EdgeInsets.all(8),
                                                  decoration:
                                                      const BoxDecoration(
                                                          shape:
                                                              BoxShape.circle,
                                                          color: AppColors
                                                              .primaryColor),
                                                  child: Image.asset(
                                                    IconsApp.callingIcon,
                                                    color: AppColors.blackColor,
                                                  ),
                                                )
                                              ],
                                            ),

                                            //-------------------------------------------------------//
                                            SizedBox(
                                              height: h * 0.01,
                                            ),
                                            Divider(
                                              color: AppColors.greyColor
                                                  .withOpacity(0.2),
                                              thickness: 2,
                                            ),
                                            SizedBox(
                                              height: h * 0.01,
                                            ),
                                            Row(
                                              children: [
                                                appText(
                                                    myText: appLocal
                                                        .deliverydetails, //"Delivery details",
                                                    isbold: true),
                                              ],
                                            ),
                                            SizedBox(
                                              height: h * 0.01,
                                            ),

                                            detailDelieryWidget(
                                                iconPath: IconsApp.locationIcon,
                                                headline: appLocal
                                                    .address, //"Address",
                                                description:
                                                    "19, rue Français Miran 75004 Paris, France"),
                                            SizedBox(
                                              height: h * 0.01,
                                            ),

                                            detailDelieryWidget(
                                                iconPath: IconsApp
                                                    .contectusMessageiconIcon,
                                                headline: appLocal
                                                    .message, //"Message",
                                                description: appLocal
                                                    .callmewhenyouarehere //"Call me when you are here"
                                                ),
                                            SizedBox(
                                              height: h * 0.01,
                                            ),
                                            detailDelieryWidget(
                                                iconPath: IconsApp.lockIcon,
                                                headline: appLocal
                                                    .pincode, //"Pin code",
                                                description: "4275"),
                                            SizedBox(
                                              height: h * 0.02,
                                            ),
                                            SizedBox(
                                              width: w * 0.8,
                                              height: h * 0.06,
                                              child: appButton(
                                                  buttonText: appLocal
                                                      .completeorder, //"Complete Order",
                                                  ontapfunction: () {
                                                    Navigator.push(
                                                        context,
                                                        createRoute(
                                                            newPage:
                                                                const OrderReceviedSuccfullyScreen()));
                                                  }),
                                            )
                                          ],
                                        ))
                                  ],
                                ),
                              ),
                            ],
                          ),
                          //--------------------------------------//\
                          Positioned(
                            top: 0,
                            left: w * 0.43,
                            child: Container(
                              height: h * 0.06,
                              width: w * 0.14,
                              clipBehavior: Clip.antiAlias,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                // border: Border.all(
                                //     color: AppColors.primaryColor, width: 2)
                              ),
                              child: Image.network(
                                  fit: BoxFit.cover,
                                  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTRtcqTpe_DDBI3U7ppRfaU17-SY_WpOmV4w&s"),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                )
              ],
            )));
  }
}

//--------------------------------------------------------------------//

Widget detailDelieryWidget(
    {required String iconPath,
    required String headline,
    required String description}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Container(
      height: h * 0.08,
      width: w,
      decoration: BoxDecoration(
          color: AppColors.secondaryColor,
          borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          SizedBox(
            height: h * 0.03,
            width: w * 0.1,
            child: Image.asset(
              iconPath,
              color: AppColors.primaryColor,
            ),
          ),
          SizedBox(
            width: w * 0.01,
          ),
          Expanded(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              appText(myText: headline, isbold: true),
              appText(myfontSize: 10, myText: description, isbold: true)
            ],
          ))
        ],
      ),
    );
  });
}
