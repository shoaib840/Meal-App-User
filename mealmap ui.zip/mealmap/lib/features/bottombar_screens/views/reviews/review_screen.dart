import 'package:mealmap/utilz/constants/exports.dart';

class ReviewScreen extends StatefulWidget {
  const ReviewScreen({super.key});

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  int goodFoodStar = 0;
  int goodServiceStar = 0;
  bool valueFormoney = true;
  bool recomendToFriend = true;
  bool familyfriendlyplace = true;
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              height: h,
              width: w,
              padding: EdgeInsets.symmetric(horizontal: w * 0.02),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: h * 0.02,
                    ),
                    Row(
                      children: [
                        arrowBack(),
                        SizedBox(
                          width: w * 0.02,
                        ),
                        appText(myText: "Add a review", isbold: true),
                      ],
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    Container(
                      height: h * 0.15,
                      width: w,
                      padding: EdgeInsets.symmetric(
                          horizontal: w * 0.02, vertical: h * 0.01),
                      decoration: BoxDecoration(
                          color: AppColors.whiteColor,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.2),
                              spreadRadius: 3,
                              blurRadius: 4,
                              offset: const Offset(
                                  0, 3), // changes position of shadow
                            ),
                          ],
                          borderRadius: BorderRadius.circular(10)),
                      child: Row(
                        children: [
                          Container(
                            height: h * 0.15,
                            width: w * 0.35,
                            clipBehavior: Clip.antiAlias,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10)),
                            child: Image.asset(
                              ImagesApp.newResturantImage,
                              fit: BoxFit.fill,
                            ),
                          ),
                          SizedBox(
                            width: w * 0.01,
                          ),
                          Expanded(
                              child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              appText(myText: "Italian", isbold: true),
                              appText(
                                  myText: "Don Giovanni",
                                  myfontSize: 14,
                                  isbold: true),
                              appText(
                                  myText: "75008, Paris",
                                  myfontSize: 8,
                                  isbold: true),
                              appText(
                                  myText: "3.5 km",
                                  myfontSize: 8,
                                  isbold: true),
                              Row(
                                children: [
                                  appText(
                                      myText: "Average price",
                                      myfontSize: 8,
                                      isbold: true),
                                  SizedBox(
                                    width: w * 0.01,
                                  ),
                                  Container(
                                    height: h * 0.025,
                                    width: w * 0.1,
                                    decoration: BoxDecoration(
                                        color: AppColors.secondaryColor,
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: Center(
                                      child: appText(
                                          myText: "\$39",
                                          isbold: true,
                                          myfontSize: 10),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          )),
                          SizedBox(
                            height: h * 0.15,
                            width: w * 0.1,
                            child: Column(
                              children: [
                                Container(
                                  height: h * 0.025,
                                  width: w * 0.1,
                                  decoration: BoxDecoration(
                                      color: AppColors.secondaryColor,
                                      borderRadius: BorderRadius.circular(10)),
                                  child: Center(
                                    child: appText(
                                        myText: "9.4",
                                        isbold: true,
                                        myfontSize: 10),
                                  ),
                                ),
                                SizedBox(
                                  height: h * 0.01,
                                ),
                                appText(
                                    myText: "(1826)",
                                    myfontSize: 8,
                                    myColors: AppColors.greyColor)
                              ],
                            ),
                          )
                        ],
                      ),
                    ),

                    //--------------------------------------------------------------------------------//

                    SizedBox(
                      height: h * 0.02,
                    ),
                    appText(
                        myText: "Upload pictures",
                        isbold: true,
                        myfontSize: 14),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    Container(
                      height: 50,
                      width: 50,
                      // padding: const EdgeInsets.all(15),
                      decoration: const BoxDecoration(
                          color: AppColors.primaryColor,
                          shape: BoxShape.circle),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                            onTap: () {
                              showModalBottomSheet(
                                backgroundColor: Colors.transparent,
                                isScrollControlled: true,
                                context: context,
                                builder: (BuildContext context) {
                                  return const EditPictureBottomSheet();
                                },
                              );
                            },
                            splashColor: AppColors.whiteColor,
                            child: Padding(
                              padding: const EdgeInsets.all(15.0),
                              child: Image.asset(
                                IconsApp.cameraIcon,
                                color: AppColors.blackColor,
                              ),
                            )),
                      ),
                    ),
                    //-----------------------------------------------------
                    SizedBox(
                      height: h * 0.04,
                    ),
                    Container(
                      width: w,
                      padding: EdgeInsets.symmetric(
                          horizontal: w * 0.02, vertical: h * 0.01),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: AppColors.secondaryColor),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          appText(
                              myText: "How good was the food?",
                              isbold: true,
                              myfontSize: 14),
                          Row(
                            children: List.generate(10, (index) {
                              return GestureDetector(
                                onTap: () {
                                  setState(() {
                                    goodFoodStar = index;
                                  });
                                },
                                child: Icon(
                                  Icons.star,
                                  color: index <= goodFoodStar
                                      ? Colors.amber
                                      : Colors.grey.withOpacity(0.5),
                                ),
                              );
                            }),
                          ),
                          SizedBox(
                            height: h * 0.02,
                          ),
                          appText(
                              myText: "How good was the service?",
                              isbold: true,
                              myfontSize: 14),
                          Row(
                            children: List.generate(10, (index) {
                              return GestureDetector(
                                onTap: () {
                                  setState(() {
                                    goodServiceStar = index;
                                  });
                                },
                                child: Icon(
                                  Icons.star,
                                  color: index <= goodServiceStar
                                      ? Colors.amber
                                      : Colors.grey.withOpacity(0.5),
                                ),
                              );
                            }),
                          ),
                          // SizedBox(
                          //   height: h * 0.02,
                          // ),
                          // appText(
                          //     myText: "How good was the food?",
                          //     isbold: true,
                          //     myfontSize: 14),
                          // Row(
                          //   children: List.generate(10, (index) {
                          //     return GestureDetector(
                          //       onTap: () {
                          //         setState(() {
                          //           goodFoodStar = index;
                          //         });
                          //       },
                          //       child: Icon(
                          //         Icons.star,
                          //         color: index <= goodFoodStar
                          //             ? Colors.amber
                          //             : Colors.grey.withOpacity(0.5),
                          //       ),
                          //     );
                          //   }),
                          // ),
                          // SizedBox(
                          //   height: h * 0.02,
                          // )
                        ],
                      ),
                    ),

                    //------------------------------------------------------//
                    SizedBox(
                      height: h * 0.02,
                    ),
                    yesNoQuestionWidget(
                        onNoTap: () {
                          setState(() {
                            valueFormoney = false;
                          });
                        },
                        question: "Was it value for your money?",
                        onYesTap: () {
                          setState(() {
                            valueFormoney = true;
                          });
                        },
                        yesClicked: valueFormoney),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    yesNoQuestionWidget(
                        onNoTap: () {
                          setState(() {
                            recomendToFriend = false;
                          });
                        },
                        question: "Would you recommend to your friends?",
                        onYesTap: () {
                          setState(() {
                            recomendToFriend = true;
                          });
                        },
                        yesClicked: recomendToFriend),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    yesNoQuestionWidget(
                        onNoTap: () {
                          setState(() {
                            familyfriendlyplace = false;
                          });
                        },
                        question: "Was it a family-friendly place?",
                        onYesTap: () {
                          setState(() {
                            familyfriendlyplace = true;
                          });
                        },
                        yesClicked: familyfriendlyplace),
                    SizedBox(
                      height: h * 0.02,
                    ),

                    customTextField(
                        mYhintText: "Comment", keyBordType: TextInputType.name),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    SizedBox(
                      height: h * 0.065,
                      width: w * 0.8,
                      child:
                          appButton(buttonText: "Submit", ontapfunction: () {}),
                    ),
                    SizedBox(
                      height: h * 0.04,
                    ),
                  ],
                ),
              ),
            )));
  }
}
