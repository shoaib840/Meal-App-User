import 'package:mealmap/utilz/constants/exports.dart';

class WishListScreen extends StatefulWidget {
  const WishListScreen({super.key});

  @override
  State<WishListScreen> createState() => _WishListScreenState();
}

class _WishListScreenState extends State<WishListScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Container(
      height: h,
      width: w,
      padding: EdgeInsets.symmetric(horizontal: w * 0.02),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: h * 0.01,
          ),
          appText(
              myText: appLocal!.wishlist, //"Wishlist",
              isbold: true,
              myfontSize: 14),
          SizedBox(
            height: h * 0.03,
          ),
          appText(
              myText: appLocal.managewishlist, //"Manage wishlist",
              isbold: true),
          SizedBox(
            height: h * 0.02,
          ),
          Expanded(
              child: SingleChildScrollView(
            child: Column(
              children: [
                for (int i = 0; i < 10; i++) ...{
                  wishListItem(
                      resturantImagePath: ImagesApp.resturantImage,
                      foodType: "Italian",
                      resturantName: "Don Giovanni",
                      location: "75008, Paris",
                      averagePrice: "\$30",
                      rating: "9.9",
                      percentDiscount: "30%",
                      onDeleteTap: () {})
                }
              ],
            ),
          )),
          SizedBox(
            height: h * 0.1,
          ),
        ],
      ),
    );
  }
}
