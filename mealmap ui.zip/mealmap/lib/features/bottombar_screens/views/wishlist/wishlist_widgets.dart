import 'package:mealmap/utilz/constants/exports.dart';

Widget wishListItem({
  required String resturantImagePath,
  required String foodType,
  required String resturantName,
  required String location,
  required String averagePrice,
  required String rating,
  required String percentDiscount,
  required onDeleteTap,
}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Container(
      height: h * 0.14,
      margin: EdgeInsets.only(
        left: w * 0.01,
        right: w * 0.01,
        bottom: h * 0.01,
      ),
      padding: EdgeInsets.symmetric(horizontal: h * 0.01, vertical: w * 0.02),
      width: w,
      decoration: BoxDecoration(boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.2),
          spreadRadius: 2,
          blurRadius: 4,
          offset: const Offset(0, 3), // changes position of shadow
        ),
      ], color: Colors.white, borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          Container(
            height: h * 0.13,
            width: w * 0.38,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)),
            child: Image.asset(
              resturantImagePath,
              fit: BoxFit.fill,
            ),
          ),
          SizedBox(
            width: w * 0.01,
          ),
          Expanded(
              child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              appText(myText: foodType),
              appText(myText: resturantName, myfontSize: 14, isbold: true),
              appText(myText: location, myfontSize: 10),
              Row(
                children: [
                  appText(
                      myText: appLocal!.averageprice, //"Average price",
                      myfontSize: 8,
                      isbold: true),
                  SizedBox(
                    width: w * 0.01,
                  ),
                  Container(
                    decoration: BoxDecoration(
                        color: AppColors.secondaryColor,
                        borderRadius: BorderRadius.circular(30)),
                    padding: EdgeInsets.symmetric(
                        horizontal: w * 0.02, vertical: h * 0.005),
                    child: appText(myText: averagePrice, myfontSize: 10),
                  )
                ],
              )
            ],
          )),
          SizedBox(
            width: w * 0.01,
          ),
          SizedBox(
            height: h * 0.13,
            width: w * 0.1,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: h * 0.025,
                  width: w * 0.1,
                  decoration: BoxDecoration(
                      color: AppColors.secondaryColor,
                      borderRadius: BorderRadius.circular(10)),
                  child: Center(
                    child:
                        appText(myText: rating, isbold: true, myfontSize: 10),
                  ),
                ),
                Container(
                  height: h * 0.035,
                  width: w * 0.08,
                  clipBehavior: Clip.antiAlias,
                  decoration: const BoxDecoration(
                      color: AppColors.redColor, shape: BoxShape.circle),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: onDeleteTap,
                      splashColor: AppColors.whiteColor,
                      child: const Center(
                          child: Icon(
                        Icons.delete_outline_outlined,
                        color: AppColors.whiteColor,
                        size: 14,
                      )),
                    ),
                  ),
                ),
                Container(
                  height: h * 0.025,
                  width: w * 0.1,
                  decoration: BoxDecoration(
                      color: AppColors.yellowColor,
                      borderRadius: BorderRadius.circular(10)),
                  child: Center(
                    child: appText(
                        myText: percentDiscount, isbold: true, myfontSize: 10),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  });
}
