// Import your custom drawer file
import 'package:drawerbehavior/drawerbehavior.dart';
import 'package:mealmap/utilz/constants/exports.dart';

class DrawerWithBottomBar extends StatefulWidget {
  const DrawerWithBottomBar({
    super.key,
  });

  @override
  // ignore: library_private_types_in_public_api
  _DrawerWithBottomBarState createState() => _DrawerWithBottomBarState();
}

class _DrawerWithBottomBarState extends State<DrawerWithBottomBar> {
  final DrawerScaffoldController controller = DrawerScaffoldController();

  @override
  Widget build(BuildContext context) {
    final authsWatch = context.watch<AuthssController>();
    return SafeArea(
      child: authsWatch.isloading
          ? Scaffold(backgroundColor: AppColors.whiteColor, body: loading())
          : DrawerScaffold(
              controller: controller,
              drawers: [
                SideDrawer(
                  color: AppColors.primaryColor,
                  percentage: 0.85,
                  child: const MyDrawer(),
                  alignment: Alignment.topLeft,
                  animation: true,
                ),
              ],
              builder: (context, id) {
                return BottomBar();
              },
            ),
    );
  }
}
