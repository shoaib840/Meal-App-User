import 'package:mealmap/utilz/constants/exports.dart';

class DineInHistroy extends StatefulWidget {
  const DineInHistroy({super.key});

  @override
  State<DineInHistroy> createState() => _DineInHistroyState();
}

class _DineInHistroyState extends State<DineInHistroy> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SizedBox(
      height: h,
      width: w,
      child: SingleChildScrollView(
        child: Column(
          children: [
            for (int i = 0; i < 10; i++) ...{
              dinrInListItemWidget(
                  resturantImagePath: ImagesApp.newResturantImage,
                  foodType: "Italian",
                  resturantName: "Don Giovanni",
                  locationOfRes: "75008, Paris",
                  resturantsRating: "9.4",
                  onTapDeleteThis: () {
                    showModalBottomSheet(
                      backgroundColor: Colors.transparent,
                      isScrollControlled: true,
                      context: context,
                      builder: (BuildContext context) {
                        return DeleteBottomSheet(
                          onAcceptClick: () {},
                        );
                      },
                    );
                  },
                  comingDaysLeftOfOrder: "22/6/2024",
                  timeOfOrder: "11:00 PM",
                  personsForOrder: "2 ${appLocal!.persons}",
                  percentDiscountOnOrder: "30%")
            }
          ],
        ),
      ),
    );
  }
}
