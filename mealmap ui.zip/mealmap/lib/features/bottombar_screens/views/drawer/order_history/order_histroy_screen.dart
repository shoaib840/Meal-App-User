import 'package:mealmap/utilz/constants/exports.dart';

class OrderHistroyScreen extends StatefulWidget {
  const OrderHistroyScreen({super.key});

  @override
  State<OrderHistroyScreen> createState() => _OrderHistroyScreenState();
}

class _OrderHistroyScreenState extends State<OrderHistroyScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              height: h,
              width: w,
              padding: EdgeInsets.symmetric(horizontal: w * 0.02),
              child: Column(
                children: [
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Row(
                    children: [
                      arrowBack(),
                      SizedBox(
                        width: w * 0.02,
                      ),
                      appText(
                          myText: appLocal!.ordershistory, //"Order history",
                          isbold: true),
                    ],
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Container(
                    height: h * 0.05,
                    width: w,
                    decoration: BoxDecoration(
                      color: AppColors.primaryColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: TabBar(
                      dividerColor: Colors.transparent,
                      indicatorColor: AppColors.blackColor,
                      controller: _tabController,
                      labelColor: AppColors.primaryColor,
                      tabs: [
                        Tab(
                          child: appText(
                            textAlign: TextAlign.center,
                            //"Order history",
                            myText: appLocal.delivery, // "Delivery",
                            isbold: true,
                            myfontSize: 12,
                          ),
                        ),
                        Tab(
                          child: appText(
                            textAlign: TextAlign.center,
                            myText: appLocal.takeaway, // "Take away",
                            isbold: true,
                            myfontSize: 12,
                          ),
                        ),
                        Tab(
                          child: appText(
                            textAlign: TextAlign.center,
                            myText: appLocal.dinein, //"Dine-in",
                            isbold: true,
                            myfontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Expanded(
                    child: TabBarView(
                      controller: _tabController,
                      children: const [
                        DeliveryHistroy(),
                        TakeAwayHistroy(),
                        DineInHistroy()
                      ],
                    ),
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                ],
              ),
            )));
  }
}
