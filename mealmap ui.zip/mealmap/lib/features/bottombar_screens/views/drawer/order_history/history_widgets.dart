import 'package:mealmap/utilz/constants/exports.dart';

Widget deliveryOrTakeAwayHistroyWidget(
    {required String foodImagePath,
    required String restuarantName,
    required String foodName,
    required String foodPrice,
    required onDeletePress,
    required String date,
    required String pieces}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Container(
      height: h * 0.12,
      width: w,
      margin: EdgeInsets.only(
        left: w * 0.01,
        right: w * 0.01,
        bottom: h * 0.01,
      ),
      padding: EdgeInsets.symmetric(horizontal: h * 0.01, vertical: w * 0.02),
      decoration: BoxDecoration(boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.2),
          spreadRadius: 2,
          blurRadius: 4,
          offset: const Offset(0, 3), // changes position of shadow
        ),
      ], color: Colors.white, borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          Container(
            height: h * 0.1,
            width: w * 0.2,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)),
            child: Image.asset(
              foodImagePath,
              fit: BoxFit.fill,
            ),
          ),
          SizedBox(
            width: w * 0.01,
          ),
          Expanded(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  appText(myText: "${appLocal!.from}  ", myfontSize: 10),
                  appText(myText: restuarantName, isbold: true, myfontSize: 10)
                ],
              ),
              appText(myText: foodName, isbold: true),
              Container(
                decoration: BoxDecoration(
                    color: AppColors.secondaryColor,
                    borderRadius: BorderRadius.circular(30)),
                padding: EdgeInsets.symmetric(
                    horizontal: w * 0.02, vertical: h * 0.005),
                child: appText(myText: foodPrice, myfontSize: 10),
              )
            ],
          )),
          SizedBox(
            width: w * 0.01,
          ),
          SizedBox(
            height: h * 0.1,
            width: w * 0.3,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                appText(myText: date, myfontSize: 7),
                Container(
                  height: h * 0.035,
                  width: w * 0.08,
                  clipBehavior: Clip.antiAlias,
                  decoration: const BoxDecoration(
                      color: AppColors.redColor, shape: BoxShape.circle),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: onDeletePress,
                      splashColor: AppColors.whiteColor,
                      child: const Center(
                          child: Icon(
                        Icons.delete_outline_outlined,
                        color: AppColors.whiteColor,
                        size: 14,
                      )),
                    ),
                  ),
                ),
                appText(myText: pieces, isbold: true)
              ],
            ),
          )
        ],
      ),
    );
  });
}

//----------------------------------------Dine In Widget

Widget dinrInListItemWidget({
  required String resturantImagePath,
  required String foodType,
  required String resturantName,
  required String locationOfRes,
  required String resturantsRating,
  required onTapDeleteThis,
  required String comingDaysLeftOfOrder,
  required String timeOfOrder,
  required String personsForOrder,
  required String percentDiscountOnOrder,
}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Container(
      margin: EdgeInsets.only(
        left: w * 0.01,
        right: w * 0.01,
        bottom: h * 0.01,
      ),
      padding: EdgeInsets.symmetric(horizontal: h * 0.01, vertical: w * 0.02),
      width: w,
      decoration: BoxDecoration(boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.2),
          spreadRadius: 2,
          blurRadius: 4,
          offset: const Offset(0, 3), // changes position of shadow
        ),
      ], color: Colors.white, borderRadius: BorderRadius.circular(10)),
      child: Column(
        children: [
          SizedBox(
            height: h * 0.13,
            width: w,
            child: Row(
              children: [
                Container(
                  height: h * 0.13,
                  width: w * 0.38,
                  clipBehavior: Clip.antiAlias,
                  decoration:
                      BoxDecoration(borderRadius: BorderRadius.circular(10)),
                  child: Image.asset(
                    resturantImagePath,
                    fit: BoxFit.fill,
                  ),
                ),
                SizedBox(
                  width: w * 0.02,
                ),
                //-----------------------------------//
                SizedBox(
                  height: h * 0.13,
                  width: w * 0.39,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      appText(myText: foodType),
                      appText(
                          myText: resturantName, myfontSize: 14, isbold: true),
                      appText(myText: locationOfRes, myfontSize: 10),
                      Container(
                        height: h * 0.03,
                        width: w * 0.27,
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: AppColors.greenColor,
                        ),
                        child: Row(
                          children: [
                            SizedBox(
                              width: w * 0.01,
                            ),
                            Container(
                              height: h * 0.025,
                              width: w * 0.05,
                              decoration: const BoxDecoration(
                                  color: AppColors.whiteColor,
                                  shape: BoxShape.circle),
                              child: const Icon(
                                Icons.check,
                                color: AppColors.greenColor,
                                size: 10,
                              ),
                            ),
                            SizedBox(
                              width: w * 0.01,
                            ),
                            appText(
                                myText: appLocal!.attended, //"Attended",
                                myfontSize: 8,
                                isbold: true)
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                const Spacer(),
                SizedBox(
                  height: h * 0.13,
                  width: w * 0.1,
                  child: Column(
                    children: [
                      Container(
                        height: h * 0.025,
                        width: w * 0.1,
                        decoration: BoxDecoration(
                            color: AppColors.secondaryColor,
                            borderRadius: BorderRadius.circular(10)),
                        child: Center(
                          child: appText(
                              myText: resturantsRating,
                              isbold: true,
                              myfontSize: 10),
                        ),
                      ),
                      SizedBox(
                        height: h * 0.02,
                      ),
                      Container(
                        height: h * 0.035,
                        width: w * 0.08,
                        clipBehavior: Clip.antiAlias,
                        decoration: const BoxDecoration(
                            color: AppColors.redColor, shape: BoxShape.circle),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: onTapDeleteThis,
                            splashColor: AppColors.whiteColor,
                            child: const Center(
                                child: Icon(
                              Icons.delete_outline_outlined,
                              color: AppColors.whiteColor,
                              size: 14,
                            )),
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
          //---------------------------------------------------------------------------------------------//
          SizedBox(
            height: h * 0.01,
          ),
          SizedBox(
            height: h * 0.06,
            width: w,
            child: Row(
              children: [
                Container(
                  height: h * 0.06,
                  width: w * 0.75,
                  decoration: BoxDecoration(
                      color: AppColors.secondaryColor,
                      borderRadius: BorderRadius.circular(10)),
                  child: Row(
                    children: [
                      SizedBox(
                        height: h * 0.06,
                        width: w * 0.25,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: h * 0.05,
                              width: w * 0.04,
                              child: Image.asset(IconsApp.calenderIcon),
                            ),
                            SizedBox(
                              width: w * 0.01,
                            ),
                            appText(
                                myText: comingDaysLeftOfOrder,
                                isbold: true,
                                myfontSize: 10)
                          ],
                        ),
                      ),
                      SizedBox(
                        height: h * 0.06,
                        width: w * 0.24,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: h * 0.05,
                              width: w * 0.04,
                              child: Image.asset(IconsApp.clockIcon),
                            ),
                            SizedBox(
                              width: w * 0.01,
                            ),
                            appText(
                                myText: timeOfOrder,
                                isbold: true,
                                myfontSize: 10)
                          ],
                        ),
                      ),
                      SizedBox(
                        height: h * 0.06,
                        width: w * 0.26,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: h * 0.05,
                              width: w * 0.04,
                              child: Image.asset(IconsApp.personsIcon),
                            ),
                            SizedBox(
                              width: w * 0.01,
                            ),
                            appText(
                                myText: personsForOrder,
                                isbold: true,
                                myfontSize: 10)
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  width: w * 0.01,
                ),
                Expanded(
                    child: Container(
                  height: h * 0.06,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: AppColors.yellowColor),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        height: h * 0.05,
                        width: w * 0.035,
                        child: Image.asset(
                          IconsApp.dollarBadgeIcon,
                        ),
                      ),
                      appText(
                          myText: percentDiscountOnOrder,
                          myfontSize: 10,
                          isbold: true)
                    ],
                  ),
                ))
              ],
            ),
          ),
        ],
      ),
    );
  });
}
