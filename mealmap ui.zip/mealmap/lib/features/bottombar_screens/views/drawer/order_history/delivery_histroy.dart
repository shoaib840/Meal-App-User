import 'package:mealmap/utilz/constants/exports.dart';

class DeliveryHistroy extends StatefulWidget {
  const DeliveryHistroy({super.key});

  @override
  State<DeliveryHistroy> createState() => _DeliveryHistroyState();
}

class _DeliveryHistroyState extends State<DeliveryHistroy> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SizedBox(
      height: h,
      width: w,
      child: SingleChildScrollView(
        child: Column(
          children: [
            for (int i = 0; i < 10; i++) ...{
              deliveryOrTakeAwayHistroyWidget(
                foodImagePath: ImagesApp.newFoodImage,
                restuarantName: "Don Giovanni",
                date: "${appLocal!.orderedon} 22/6/2024",
                foodName: "Crocché",
                foodPrice: "\$30",
                pieces: "2 ${appLocal.piece} ",
                onDeletePress: () {
                  showModalBottomSheet(
                    backgroundColor: Colors.transparent,
                    isScrollControlled: true,
                    context: context,
                    builder: (BuildContext context) {
                      return DeleteBottomSheet(
                        onAcceptClick: () {},
                      );
                    },
                  );
                },
              )
            }
          ],
        ),
      ),
    );
  }
}
