import 'package:mealmap/utilz/constants/exports.dart';

class TakeAwayHistroy extends StatefulWidget {
  const TakeAwayHistroy({super.key});

  @override
  State<TakeAwayHistroy> createState() => _TakeAwayHistroyState();
}

class _TakeAwayHistroyState extends State<TakeAwayHistroy> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SizedBox(
      height: h,
      width: w,
      child: SingleChildScrollView(
        child: Column(
          children: [
            for (int i = 0; i < 10; i++) ...{
              deliveryOrTakeAwayHistroyWidget(
                  foodImagePath: ImagesApp.newFoodImage,
                  restuarantName: "Don Giovanni",
                  date: "Ordered on 22/6/2024",
                  foodName: "Crocché",
                  foodPrice: "\$30",
                  onDeletePress: () {
                    showModalBottomSheet(
                      backgroundColor: Colors.transparent,
                      isScrollControlled: true,
                      context: context,
                      builder: (BuildContext context) {
                        return DeleteBottomSheet(
                          onAcceptClick: () {},
                        );
                      },
                    );
                  },
                  pieces: "2 Pieces")
            }
          ],
        ),
      ),
    );
  }
}
