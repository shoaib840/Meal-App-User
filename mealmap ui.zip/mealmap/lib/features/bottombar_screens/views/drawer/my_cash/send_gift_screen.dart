import 'dart:developer';

import 'package:mealmap/utilz/constants/exports.dart';

class SendGiftScreen extends StatefulWidget {
  const SendGiftScreen({super.key});

  @override
  State<SendGiftScreen> createState() => _SendGiftScreenState();
}

class _SendGiftScreenState extends State<SendGiftScreen> {
  TextEditingController phoneNumber = TextEditingController();
  String completePhoneNumber = '';
  int _selectedChipIndex = -1;
  List<String> giftPrices = ["10", "25", "50", "100", "150", "300", "500"];
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              height: h,
              width: w,
              padding: EdgeInsets.symmetric(horizontal: w * 0.02),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: h * 0.01,
                    ),
                    Row(
                      children: [
                        arrowBack(),
                        SizedBox(
                          width: w * 0.02,
                        ),
                        appText(
                            myText: appLocal!.sendagift, // "Send a gift",
                            isbold: true),
                      ],
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    appText(
                        myText: appLocal.sendagift, // "Send a gift",
                        isbold: true,
                        myfontSize: 22),
                    SizedBox(
                      height: h * 0.03,
                    ),
                    SizedBox(
                      height: h * 0.12,
                      width: w * 0.6,
                      child: Image.asset(
                        IconsApp.giftIcon,
                        color: AppColors.primaryColor,
                      ),
                    ),
                    SizedBox(
                      height: h * 0.04,
                    ),
                    appText(
                        myText: appLocal
                            .enterdetailsofthereciever, //"Enter details of the reciever",
                        isbold: true,
                        myfontSize: 14),
                    SizedBox(
                      height: h * 0.06,
                    ),
                    customTextField(
                        mYhintText:
                            "${appLocal.firstname} ${appLocal.lastname}",
                        keyBordType: TextInputType.name),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    customTextField(
                        mYhintText: appLocal.email, //"Email",
                        keyBordType: TextInputType.name),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    SizedBox(
                      width: w,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: IntlPhoneField(
                          dropdownIcon: const Icon(
                            Icons.arrow_drop_down,
                            color: AppColors.primaryColor,
                          ),
                          initialCountryCode: 'US',
                          controller: phoneNumber,
                          inputFormatters: [
                            FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                          ],
                          keyboardType: TextInputType.phone,
                          style: const TextStyle(fontFamily: "Poppins"),
                          decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 5, horizontal: 5),
                            filled: true,
                            fillColor: AppColors.secondaryColor,
                            floatingLabelBehavior: FloatingLabelBehavior.never,
                            counterText: '',
                            hintText: appLocal.phonenumber, //"Phone Number",
                            hintStyle: const TextStyle(
                                color: Colors.black,
                                fontSize: 12,
                                fontFamily: "Poppins"),
                            // labelText: 'Phone Number',
                            // labelStyle: const TextStyle(
                            //     color: Colors.black,
                            //     fontSize: 12,
                            //     fontFamily: "Poppins"),
                            errorBorder: OutlineInputBorder(
                              borderSide:
                                  const BorderSide(color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            enabled: true,
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            border: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          onChanged: (phone) {
                            setState(() {
                              completePhoneNumber =
                                  phone.completeNumber.toString();
                              log(phone.completeNumber.toString());
                              log(completePhoneNumber);
                            });
                          },
                          onCountryChanged: (phone) {
                            log('Country code changed to: ${phone.code}');
                          },
                        ),
                      ),
                    ),
                    SizedBox(
                      height: h * 0.04,
                    ),
                    appText(
                        myText: appLocal.selectamount, //"Select amount",
                        isbold: true,
                        myfontSize: 16),
                    SizedBox(
                      height: h * 0.01,
                    ),
                    Wrap(
                      alignment: WrapAlignment.center,
                      spacing: w * 0.03, // Space between chips
                      children: List.generate(giftPrices.length, (index) {
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedChipIndex = index;
                            });
                          },
                          child: Chip(
                            label: appText(
                                myText: "\$${giftPrices[index]}", isbold: true),
                            backgroundColor: _selectedChipIndex == index
                                ? AppColors.greenColor
                                : AppColors.secondaryColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                              side: BorderSide(
                                color: _selectedChipIndex == index
                                    ? AppColors.greenColor
                                    : AppColors.secondaryColor,
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                    //---------------------------------------------------//
                    SizedBox(
                      height: h * 0.04,
                    ),
                    SizedBox(
                      height: h * 0.065,
                      width: w * 0.8,
                      child: appButton(
                          buttonText: appLocal.buyandsend, //"Buy and send",
                          ontapfunction: () {
                            Navigator.pushReplacement(
                                context,
                                createRoute(
                                    newPage: const SuccessfulGiftScreen(
                                  isRadeem: false,
                                )));
                          }),
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                  ],
                ),
              ),
            )));
  }
}
