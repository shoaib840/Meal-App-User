import 'package:mealmap/utilz/constants/exports.dart';

class RedeemGiftScreen extends StatefulWidget {
  const RedeemGiftScreen({super.key});

  @override
  State<RedeemGiftScreen> createState() => _RedeemGiftScreenState();
}

class _RedeemGiftScreenState extends State<RedeemGiftScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              height: h,
              width: w,
              padding: EdgeInsets.symmetric(horizontal: w * 0.02),
              child: Column(
                children: [
                  SizedBox(
                    height: h * 0.01,
                  ),
                  Row(
                    children: [
                      arrowBack(),
                      SizedBox(
                        width: w * 0.02,
                      ),
                      appText(
                          myText:
                              appLocal!.redeemyourgift, //"Redeem your gift",
                          isbold: true),
                    ],
                  ),
                  SizedBox(
                    height: h * 0.08,
                  ),
                  appText(
                      myText: appLocal.redeemagift, //"Redeem a gift",
                      isbold: true,
                      myfontSize: 22),
                  SizedBox(
                    height: h * 0.05,
                  ),
                  SizedBox(
                    height: h * 0.12,
                    width: w * 0.6,
                    child: Image.asset(
                      IconsApp.openGiftIcon,
                      color: AppColors.primaryColor,
                    ),
                  ),
                  SizedBox(
                    height: h * 0.06,
                  ),
                  Expanded(
                      child: SingleChildScrollView(
                    child: Column(
                      children: [
                        for (int i = 0; i < 3; i++) ...{
                          redeemsGiftWidget(
                              moneyForRedeem: "\$50",
                              senderName: "Eagle solutions",
                              senderNumber: "+92 300 000 0000",
                              senderCountry: "Italy",
                              onTapRadeem: () {
                                Navigator.pushReplacement(
                                    context,
                                    createRoute(
                                        newPage: const SuccessfulGiftScreen(
                                      isRadeem: true,
                                    )));
                              })
                        }
                      ],
                    ),
                  ))
                ],
              ),
            )));
  }
}

//-------------------------------------------------------------------------//
Widget redeemsGiftWidget(
    {required String moneyForRedeem,
    required String senderName,
    required String senderNumber,
    required String senderCountry,
    required onTapRadeem}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return Container(
      width: w,
      margin: EdgeInsets.only(bottom: h * 0.01),
      padding: EdgeInsets.symmetric(horizontal: w * 0.02, vertical: h * 0.01),
      decoration: BoxDecoration(boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.2),
          spreadRadius: 3,
          blurRadius: 5,
          offset: const Offset(0, 3), // changes position of shadow
        ),
      ], color: AppColors.whiteColor, borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          Container(
            height: h * 0.1,
            width: w * 0.2,
            decoration: BoxDecoration(
                color: AppColors.secondaryColor.withOpacity(0.5),
                borderRadius: BorderRadius.circular(10)),
            child: Center(
                child: appText(
                    myText: moneyForRedeem, isbold: true, myfontSize: 22)),
          ),
          SizedBox(
            width: w * 0.02,
          ),
          Expanded(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              appText(
                  myText: appLocal!.sender, //"Sender",
                  isbold: true,
                  myfontSize: 10),
              appText(
                myText: senderName,
                isbold: true,
              ),
              appText(myText: senderNumber, isbold: true, myfontSize: 10),
              appText(myText: senderCountry, isbold: true, myfontSize: 8),
            ],
          )),
          SizedBox(
            width: w * 0.01,
          ),
          SizedBox(
            height: h * 0.045,
            width: w * 0.22,
            child: appButton(
                myfontSize: 10,
                buttonText: appLocal.redeem, // "Redeem",
                ontapfunction: onTapRadeem),
          )
        ],
      ),
    );
  });
}
