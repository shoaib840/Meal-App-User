import 'package:mealmap/utilz/constants/exports.dart';

class SuccessfulGiftScreen extends StatefulWidget {
  final bool isRadeem;
  const SuccessfulGiftScreen({super.key, required this.isRadeem});

  @override
  State<SuccessfulGiftScreen> createState() => _SuccessfulGiftScreenState();
}

class _SuccessfulGiftScreenState extends State<SuccessfulGiftScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              padding: EdgeInsets.symmetric(horizontal: w * 0.02),
              height: h,
              width: w,
              child: Column(
                children: [
                  SizedBox(
                    height: h * 0.01,
                  ),
                  Row(
                    children: [
                      arrowBack(),
                    ],
                  ),
                  SizedBox(
                    height: h * 0.03,
                  ),
                  SizedBox(
                    height: h * 0.05,
                    width: w * 0.1,
                    child: Image.asset(IconsApp.appIcon),
                  ),
                  SizedBox(
                    height: h * 0.01,
                  ),
                  appText(myText: "MealApp", isbold: true, myfontSize: 30),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  Container(
                    height: h * 0.3,
                    width: w * 0.8,
                    decoration: const BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage(IconsApp.celebrationIcon))),
                    child: Center(
                      child: Container(
                        height: h * 0.1,
                        width: w * 0.2,
                        decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppColors.greenColor),
                        child: const Icon(
                          Icons.check,
                          color: AppColors.whiteColor,
                          size: 50,
                        ),
                      ),
                    ),
                  ),

                  //---------------------------------------------------------------------//
                  SizedBox(
                    height: h * 0.04,
                  ),
                  appText(
                      myText: widget.isRadeem
                          ? appLocal!.giftcardredeemedsuccesfully

                          ///"Gift card redeemed succesfully!"
                          : appLocal!
                              .giftcardsentsuccesfully, // "Gift card sent succesfully!",
                      isbold: true,
                      myfontSize: 16),
                  SizedBox(
                    height: h * 0.02,
                  ),
//[--------------------------------------------------------------------------------------------//]
                  widget.isRadeem
                      ? Text.rich(
                          style: const TextStyle(
                              fontFamily: "Poppins",
                              fontWeight: FontWeight.bold,
                              fontSize: 12),
                          textAlign: TextAlign.center,
                          TextSpan(
                            text:
                                appLocal.agiftcardworth, //'A gift card worth ',
                            style: const TextStyle(color: Colors.black),
                            children: <TextSpan>[
                              const TextSpan(
                                text: ' \$50 ',
                                style: TextStyle(color: AppColors.primaryColor),
                              ),
                              TextSpan(
                                text: appLocal.from,
                                style: const TextStyle(color: Colors.black),
                              ),
                              const TextSpan(
                                text: ' Eagle Solutions ',
                                style: TextStyle(color: AppColors.primaryColor),
                              ),
                              TextSpan(
                                text: appLocal.wasredeemed, //' was redeemed.',
                                style: const TextStyle(color: Colors.black),
                              ),
                            ],
                          ),
                        )
                      : Text.rich(
                          style: const TextStyle(
                              fontFamily: "Poppins",
                              fontWeight: FontWeight.bold,
                              fontSize: 12),
                          textAlign: TextAlign.center,
                          TextSpan(
                            text:
                                appLocal.agiftcardworth, //'A gift card worth',
                            style: const TextStyle(color: Colors.black),
                            children: <TextSpan>[
                              const TextSpan(
                                text: ' \$50 ',
                                style: TextStyle(color: AppColors.primaryColor),
                              ),
                              TextSpan(
                                text: appLocal.wassentto, //'was sent to',
                                style: const TextStyle(color: Colors.black),
                              ),
                              const TextSpan(
                                text: ' Eagle Solutions.',
                                style: TextStyle(color: AppColors.primaryColor),
                              ),
                            ],
                          ),
                        ),
                  //-------------------------------------------------------------------------------//
                  const Spacer(),
                  SizedBox(
                    height: h * 0.065,
                    width: w * 0.8,
                    child: appButton(
                        buttonText: appLocal.backtohome, // "Back to home",
                        ontapfunction: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            createRoute(newPage: const DrawerWithBottomBar()),
                            (route) => false,
                          );
                        }),
                  ),
                  SizedBox(
                    height: h * 0.02,
                  )
                ],
              ),
            )));
  }
}
