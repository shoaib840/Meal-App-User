import 'package:mealmap/utilz/constants/exports.dart';

class MyCashScreen extends StatefulWidget {
  const MyCashScreen({super.key});

  @override
  State<MyCashScreen> createState() => _MyCashScreenState();
}

class _MyCashScreenState extends State<MyCashScreen> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.backgroundColor,
        body: Container(
          height: h,
          width: w,
          padding: EdgeInsets.symmetric(horizontal: w * 0.02),
          child: Column(
            children: [
              SizedBox(
                height: h * 0.01,
              ),
              Row(
                children: [
                  arrowBack(),
                  SizedBox(
                    width: w * 0.02,
                  ),
                  appText(
                      myText: appLocal!.mycash, //"My cash",
                      isbold: true),
                ],
              ),
              SizedBox(
                height: h * 0.05,
              ),
              appText(
                  myText: appLocal.balance, //"Balance",
                  isbold: true,
                  myfontSize: 22),
              SizedBox(
                height: h * 0.02,
              ),
              Container(
                height: h * 0.12,
                width: w * 0.24,
                decoration: const BoxDecoration(
                  color: AppColors.secondaryColor,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: appText(myText: "\$120", isbold: true, myfontSize: 16),
                ),
              ),
              SizedBox(
                height: h * 0.03,
              ),
              Container(
                height: h * 0.05,
                width: w * 0.38,
                padding: EdgeInsets.only(left: w * 0.01, right: w * 0.01),
                decoration: BoxDecoration(
                    color: AppColors.greyColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20)),
                child: Row(
                  children: [
                    SizedBox(
                        height: h * 0.03,
                        child: Image.asset(IconsApp.glassIcon)),
                    SizedBox(
                      width: w * 0.06,
                    ),
                    appText(
                      myText: "100",
                      isbold: true,
                      myfontSize: 14,
                    ),
                    appText(
                      myText: " MiSpritz",
                    )
                  ],
                ),
              ),
              SizedBox(
                height: h * 0.1,
              ),
              cashWidget(
                  iconPath: IconsApp.giftIcon,
                  onTap: () {
                    Navigator.push(
                        context, createRoute(newPage: const SendGiftScreen()));
                  },
                  firstText: appLocal.sendagift, //"Send a gift",
                  secondText: appLocal
                      .youcansendagifttoyourfriends, //"You can send a gift to your friends",
                  boxColor: AppColors.secondaryColor.withOpacity(0.3)),
              SizedBox(
                height: h * 0.02,
              ),
              cashWidget(
                  iconPath: IconsApp.giftIcon,
                  onTap: () {
                    Navigator.push(context,
                        createRoute(newPage: const RedeemGiftScreen()));
                  },
                  firstText:appLocal.redeemyourgiftcard, //"Redeem your gift card",
                  secondText: appLocal.redeemgiftcardssentbyyourfriends, //"Redeem gift cards sent by your friends",
                  boxColor: AppColors.greyColor.withOpacity(0.2))
            ],
          ),
        ),
      ),
    );
  }
}

Widget cashWidget(
    {required String iconPath,
    required onTap,
    required String firstText,
    required String secondText,
    required boxColor}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: h * 0.09,
        width: w,
        padding: EdgeInsets.symmetric(horizontal: w * 0.02),
        decoration: BoxDecoration(
            color: boxColor, borderRadius: BorderRadius.circular(10)),
        child: Row(
          children: [
            SizedBox(
              height: h * 0.04,
              width: w * 0.06,
              child: Image.asset(IconsApp.giftIcon),
            ),
            SizedBox(
              width: w * 0.02,
            ),
            Expanded(
                child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                appText(myText: firstText, isbold: true),
                appText(myText: secondText)
              ],
            )),
            Container(
                height: h * 0.035,
                width: w * 0.11,
                clipBehavior: Clip.antiAlias,
                decoration: const BoxDecoration(
                    color: AppColors.secondaryColor, shape: BoxShape.circle),
                child: const Icon(Icons.arrow_forward_ios_outlined,
                    size: 14, color: AppColors.primaryColor)),
          ],
        ),
      ),
    );
  });
}
