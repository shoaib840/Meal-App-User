import 'dart:developer';
import 'package:mealmap/utilz/constants/exports.dart';

class ContectUsScreen extends StatefulWidget {
  const ContectUsScreen({super.key});

  @override
  State<ContectUsScreen> createState() => _ContectUsScreenState();
}

class _ContectUsScreenState extends State<ContectUsScreen> {
  TextEditingController phoneNumber = TextEditingController();
  String completePhoneNumber = '';
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              height: h,
              width: w,
              padding: EdgeInsets.symmetric(horizontal: w * 0.02),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: h * 0.01,
                    ),
                    Row(
                      children: [
                        arrowBack(),
                        SizedBox(
                          width: w * 0.02,
                        ),
                        appText(
                            myText: appLocal!.contactus, // "Contact us",
                            isbold: true),
                      ],
                    ),
                    SizedBox(
                      height: h * 0.1,
                    ),
                    appText(
                        myText: appLocal.contactus, //"Contact us",
                        isbold: true,
                        myfontSize: 22),
                    SizedBox(
                      height: h * 0.05,
                    ),
                    SizedBox(
                      height: h * 0.15,
                      width: w * 0.5,
                      child: Image.asset(IconsApp.contectusMessageiconIcon),
                    ),
                    SizedBox(
                      height: h * 0.05,
                    ),
                    appText(
                        myText: appLocal
                            .enteryourdetailstogetintouch, // "Enter your details to get in touch",
                        isbold: true),
                    SizedBox(
                      height: h * 0.06,
                    ),
                    customTextField(
                        mYhintText: appLocal.name, // "Name",
                        keyBordType: TextInputType.name),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    customTextField(
                        mYhintText: appLocal.email, // "Email",
                        keyBordType: TextInputType.name),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    SizedBox(
                      width: w,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: IntlPhoneField(
                          dropdownIcon: const Icon(
                            Icons.arrow_drop_down,
                            color: AppColors.primaryColor,
                          ),
                          initialCountryCode: 'US',
                          controller: phoneNumber,
                          inputFormatters: [
                            FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                          ],
                          keyboardType: TextInputType.phone,
                          style: const TextStyle(fontFamily: "Poppins"),
                          decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 5, horizontal: 5),
                            filled: true,
                            fillColor: AppColors.secondaryColor,
                            floatingLabelBehavior: FloatingLabelBehavior.never,
                            counterText: '',
                            hintText: appLocal.phonenumber, //"Phone Number",
                            hintStyle: const TextStyle(
                                color: Colors.black,
                                fontSize: 12,
                                fontFamily: "Poppins"),
                            // labelText: 'Phone Number',
                            // labelStyle: const TextStyle(
                            //     color: Colors.black,
                            //     fontSize: 12,
                            //     fontFamily: "Poppins"),
                            errorBorder: OutlineInputBorder(
                              borderSide:
                                  const BorderSide(color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            enabled: true,
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            border: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          onChanged: (phone) {
                            setState(() {
                              completePhoneNumber =
                                  phone.completeNumber.toString();
                              log(phone.completeNumber.toString());
                              log(completePhoneNumber);
                            });
                          },
                          onCountryChanged: (phone) {
                            log('Country code changed to: ${phone.code}');
                          },
                        ),
                      ),
                    ),
                    SizedBox(
                      height: h * 0.1,
                    ),
                    SizedBox(
                      height: h * 0.065,
                      width: w * 0.8,
                      child: appButton(
                          buttonText: appLocal.getintouch, //"Get in touch",
                          ontapfunction: () {}),
                    ),
                    SizedBox(
                      height: h * 0.02,
                    )
                  ],
                ),
              ),
            )));
  }
}
