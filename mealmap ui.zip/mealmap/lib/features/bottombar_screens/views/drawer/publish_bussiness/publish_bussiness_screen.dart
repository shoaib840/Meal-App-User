import 'dart:developer';

import 'package:mealmap/utilz/constants/exports.dart';

class PublishBussinessScreen extends StatefulWidget {
  const PublishBussinessScreen({super.key});

  @override
  State<PublishBussinessScreen> createState() => _PublishBussinessScreenState();
}

class _PublishBussinessScreenState extends State<PublishBussinessScreen> {
  TextEditingController phoneNumberController = TextEditingController();
  TextEditingController whatsappNumberController = TextEditingController();
  String completePhoneNumber = '';
  String completeWhatsNumber = '';
  bool owndeliveryservice = true;
  bool contectedUs = true;

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: AppColors.backgroundColor,
            body: Container(
              height: h,
              width: w,
              padding: EdgeInsets.symmetric(horizontal: w * 0.05),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: h * 0.02,
                    ),
                    Row(
                      children: [
                        arrowBack(),
                        SizedBox(
                          width: w * 0.02,
                        ),
                        appText(
                            myText: appLocal!
                                .publishyourbusiness, //"Publish your business",
                            isbold: true),
                      ],
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    appText(
                        myText: appLocal
                            .pleasefillinyourbusinessdetails, //"Please fill in your business details",
                        myfontSize: 14,
                        isbold: true),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    customTextField(
                        mYhintText: appLocal.companyname, //"Company name",
                        keyBordType: TextInputType.name),
                    SizedBox(
                      height: h * 0.01,
                    ),
                    customTextField(
                        mYhintText: appLocal.email, //"Email",
                        keyBordType: TextInputType.name),
                    SizedBox(
                      height: h * 0.01,
                    ),
                    SizedBox(
                      width: w,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: IntlPhoneField(
                          validator: (phone) {
                            if (phone?.number == null ||
                                phone!.number.isEmpty) {
                              return appLocal.required; //'Required';
                            }
                            return null;
                          },
                          dropdownIcon: const Icon(
                            Icons.arrow_drop_down,
                            color: AppColors.primaryColor,
                          ),
                          initialCountryCode: 'US',
                          controller: phoneNumberController,
                          inputFormatters: [
                            FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                          ],
                          keyboardType: TextInputType.phone,
                          style: const TextStyle(fontFamily: "Poppins"),
                          decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 5, horizontal: 5),
                            filled: true,
                            fillColor: AppColors.secondaryColor,
                            floatingLabelBehavior: FloatingLabelBehavior.never,
                            counterText: '',
                            hintText: appLocal.phonenumber, //"Phone number",
                            hintStyle: const TextStyle(
                                color: Colors.black,
                                fontSize: 12,
                                fontFamily: "Poppins"),
                            errorBorder: OutlineInputBorder(
                              borderSide:
                                  const BorderSide(color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            enabled: true,
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            border: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          onChanged: (phone) {
                            setState(() {
                              completePhoneNumber =
                                  phone.completeNumber.toString();
                              log(phone.completeNumber.toString());
                              log(completePhoneNumber);
                            });
                          },
                          onCountryChanged: (phone) {
                            log('Country code changed to: ' +
                                phone.code.toString());
                          },
                        ),
                      ),
                    ),
                    SizedBox(
                      height: h * 0.01,
                    ),
                    SizedBox(
                      width: w,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: IntlPhoneField(
                          validator: (phone) {
                            if (phone?.number == null ||
                                phone!.number.isEmpty) {
                              return appLocal.required; //'Required';
                            }
                            return null;
                          },
                          dropdownIcon: const Icon(
                            Icons.arrow_drop_down,
                            color: AppColors.primaryColor,
                          ),
                          initialCountryCode: 'US',
                          controller: whatsappNumberController,
                          inputFormatters: [
                            FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                          ],
                          keyboardType: TextInputType.phone,
                          style: const TextStyle(fontFamily: "Poppins"),
                          decoration: InputDecoration(
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 5, horizontal: 5),
                            filled: true,
                            fillColor: AppColors.secondaryColor,
                            floatingLabelBehavior: FloatingLabelBehavior.never,
                            counterText: '',
                            hintText:
                                appLocal.whatsappnumber, //"Whatsapp number",
                            hintStyle: const TextStyle(
                                color: Colors.black,
                                fontSize: 12,
                                fontFamily: "Poppins"),
                            errorBorder: OutlineInputBorder(
                              borderSide:
                                  const BorderSide(color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            enabled: true,
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            border: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 2, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          onChanged: (phone) {
                            setState(() {
                              completeWhatsNumber =
                                  phone.completeNumber.toString();
                              log(phone.completeNumber.toString());
                              log(completeWhatsNumber);
                            });
                          },
                          onCountryChanged: (phone) {
                            log('Country code changed to: ' +
                                phone.code.toString());
                          },
                        ),
                      ),
                    ),
                    SizedBox(
                      height: h * 0.01,
                    ),
                    customTextField(
                        mYhintText:
                            appLocal.seatingcapacity, //"Seating capacity",
                        keyBordType: TextInputType.number),
                    SizedBox(
                      height: h * 0.01,
                    ),
                    customTextField(
                        mYhintText:
                            appLocal.averagereceipt, //"Average receipt",
                        keyBordType: TextInputType.number),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        appText(
                            myText: appLocal.companyname, //"Company address",
                            myfontSize: 14,
                            isbold: true),
                        Container(
                          height: h * 0.035,
                          width: w * 0.4,
                          decoration: BoxDecoration(
                              color: AppColors.secondaryColor,
                              borderRadius: BorderRadius.circular(30)),
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () {},
                              splashColor: AppColors.whiteColor,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  SizedBox(
                                    height: h * 0.02,
                                    width: w * 0.04,
                                    child: Image.asset(IconsApp.locationIcon),
                                  ),
                                  appText(
                                      myText: appLocal
                                          .getlocation, //"Get location",
                                      isbold: true,
                                      myfontSize: 10)
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    SizedBox(
                      height: h * 0.01,
                    ),
                    customTextField(
                        mYhintText: appLocal.streetaddress, //"Street address",
                        keyBordType: TextInputType.number),
                    SizedBox(
                      height: h * 0.01,
                    ),
                    customTextField(
                        mYhintText: appLocal.city, //"City",
                        keyBordType: TextInputType.number),
                    SizedBox(
                      height: h * 0.01,
                    ),
                    customTextField(
                        mYhintText: appLocal.postcode, //"Post code",
                        keyBordType: TextInputType.number),
                    SizedBox(
                      height: h * 0.01,
                    ),
                    customTextField(
                        mYhintText: appLocal.country, //"Country",
                        keyBordType: TextInputType.number),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    yesNoQuestionWidget(
                        question: appLocal
                            .doyouhaveyourowndeliveryservice, //"Do you have your own delivery service?",
                        onYesTap: () {
                          setState(() {
                            owndeliveryservice = true;
                          });
                        },
                        onNoTap: () {
                          setState(() {
                            owndeliveryservice = false;
                          });
                        },
                        yesClicked: owndeliveryservice),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    yesNoQuestionWidget(
                        onNoTap: () {
                          setState(() {
                            contectedUs = false;
                          });
                        },
                        question: appLocal
                            .wouldyouliketobecontactedbyus, //"Would you like to be contacted by us?",
                        onYesTap: () {
                          setState(() {
                            contectedUs = true;
                          });
                        },
                        yesClicked: contectedUs),
                    SizedBox(
                      height: h * 0.06,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          height: h * 0.065,
                          width: w * 0.8,
                          child: appButton(
                              buttonText: appLocal.submit, //"Submit",
                              ontapfunction: () {}),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: h * 0.02,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          height: h * 0.065,
                          width: w * 0.8,
                          child: appButtonWithIcon(
                              buttonText:
                                  appLocal.downloadapp, //"Download app",
                              ontapfunction: () {},
                              iconPath: IconsApp.playStoreIcon),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: h * 0.05,
                    ),
                  ],
                ),
              ),
            )));
  }
}

//-=--------------------------

Widget yesNoQuestionWidget(
    {required String question,
    required onYesTap,
    required onNoTap,
    required bool yesClicked}) {
  return Builder(builder: (context) {
    final appLocal = AppLocalizations.of(context);
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        appText(myText: question, isbold: true),
        SizedBox(
          height: h * 0.01,
        ),
        Row(
          children: [
            Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: onYesTap,
                splashColor: AppColors.secondaryColor,
                child: Row(
                  children: [
                    appText(
                        myText: appLocal!.yes, //"Yes",
                        isbold: true),
                    SizedBox(
                      width: w * 0.01,
                    ),
                    Container(
                      height: 16,
                      width: 16,
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.blackColor)),
                      child: Container(
                        decoration: BoxDecoration(
                            color: yesClicked
                                ? AppColors.blackColor
                                : Colors.transparent,
                            shape: BoxShape.circle),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: w * 0.08,
            ),
            Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: onNoTap,
                splashColor: AppColors.secondaryColor,
                child: Row(
                  children: [
                    appText(
                        myText: appLocal.no, //"No",
                        isbold: true),
                    SizedBox(
                      width: w * 0.01,
                    ),
                    Container(
                      height: 16,
                      width: 16,
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.blackColor)),
                      child: Container(
                        decoration: BoxDecoration(
                            color: yesClicked
                                ? Colors.transparent
                                : AppColors.blackColor,
                            shape: BoxShape.circle),
                      ),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ],
    );
  });
}
