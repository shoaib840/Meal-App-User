import 'package:mealmap/utilz/constants/exports.dart';

class MyDrawer extends StatefulWidget {
  const MyDrawer({super.key});

  @override
  State<MyDrawer> createState() => _MyDrawerState();
}

class _MyDrawerState extends State<MyDrawer> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final authsWatch = context.watch<AuthssController>();
    final appLocal = AppLocalizations.of(context);
    return Container(
      height: h,
      width: w * 0.76,
      padding: EdgeInsets.only(bottom: h * 0.02, top: w * 0.02),
      decoration: const BoxDecoration(
          color: AppColors.primaryColor,
          borderRadius: BorderRadius.only(
              topRight: Radius.circular(20), bottomRight: Radius.circular(20))),
      child: Column(
        children: [
          SizedBox(
            height: h * 0.02,
          ),
          GestureDetector(
            onTap: () {},
            child: SizedBox(
              height: h * 0.1,
              width: w,
              // color: AppColors.secondaryColor.withOpacity(0.2),
              child: Row(
                children: [
                  Container(
                    height: h * 0.07,
                    width: w * 0.18,
                    padding: EdgeInsets.all(
                        authsWatch.userData!['profileImage'] == "" ? 16 : 0),
                    clipBehavior: Clip.antiAlias,
                    decoration: const BoxDecoration(
                        color: AppColors.whiteColor, shape: BoxShape.circle),
                    child: authsWatch.userData!['profileImage'] == ""
                        ? Image.asset(
                            IconsApp.personIcon,
                            color: AppColors.blueColor,
                          )
                        : Image.network(
                            authsWatch.userData!['profileImage'],
                            fit: BoxFit.cover,
                          ),
                  ),
                  Expanded(
                      child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      appText(
                          myText:
                              "${authsWatch.userData!['firstName']} ${authsWatch.userData!['lastName']}",
                          isbold: true,
                          myfontSize: 14),
                      appText(
                          myText: authsWatch.userData!['email'], myfontSize: 12)
                    ],
                  )),
                ],
              ),
            ),
          ),
          //----------------------------------------------------------------------//

          GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const MyCashScreen(),
                  ));
            },
            child: SizedBox(
              height: h * 0.1,
              width: w,
              child: Row(
                children: [
                  Container(
                    height: h * 0.04,
                    width: w * 0.13,
                    padding: const EdgeInsets.all(10),
                    clipBehavior: Clip.antiAlias,
                    decoration: const BoxDecoration(
                        color: AppColors.whiteColor, shape: BoxShape.circle),
                    child: Image.asset(
                      IconsApp.dollarIcon,
                    ),
                  ),
                  Expanded(
                      child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      appText(
                          myText: appLocal!.mycash, // "My Cash",
                          isbold: true,
                          myfontSize: 14),
                      Row(
                        children: [
                          appText(
                              myText: appLocal.balance, // "Balance",
                              myfontSize: 12),
                          SizedBox(
                            width: w * 0.02,
                          ),
                          Container(
                            padding: const EdgeInsets.all(5),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: AppColors.whiteColor,
                            ),
                            child: appText(
                                myText: "\$${authsWatch.userData!['cash']}",
                                isbold: true),
                          )
                        ],
                      )
                    ],
                  )),
                  Container(
                      height: h * 0.035,
                      width: w * 0.11,
                      clipBehavior: Clip.antiAlias,
                      decoration: const BoxDecoration(
                          color: AppColors.whiteColor, shape: BoxShape.circle),
                      child: const Icon(Icons.arrow_forward_ios_outlined,
                          size: 14, color: AppColors.primaryColor)),
                ],
              ),
            ),
          ),
          SizedBox(
            height: h * 0.02,
          ),
          //---------------------------------------------------//
          Expanded(
              child: Container(
            padding: EdgeInsets.only(left: w * 0.02, right: w * 0.02),
            child: Column(
              children: [
                drawerOptions(
                    iconPath: IconsApp.personIcon,
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const ProfileScreen(),
                          ));
                    },
                    name: appLocal.profile, //"Profile",
                    iconColor: AppColors.blackColor),
                SizedBox(
                  height: h * 0.01,
                ),
                drawerOptions(
                  iconPath: IconsApp.histroyIcon,
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const OrderHistroyScreen(),
                        ));
                  },
                  name: appLocal.ordershistory, //"Orders History"
                ),
                SizedBox(
                  height: h * 0.01,
                ),
                drawerOptions(
                    iconPath: IconsApp.shareIcon,
                    onTap: () {},
                    name: appLocal.shareapp //"Share App"
                    ),
                SizedBox(
                  height: h * 0.01,
                ),
                drawerOptions(
                    iconPath: IconsApp.contectusIcon,
                    iconPadding: 1,
                    onTap: () {
                      Navigator.push(context,
                          createRoute(newPage: const ContectUsScreen()));
                    },
                    name: appLocal.contactus //"Contact Us"
                    ),
                SizedBox(
                  height: h * 0.01,
                ),
                drawerOptions(
                    iconPath: IconsApp.privacyIcon,
                    onTap: () {},
                    name: appLocal.privacypolicy //"Privacy Policy"
                    ),
                SizedBox(
                  height: h * 0.01,
                ),
                drawerOptions(
                    iconPath: IconsApp.languagesIcon,
                    onTap: () {
                      Navigator.push(
                          context,
                          createRoute(
                              newPage: const LanguageSelectionScreen()));
                    },
                    name: appLocal.language //"Languages"
                    ),
                const Spacer(),
                SizedBox(
                  height: h * 0.05,
                  child: appButton(
                      buttonText: appLocal
                          .publishyourbusiness, //"Publish your business",
                      buttonColor: AppColors.blackColor,
                      textColor: AppColors.whiteColor,
                      ontapfunction: () {
                        Navigator.push(
                            context,
                            createRoute(
                                newPage: const PublishBussinessScreen()));
                      }),
                ),
                SizedBox(
                  height: h * 0.02,
                ),
                SizedBox(
                  height: h * 0.05,
                  child: appButton(
                      buttonText:
                          appLocal.earnmoneyasarider, //"Earn money as a rider",
                      buttonColor: AppColors.blackColor,
                      textColor: AppColors.whiteColor,
                      ontapfunction: () {}),
                ),
                SizedBox(
                  height: h * 0.02,
                ),
                const Divider(
                  color: AppColors.greyColor,
                ),
                drawerOptions(
                  iconPath: IconsApp.logoutIcon,
                  onTap: () {
                    showModalBottomSheet(
                      backgroundColor: Colors.transparent,
                      isScrollControlled: true,
                      context: context,
                      builder: (BuildContext context) {
                        return const LogoutBottomSheet();
                      },
                    );
                  },
                  name: appLocal.logout, //"Logout"
                ),
                SizedBox(
                  height: h * 0.04,
                )
              ],
            ),
          ))
        ],
      ),
    );
  }
}

Widget drawerOptions(
    {required String iconPath,
    required onTap,
    double iconPadding = 0.0,
    iconColor,
    required String name}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SizedBox(
      height: h * 0.05,
      width: w,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          splashColor: AppColors.secondaryColor,
          child: Row(
            children: [
              SizedBox(
                width: w * 0.02,
              ),
              Container(
                padding: EdgeInsets.all(iconPadding),
                height: h * 0.02,
                child: Image.asset(
                  iconPath,
                  color: iconColor,
                ),
              ),
              SizedBox(
                width: w * 0.04,
              ),
              appText(myText: name, isbold: true)
            ],
          ),
        ),
      ),
    );
  });
}
