import 'package:mealmap/utilz/constants/exports.dart';

class LogoutBottomSheet extends StatefulWidget {
  const LogoutBottomSheet({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _LogoutBottomSheetState createState() => _LogoutBottomSheetState();
}

class _LogoutBottomSheetState extends State<LogoutBottomSheet> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: const BoxDecoration(
            color: AppColors.whiteColor,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15), topRight: Radius.circular(15))),
        margin: EdgeInsets.only(
          left: w * 0.04,
          right: w * 0.04,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        height: h * 0.35,
        width: w,
        child: Column(
          children: [
            appText(
                myText: appLocal!
                    .areyousureyouwanttologout, //"Are you sure you want to logout?",
                isbold: true),
            SizedBox(
              height: h * 0.04,
            ),
            SizedBox(
                height: h * 0.1,
                width: w * 0.5,
                child: Image.asset(IconsApp.logoutBigIcon)),
            const Spacer(),
            Container(
              height: h * 0.06,
              width: w * 0.7,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  color: AppColors.primaryColor),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                      width: w * 0.32,
                      height: h * 0.6,
                      child: appButton(
                          boxShadow: false,
                          buttonText: appLocal.accept, // "Accept",
                          ontapfunction: () async {
                            await FirebaseAuth.instance.signOut();
                            Navigator.pushAndRemoveUntil(
                                // ignore: use_build_context_synchronously
                                context,
                                createRoute(newPage: const LoginScreen()),
                                (route) => false);
                          })),
                  const VerticalDivider(
                    endIndent: 5,
                    indent: 5,
                    color: AppColors.blackColor,
                  ),
                  SizedBox(
                      width: w * 0.32,
                      height: h * 0.6,
                      child: appButton(
                          boxShadow: false,
                          buttonText: appLocal.decline, //"Decline",
                          ontapfunction: () {
                            Navigator.pop(context);
                          }))
                ],
              ),
            ),
            SizedBox(
              height: h * 0.02,
            ),
          ],
        ),
      ),
    );
  }
}
