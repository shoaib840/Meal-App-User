
import 'package:mealmap/utilz/constants/exports.dart';

class LanguageSelectionScreen extends StatefulWidget {
  const LanguageSelectionScreen({super.key});

  @override
  State<LanguageSelectionScreen> createState() =>
      _LanguageSelectionScreenState();
}

class _LanguageSelectionScreenState extends State<LanguageSelectionScreen> {
  List<Map<String, String>> listOfCountry = [
    {"flag": IconsApp.englishFlagIcon, "name": "English", "code": "en"},
    {"flag": IconsApp.spainFlagIcon, "name": "Spanish", "code": "es"},
    {"flag": IconsApp.franceFlagIcon, "name": "French", "code": "fr"},
    {"flag": IconsApp.italyFlagIcon, "name": "Italian", "code": "it"},
    {"flag": IconsApp.germanyFlagIcon, "name": "German", "code": "de"},
    {"flag": IconsApp.russiaFlagIcon, "name": "Russain", "code": "ru"},
    {"flag": IconsApp.greekFlagIcon, "name": "Greek", "code": "el"},
    {"flag": IconsApp.polishFlagIcon, "name": "Polish", "code": "pl"},
    {"flag": IconsApp.portugalFlagIcon, "name": "Portuguese", "code": "pt"},
    {"flag": IconsApp.turkeyFlagIcon, "name": "Turkish", "code": "tr"},
    {"flag": IconsApp.dutchFlagIcon, "name": "Dutch", "code": "nl"},
  ];

  int selectedIndex = -1;

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.backgroundColor,
        body: Container(
          height: h,
          width: w,
          padding: EdgeInsets.symmetric(horizontal: w * 0.02),
          child: Column(
            children: [
              SizedBox(height: h * 0.02),
              Row(
                children: [
                  arrowBack(),
                  SizedBox(width: w * 0.02),
                  appText(myText: appLocal!.language, isbold: true),
                ],
              ),
              SizedBox(height: h * 0.02),
              customTextField(
                prefixIcon: Icons.search,
                mYhintText: appLocal.language, //"Language",
                keyBordType: TextInputType.name,
              ),
              SizedBox(height: h * 0.02),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      for (int i = 0; i < listOfCountry.length; i++) ...{
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedIndex = i;
                            });
                            // Update the LanguageController with the selected language
                            Provider.of<LanguageControlllerr>(context,
                                    listen: false)
                                .changeLanguage(listOfCountry[i]['code']!);
                            // Navigate back or close the screen
                            Navigator.of(context).pop();
                          },
                          child: Container(
                            margin: EdgeInsets.only(bottom: h * 0.01),
                            height: h * 0.06,
                            width: w,
                            decoration: BoxDecoration(
                              color: selectedIndex == i
                                  ? AppColors.secondaryColor
                                  : AppColors.whiteColor,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              children: [
                                SizedBox(width: w * 0.02),
                                SizedBox(
                                  height: h * 0.03,
                                  width: w * 0.06,
                                  child: Image.asset(listOfCountry[i]['flag']!),
                                ),
                                SizedBox(width: w * 0.1),
                                appText(
                                  myText: listOfCountry[i]['name']!,
                                  isbold: true,
                                  myfontSize: 10,
                                ),
                              ],
                            ),
                          ),
                        ),
                      }
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
