bool emailvalidator(email) {
  if (RegExp(r'^.+@[a-zA-Z]+\.{1}[a-zA-Z]+(\.{0,1}[a-zA-Z]+)$')
      .hasMatch(email)) {
    return true;
  }
  return false;
}