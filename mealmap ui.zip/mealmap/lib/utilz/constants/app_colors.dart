import 'package:mealmap/utilz/constants/exports.dart';

class AppColors {
  static const Color primaryColor = Color(0xff58EBAD);
  static const Color secondaryColor = Color.fromARGB(255, 191, 249, 225);
  static const Color backgroundColor = Colors.white;
  static const Color textColor = Colors.black;
  static const Color whiteColor = Colors.white;
  static const Color blackColor = Colors.black;
  static const Color greyColor = Color(0xff999999);
  static const Color blueColor = Color(0xff29CEF2);
  static const Color yellowColor = Color(0xffFEC62B);
  static const Color lightyellowColor = Color(0xffFFF1C7);
  static const Color greenColor = Color(0xff86F474);
  static const Color redColor = Color(0xffEC3D46);
}
