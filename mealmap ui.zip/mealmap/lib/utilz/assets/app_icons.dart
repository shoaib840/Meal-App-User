class IconsApp {
  static const String appIcon = "assets/icons/mainlogo.png";
   static const String languagesIcon = "assets/icons/languages.png";
  
  static const String locationIcon = "assets/icons/locationIcon.png";
  static const String appleIcon = "assets/icons/apple.png";
  static const String googleIcon = "assets/icons/google.png";
  static const String mailIcon = "assets/icons/mail.png";
  static const String personIcon = "assets/icons/person.png";
  static const String homeIcon = "assets/icons/home.png";
  static const String reservationIcon = "assets/icons/reservation.png";
  static const String favouriteIcon = "assets/icons/favourite.png";
  static const String cartIcon = "assets/icons/cart.png";
  static const String qrCodeIcon = "assets/icons/qr_icon.png";
  static const String dollarIcon = "assets/icons/dollar.png";
  static const String fromlocationIcon = "assets/icons/location.png";
  static const String clockIcon = "assets/icons/clock.png";

  static const String histroyIcon = "assets/icons/histroy.png";
  static const String shareIcon = "assets/icons/share.png";
  static const String privacyIcon = "assets/icons/privacy.png";
  static const String glassIcon = "assets/icons/glass.png";
  static const String logoutIcon = "assets/icons/logout.png";
  static const String contectusIcon = "assets/icons/contectus.png";

  static const String calenderIcon = "assets/icons/calender.png";
  static const String personsIcon = "assets/icons/persons.png";
  static const String dollarBadgeIcon = "assets/icons/dollar_badge.png";
  static const String callingIcon = "assets/icons/calling.png";
  static const String shareNewIcon = "assets/icons/share_new.png";
  static const String cancelIcon = "assets/icons/cancel_icon.png";

  static const String starmessageIcon = "assets/icons/starmessage.png";
  static const String cardIcon = "assets/icons/card.png";
  static const String logoutBigIcon = "assets/icons/logoutIcon.png";
  static const String contectusMessageiconIcon =
      "assets/icons/contectus_messageicon.png";

  static const String giftIcon = "assets/icons/gift.png";
  static const String openGiftIcon = "assets/icons/open_gift.png";
  static const String celebrationIcon = "assets/icons/celebration.png";

  static const String deliveryIcon = "assets/icons/delivery.png";
  static const String takeawayIcon = "assets/icons/takeaway.png";
  static const String dineinIcon = "assets/icons/dinein.png";
  static const String trolleyIcon = "assets/icons/trolley.png";
  static const String cartPlusIcon = "assets/icons/cartPlus.png";

  static const String onboardingOneIcon = "assets/icons/onboarding1.png";
  static const String onboardingTwoIcon = "assets/icons/onboarding2.png";
  static const String onboardingThreeIcon = "assets/icons/onboarding3.png";

  static const String lockIcon = "assets/icons/lock.png";
  static const String phoneIcon = "assets/icons/phone.png";
  static const String menuDishIcon = "assets/icons/menu_dish.png";
  static const String thumbsUpIcon = "assets/icons/thumbsup.png";
  static const String playStoreIcon = "assets/icons/play_store.png";
  static const String dineinlocationIcon = "assets/icons/dine_in_locations.png";
  static const String riderIcon = "assets/icons/rider_icon.png";
  static const String tipIcon = "assets/icons/tip_icon.png";
  static const String galleryIcon = "assets/icons/gallery.png";
  static const String cameraIcon = "assets/icons/camera.png";

//-------Country
  static const String spainFlagIcon = "assets/icons/spain.png";
  static const String franceFlagIcon = "assets/icons/france.png";
  static const String italyFlagIcon = "assets/icons/italy.png";
  static const String germanyFlagIcon = "assets/icons/germany.png";
  static const String portugalFlagIcon = "assets/icons/portugal.png";

  static const String englishFlagIcon = "assets/icons/english.png";
  static const String dutchFlagIcon = "assets/icons/dutch.png";
  static const String greekFlagIcon = "assets/icons/greek.png";
  static const String polishFlagIcon = "assets/icons/polish.png";
  static const String russiaFlagIcon = "assets/icons/russia.png";
  static const String turkeyFlagIcon = "assets/icons/turkey.png";
}
