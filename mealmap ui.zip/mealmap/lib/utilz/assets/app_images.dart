class ImagesApp {
  static const String foodImage = 'assets/images/food.png';
  static const String resturantImage = 'assets/images/resturant.png';
  static const String showdowImage = 'assets/images/shadow_image.png';
  static const String newFoodImage = 'assets/images/newfood.png';
  static const String newResturantImage = 'assets/images/newResturant.jpg';
  static const String getStartedImage = 'assets/images/getstarted.jpg';
  static const String profileImage = 'assets/images/profile.jpg';
  static const String coldDrinkImage = 'assets/images/colddrink.png';
  static const String cilliSouseImage = 'assets/images/chillisouse.png';
}
