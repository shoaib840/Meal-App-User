import 'package:mealmap/utilz/constants/exports.dart';

ScaffoldFeatureController<SnackBar, SnackBarClosedReason> snaki(
    {required context, required String msg, bool isErrorColor = false}) {
  return ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
        duration: const Duration(milliseconds: 3000),
        backgroundColor:
            isErrorColor ? AppColors.redColor : AppColors.greenColor,
        behavior: SnackBarBehavior.floating,
        content: Text(msg,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white))),
  );
}
