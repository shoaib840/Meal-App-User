import 'package:mealmap/utilz/constants/exports.dart';

class DeleteBottomSheet extends StatefulWidget {
  final Function onAcceptClick;
  const DeleteBottomSheet({super.key, required this.onAcceptClick});

  @override
  // ignore: library_private_types_in_public_api
  _DeleteBottomSheetState createState() => _DeleteBottomSheetState();
}

class _DeleteBottomSheetState extends State<DeleteBottomSheet> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    final appLocal = AppLocalizations.of(context);
    return SingleChildScrollView(
      child: Container(
        width: w,
        padding: const EdgeInsets.all(16.0),
        decoration: const BoxDecoration(
            color: AppColors.whiteColor,
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15), topRight: Radius.circular(15))),
        margin: EdgeInsets.only(
          left: w * 0.04,
          right: w * 0.04,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        height: h * 0.45,
        child: Column(
          children: [
            appText(
                myText: appLocal!
                    .areyousureyouwanttodelete, //"Are you sure you want to delete?",
                isbold: true,
                textAlign: TextAlign.center),
            SizedBox(
              height: h * 0.02,
            ),
            SizedBox(
              height: h * 0.25,
              width: w,
              child: Icon(
                Icons.delete_outline,
                size: h * 0.24,
                color: AppColors.redColor,
              ),
            ),
            const Spacer(),
            Container(
              height: h * 0.06,
              width: w * 0.65,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  color: AppColors.primaryColor),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                      width: w * 0.3,
                      height: h * 0.6,
                      child: appButton(
                          boxShadow: false,
                          buttonText: appLocal.accept, //"Accept",
                          ontapfunction: widget.onAcceptClick)),
                  const VerticalDivider(
                    endIndent: 5,
                    indent: 5,
                    color: AppColors.blackColor,
                  ),
                  SizedBox(
                      width: w * 0.3,
                      height: h * 0.6,
                      child: appButton(
                          boxShadow: false,
                          buttonText: appLocal.decline, // "Decline",
                          ontapfunction: () {
                            Navigator.pop(context);
                          }))
                ],
              ),
            ),
            SizedBox(
              height: h * 0.01,
            ),
          ],
        ),
      ),
    );
  }
}
