import 'package:mealmap/utilz/constants/exports.dart';

Widget appButton({
  required String buttonText,
  required ontapfunction,
  buttonColor,
  textColor,
  bool? textBold = true,
  borderColor,
  bool boxShadow = true,
  buttonClickColor,
  double? myfontSize,
  double? borderRadius,
}) {
  return AnimatedContainer(
    clipBehavior: Clip.antiAlias,
    duration: const Duration(milliseconds: 300),
    decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: boxShadow == true
                ? Colors.grey.withOpacity(0.3)
                : Colors.transparent,
            spreadRadius: 3,
            blurRadius: 5,
            offset: const Offset(0, 3), // changes position of shadow
          ),
        ],
        borderRadius: BorderRadius.circular(borderRadius ?? 25),
        border:
            Border.all(width: 1, color: borderColor ?? AppColors.primaryColor),
        color: buttonColor ?? AppColors.primaryColor),
    child: Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: ontapfunction,
        splashColor: buttonClickColor ?? Colors.white,
        child: Center(
          child: Text(
            buttonText,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontFamily: "Poppins",
                fontSize: myfontSize ?? 12,
                color: textColor ?? AppColors.textColor,
                fontWeight:
                    textBold == true ? FontWeight.bold : FontWeight.normal),
          ),
        ),
      ),
    ),
  );
}

Widget appButtonWithIcon(
    {required String buttonText,
    required ontapfunction,
    buttonColor,
    textColor,
    bool? textBold = true,
    borderColor,
    bool boxShadow = true,
    buttonClickColor,
    double? myfontSize,
    double? borderRadius,
    required String iconPath}) {
  return AnimatedContainer(
    clipBehavior: Clip.antiAlias,
    duration: const Duration(milliseconds: 300),
    decoration: BoxDecoration(
        // boxShadow: [
        //   BoxShadow(
        //     color:
        //         boxShadow == true ? Colors.grey.withOpacity(0.3) : Colors.white,
        //     spreadRadius: 3,
        //     blurRadius: 5,
        //     offset: const Offset(0, 3), // changes position of shadow
        //   ),
        // ],
        borderRadius: BorderRadius.circular(borderRadius ?? 25),
        border:
            Border.all(width: 1, color: borderColor ?? AppColors.primaryColor),
        color: buttonColor ?? AppColors.whiteColor),
    child: Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: ontapfunction,
        splashColor: buttonClickColor ?? AppColors.primaryColor,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 15,
              width: 15,
              child: Image.asset(iconPath),
            ),
            const SizedBox(
              width: 20,
            ),
            Text(
              buttonText,
              style: TextStyle(
                  fontFamily: "Poppins",
                  fontSize: myfontSize ?? 12,
                  color: textColor ?? AppColors.textColor,
                  fontWeight:
                      textBold == true ? FontWeight.bold : FontWeight.normal),
            ),
          ],
        ),
      ),
    ),
  );
}
