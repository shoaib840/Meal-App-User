import 'package:mealmap/utilz/constants/exports.dart';

Widget editBoxWidget({
  required  onTap
}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Container(
      height: h * 0.04,
      width: w * 0.07,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
          color: AppColors.secondaryColor.withOpacity(0.5),
          shape: BoxShape.circle),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          splashColor: AppColors.whiteColor,
          child: const Center(
            child: Icon(
              Icons.edit,
              size: 14,
              color: AppColors.primaryColor,
            ),
          ),
        ),
      ),
    );
  });
}
