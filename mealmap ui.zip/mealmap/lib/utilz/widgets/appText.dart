import 'package:mealmap/utilz/constants/exports.dart';

Widget appText(
    {required String myText,
    double? myfontSize,
    bool isbold = false,
    textAlign,
    Color? myColors}) {
  return Text(myText,
      textAlign: textAlign ?? TextAlign.start,
      style: TextStyle(
          fontFamily: "Poppins",
          color: myColors ?? AppColors.textColor,
          fontWeight: isbold ? FontWeight.bold : FontWeight.normal,
          fontSize: myfontSize ?? 12));
}
