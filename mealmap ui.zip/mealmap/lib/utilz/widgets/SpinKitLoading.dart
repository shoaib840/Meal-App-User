import 'package:mealmap/utilz/constants/exports.dart';

Widget loading({Color? color, bool backDardColor = true}) {
  return Builder(builder: (context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Container(
      height: h,
      width: w,
      color: backDardColor
          ? AppColors.blackColor.withOpacity(0.4)
          : AppColors.whiteColor,
      child: Center(
        child: Container(
          height: h * 0.1,
          width: w * 0.2,
          decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  spreadRadius: 2,
                  blurRadius: 4,
                  offset: const Offset(0, 3), // changes position of shadow
                ),
              ],
              color: AppColors.whiteColor,
              borderRadius: BorderRadius.circular(10)),
          child: Center(
            child: SpinKitWave(
              color: color ?? AppColors.primaryColor,
              size: 20,
            ),
          ),
        ),
      ),
    );
  });
}
